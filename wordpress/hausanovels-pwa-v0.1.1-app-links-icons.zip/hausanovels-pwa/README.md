# HausaNovels PWA & TWA Bridge

Production PWA and Trusted Web Activity support for HausaNovels.ng.

## Routes

- `/manifest.webmanifest`
- `/service-worker.js`
- `/offline/`
- `/.well-known/assetlinks.json`

## What it does

- Adds an installable web manifest with normal and maskable icons.
- Registers a root-scoped service worker.
- Caches static assets without caching private account, wallet, login, payment, or publisher pages.
- Shows a professional offline screen when navigation fails.
- Provides a dynamic Digital Asset Links file for the Android TWA.
- Marks TWA sessions with a secure `hn_twa=1` cookie when the app opens with `?utm_source=twa`.

## TWA verification

Open **Hausa Books → PWA & Android TWA** and add the SHA-256 fingerprint from the Google Play App Signing certificate. The Android package name is `ng.hausanovels.app`.

Use the Play App Signing fingerprint for the production Play Store build. You may add more than one fingerprint, one per line, while testing.


## 0.1.1

- Uses safer padded app icons so launcher and PWA masks do not crop the HausaNovels mark.
- Limits the TWA detection cookie to 12 hours so ordinary Chrome sessions are not permanently treated as the app.
