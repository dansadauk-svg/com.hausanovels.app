<?php
/**
 * Plugin Name: HausaNovels PWA & TWA Bridge
 * Plugin URI: https://hausanovels.ng/
 * Description: Production PWA manifest, service worker, offline screen, and Digital Asset Links endpoint for the HausaNovels Trusted Web Activity.
 * Version: 0.1.1
 * Author: HausaNovels
 * Text Domain: hausanovels-pwa
 * Requires at least: 6.0
 * Requires PHP: 8.0
 *
 * @package HausaNovelsPWA
 */

if (! defined('ABSPATH')) {
    exit;
}

define('HAUSANOVELS_PWA_VERSION', '0.1.1');
define('HAUSANOVELS_PWA_FILE', __FILE__);
define('HAUSANOVELS_PWA_URL', plugin_dir_url(__FILE__));

final class HausaNovels_PWA_Plugin
{
    private const OPTION_NAME = 'hausanovels_pwa_settings';
    private const ENDPOINT_VAR = 'hn_pwa_endpoint';
    private const TWA_COOKIE = 'hn_twa';

    public static function init(): void
    {
        add_action('init', array(__CLASS__, 'register_routes'));
        add_filter('query_vars', array(__CLASS__, 'query_vars'));
        add_action('template_redirect', array(__CLASS__, 'remember_twa_mode'), -20);
        add_action('template_redirect', array(__CLASS__, 'render_endpoint'), -10);
        add_action('wp_head', array(__CLASS__, 'output_meta'), 1);
        add_action('wp_footer', array(__CLASS__, 'register_service_worker'), 50);
        add_filter('body_class', array(__CLASS__, 'body_classes'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
    }

    public static function activate(): void
    {
        if (! is_array(get_option(self::OPTION_NAME))) {
            update_option(self::OPTION_NAME, self::defaults());
        }

        self::register_routes();
        flush_rewrite_rules();
    }

    public static function deactivate(): void
    {
        flush_rewrite_rules();
    }

    public static function defaults(): array
    {
        return array(
            'package_name' => 'ng.hausanovels.app',
            'fingerprints' => '',
        );
    }

    public static function settings(): array
    {
        $settings = wp_parse_args((array) get_option(self::OPTION_NAME, array()), self::defaults());
        $settings['package_name'] = preg_replace('/[^A-Za-z0-9._]/', '', (string) $settings['package_name']) ?: 'ng.hausanovels.app';
        $settings['fingerprints'] = (string) $settings['fingerprints'];

        return $settings;
    }

    public static function register_routes(): void
    {
        add_rewrite_rule('^manifest\.webmanifest$', 'index.php?' . self::ENDPOINT_VAR . '=manifest', 'top');
        add_rewrite_rule('^service-worker\.js$', 'index.php?' . self::ENDPOINT_VAR . '=service-worker', 'top');
        add_rewrite_rule('^offline/?$', 'index.php?' . self::ENDPOINT_VAR . '=offline', 'top');
        add_rewrite_rule('^\.well-known/assetlinks\.json$', 'index.php?' . self::ENDPOINT_VAR . '=assetlinks', 'top');
    }

    public static function query_vars(array $vars): array
    {
        $vars[] = self::ENDPOINT_VAR;
        return $vars;
    }

    public static function remember_twa_mode(): void
    {
        $source = sanitize_key(wp_unslash($_GET['utm_source'] ?? $_GET['source'] ?? ''));
        $twa = sanitize_text_field(wp_unslash($_GET['twa'] ?? ''));

        if ('twa' !== $source && '1' !== $twa) {
            return;
        }

        if (! headers_sent()) {
            $cookie_options = array(
                'expires'  => time() + (12 * HOUR_IN_SECONDS),
                'path'     => COOKIEPATH ?: '/',
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            );

            if (defined('COOKIE_DOMAIN') && is_string(COOKIE_DOMAIN) && '' !== COOKIE_DOMAIN) {
                $cookie_options['domain'] = COOKIE_DOMAIN;
            }

            setcookie(self::TWA_COOKIE, '1', $cookie_options);
        }

        $_COOKIE[self::TWA_COOKIE] = '1';
    }

    public static function is_twa_request(): bool
    {
        if ('1' === sanitize_text_field(wp_unslash($_COOKIE[self::TWA_COOKIE] ?? ''))) {
            return true;
        }

        $source = sanitize_key(wp_unslash($_GET['utm_source'] ?? $_GET['source'] ?? ''));
        return 'twa' === $source || '1' === sanitize_text_field(wp_unslash($_GET['twa'] ?? ''));
    }

    public static function body_classes(array $classes): array
    {
        if (self::is_twa_request()) {
            $classes[] = 'hn-twa-app';
        }

        return array_values(array_unique($classes));
    }

    private static function request_path(): string
    {
        $request_uri = (string) wp_unslash($_SERVER['REQUEST_URI'] ?? '/');
        $path = (string) wp_parse_url($request_uri, PHP_URL_PATH);

        return '/' . ltrim($path, '/');
    }

    public static function render_endpoint(): void
    {
        $endpoint = sanitize_key((string) get_query_var(self::ENDPOINT_VAR));
        $path = self::request_path();

        if ('' === $endpoint) {
            $map = array(
                '/manifest.webmanifest'          => 'manifest',
                '/service-worker.js'             => 'service-worker',
                '/offline/'                      => 'offline',
                '/offline'                       => 'offline',
                '/.well-known/assetlinks.json'   => 'assetlinks',
            );
            $endpoint = $map[$path] ?? '';
        }

        if ('manifest' === $endpoint) {
            self::render_manifest();
        }

        if ('service-worker' === $endpoint) {
            self::render_service_worker();
        }

        if ('offline' === $endpoint) {
            self::render_offline_page();
        }

        if ('assetlinks' === $endpoint) {
            self::render_assetlinks();
        }
    }

    private static function icon_url(string $file): string
    {
        return HAUSANOVELS_PWA_URL . 'assets/icons/' . ltrim($file, '/');
    }

    private static function render_manifest(): void
    {
        nocache_headers();
        header('Content-Type: application/manifest+json; charset=utf-8');

        $manifest = array(
            'id'               => '/',
            'name'             => 'HausaNovels',
            'short_name'       => 'HausaNovels',
            'description'      => 'Read Hausa novels, manage your library, buy coins, and unlock premium chapters.',
            'lang'             => 'en-NG',
            'dir'              => 'ltr',
            'start_url'        => '/?utm_source=pwa',
            'scope'            => '/',
            'display'          => 'standalone',
            'display_override' => array('window-controls-overlay', 'standalone', 'minimal-ui'),
            'orientation'      => 'portrait-primary',
            'background_color' => '#050816',
            'theme_color'      => '#050816',
            'categories'       => array('books', 'entertainment', 'education'),
            'prefer_related_applications' => false,
            'launch_handler'   => array('client_mode' => 'navigate-existing'),
            'icons'            => array(
                array(
                    'src'     => self::icon_url('icon-192.png'),
                    'sizes'   => '192x192',
                    'type'    => 'image/png',
                    'purpose' => 'any',
                ),
                array(
                    'src'     => self::icon_url('icon-512.png'),
                    'sizes'   => '512x512',
                    'type'    => 'image/png',
                    'purpose' => 'any',
                ),
                array(
                    'src'     => self::icon_url('icon-maskable-512.png'),
                    'sizes'   => '512x512',
                    'type'    => 'image/png',
                    'purpose' => 'maskable',
                ),
            ),
            'shortcuts' => array(
                array(
                    'name'       => 'Library',
                    'short_name' => 'Library',
                    'url'        => '/library/?utm_source=pwa-shortcut',
                    'icons'      => array(array('src' => self::icon_url('icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png')),
                ),
                array(
                    'name'       => 'Discover Books',
                    'short_name' => 'Discover',
                    'url'        => '/discover/?utm_source=pwa-shortcut',
                    'icons'      => array(array('src' => self::icon_url('icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png')),
                ),
                array(
                    'name'       => 'Wallet',
                    'short_name' => 'Wallet',
                    'url'        => '/wallet/?utm_source=pwa-shortcut',
                    'icons'      => array(array('src' => self::icon_url('icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png')),
                ),
                array(
                    'name'       => 'Account',
                    'short_name' => 'Account',
                    'url'        => '/account/?utm_source=pwa-shortcut',
                    'icons'      => array(array('src' => self::icon_url('icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png')),
                ),
            ),
        );

        echo wp_json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    private static function render_service_worker(): void
    {
        header('Content-Type: application/javascript; charset=utf-8');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Service-Worker-Allowed: /');

        $cache_version = 'hn-pwa-' . HAUSANOVELS_PWA_VERSION;
        $offline_url = home_url('/offline/');
        $precache = array(
            $offline_url,
            self::icon_url('icon-192.png'),
            self::icon_url('icon-512.png'),
            self::icon_url('icon-maskable-512.png'),
        );
        ?>
const HN_CACHE = <?php echo wp_json_encode($cache_version); ?>;
const HN_OFFLINE_URL = <?php echo wp_json_encode($offline_url); ?>;
const HN_PRECACHE = <?php echo wp_json_encode($precache, JSON_UNESCAPED_SLASHES); ?>;
const HN_STATIC_DESTINATIONS = new Set(['style', 'script', 'image', 'font']);

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(HN_CACHE).then((cache) => cache.addAll(HN_PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((key) => key.startsWith('hn-pwa-') && key !== HN_CACHE).map((key) => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

function isSensitive(url) {
  const path = url.pathname.toLowerCase();
  const blockedPaths = [
    '/wp-admin', '/wp-login.php', '/wp-json', '/account', '/wallet', '/signin', '/register',
    '/forgot-password', '/reset-password', '/publisher', '/reading', '/bookmarks', '/checkout'
  ];
  if (blockedPaths.some((prefix) => path === prefix || path.startsWith(prefix + '/'))) return true;

  const blockedParams = [
    'rest_route', 'preview', 'customize_changeset_uuid', 'hn_google_callback', 'hn_google_app_login',
    'hn_paystack_callback', 'hn_paystack_webhook', 'reference', 'trxref', 'google_login'
  ];
  for (const key of blockedParams) {
    if (url.searchParams.has(key)) return true;
  }
  for (const key of url.searchParams.keys()) {
    if (key.startsWith('hn_')) return true;
  }
  return false;
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  if (request.cache === 'only-if-cached' && request.mode !== 'same-origin') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin || isSensitive(url)) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(HN_OFFLINE_URL)));
    return;
  }

  if (!HN_STATIC_DESTINATIONS.has(request.destination)) return;

  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request).then((response) => {
        if (response && response.ok && response.type === 'basic') {
          caches.open(HN_CACHE).then((cache) => cache.put(request, response.clone()));
        }
        return response;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
        <?php
        exit;
    }

    private static function render_offline_page(): void
    {
        status_header(200);
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));
        header('Cache-Control: public, max-age=3600');
        ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
    <meta name="theme-color" content="#050816">
    <title><?php esc_html_e('You are offline — HausaNovels', 'hausanovels-pwa'); ?></title>
    <style>
        *{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#050816;color:#f8fafc;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}.card{width:min(100%,420px);text-align:center;border:1px solid rgba(168,179,199,.18);border-radius:22px;background:linear-gradient(180deg,#111827,#080c18);padding:30px 22px;box-shadow:0 26px 80px rgba(0,0,0,.45)}img{width:92px;height:92px;object-fit:contain;margin-bottom:14px}h1{font-size:1.35rem;margin:0 0 10px}p{margin:0 0 20px;color:#a8b3c7;line-height:1.55}.button{display:inline-flex;min-height:46px;align-items:center;justify-content:center;border:0;border-radius:12px;background:#21c77a;color:#04110b;padding:0 18px;font-weight:900;cursor:pointer}
    </style>
</head>
<body>
    <main class="card">
        <img src="<?php echo esc_url(self::icon_url('icon-192.png')); ?>" alt="HausaNovels">
        <h1><?php esc_html_e('No internet connection', 'hausanovels-pwa'); ?></h1>
        <p><?php esc_html_e('Reconnect and try again. Previously loaded images and app resources may still be available.', 'hausanovels-pwa'); ?></p>
        <button class="button" type="button" onclick="location.reload()"><?php esc_html_e('Try again', 'hausanovels-pwa'); ?></button>
    </main>
</body>
</html>
        <?php
        exit;
    }

    private static function fingerprints(): array
    {
        $settings = self::settings();
        $lines = preg_split('/\r\n|\r|\n/', (string) $settings['fingerprints']);
        $fingerprints = array();

        foreach ((array) $lines as $line) {
            $value = strtoupper(trim((string) $line));
            $value = preg_replace('/\s+/', '', $value);
            if (preg_match('/^(?:[A-F0-9]{2}:){31}[A-F0-9]{2}$/', $value)) {
                $fingerprints[$value] = $value;
            }
        }

        return array_values($fingerprints);
    }

    private static function render_assetlinks(): void
    {
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');

        $settings = self::settings();
        $fingerprints = self::fingerprints();
        $output = array();

        if ($fingerprints) {
            $output[] = array(
                'relation' => array('delegate_permission/common.handle_all_urls'),
                'target'   => array(
                    'namespace'                => 'android_app',
                    'package_name'             => (string) $settings['package_name'],
                    'sha256_cert_fingerprints' => $fingerprints,
                ),
            );
        }

        echo wp_json_encode($output, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    public static function output_meta(): void
    {
        if (is_admin()) {
            return;
        }
        ?>
        <meta name="theme-color" content="#050816">
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <meta name="apple-mobile-web-app-title" content="HausaNovels">
        <link rel="manifest" href="<?php echo esc_url(home_url('/manifest.webmanifest')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url(self::icon_url('icon-32.png')); ?>">
        <link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url(self::icon_url('icon-192.png')); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url(self::icon_url('apple-touch-icon.png')); ?>">
        <?php
    }

    public static function register_service_worker(): void
    {
        if (is_admin() || ! is_ssl()) {
            return;
        }
        ?>
        <script>
        (function () {
            if (!('serviceWorker' in navigator)) return;
            window.addEventListener('load', function () {
                navigator.serviceWorker.register(<?php echo wp_json_encode(home_url('/service-worker.js?v=' . rawurlencode(HAUSANOVELS_PWA_VERSION))); ?>, {
                    scope: '/',
                    updateViaCache: 'none'
                }).catch(function () {});
            }, { once: true });
        }());
        </script>
        <?php
    }

    public static function admin_menu(): void
    {
        $parent = post_type_exists('hn_book') ? 'edit.php?post_type=hn_book' : 'options-general.php';
        add_submenu_page(
            $parent,
            __('PWA & Android TWA', 'hausanovels-pwa'),
            __('PWA & Android TWA', 'hausanovels-pwa'),
            'manage_options',
            'hausanovels-pwa',
            array(__CLASS__, 'render_admin_page')
        );
    }

    public static function render_admin_page(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $notice = '';
        if (isset($_POST['hn_pwa_save'])) {
            check_admin_referer('hn_pwa_save_settings', 'hn_pwa_nonce');
            $package_name = preg_replace('/[^A-Za-z0-9._]/', '', (string) wp_unslash($_POST['package_name'] ?? ''));
            $fingerprints = sanitize_textarea_field(wp_unslash($_POST['fingerprints'] ?? ''));
            update_option(self::OPTION_NAME, array(
                'package_name' => $package_name ?: 'ng.hausanovels.app',
                'fingerprints' => $fingerprints,
            ));
            flush_rewrite_rules(false);
            $notice = __('PWA and TWA settings saved.', 'hausanovels-pwa');
        }

        $settings = self::settings();
        $valid_fingerprints = self::fingerprints();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('HausaNovels PWA & Android TWA', 'hausanovels-pwa'); ?></h1>
            <?php if ($notice) : ?><div class="notice notice-success"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>
            <p><?php esc_html_e('This plugin provides the production web manifest, root service worker, offline page, and Digital Asset Links file required by the Android Trusted Web Activity.', 'hausanovels-pwa'); ?></p>

            <table class="widefat striped" style="max-width:900px;margin:18px 0;">
                <tbody>
                    <tr><th><?php esc_html_e('Web manifest', 'hausanovels-pwa'); ?></th><td><code><?php echo esc_html(home_url('/manifest.webmanifest')); ?></code></td></tr>
                    <tr><th><?php esc_html_e('Service worker', 'hausanovels-pwa'); ?></th><td><code><?php echo esc_html(home_url('/service-worker.js')); ?></code></td></tr>
                    <tr><th><?php esc_html_e('Offline page', 'hausanovels-pwa'); ?></th><td><code><?php echo esc_html(home_url('/offline/')); ?></code></td></tr>
                    <tr><th><?php esc_html_e('Digital Asset Links', 'hausanovels-pwa'); ?></th><td><code><?php echo esc_html(home_url('/.well-known/assetlinks.json')); ?></code></td></tr>
                </tbody>
            </table>

            <form method="post" style="max-width:900px;background:#fff;border:1px solid #dcdcde;padding:18px;">
                <?php wp_nonce_field('hn_pwa_save_settings', 'hn_pwa_nonce'); ?>
                <h2><?php esc_html_e('Trusted Web Activity verification', 'hausanovels-pwa'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="hn-pwa-package"><?php esc_html_e('Android package name', 'hausanovels-pwa'); ?></label></th>
                        <td><input id="hn-pwa-package" name="package_name" class="regular-text" value="<?php echo esc_attr((string) $settings['package_name']); ?>"><p class="description"><code>ng.hausanovels.app</code> keeps compatibility with the existing Play Console app.</p></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hn-pwa-fingerprints"><?php esc_html_e('SHA-256 certificate fingerprints', 'hausanovels-pwa'); ?></label></th>
                        <td><textarea id="hn-pwa-fingerprints" name="fingerprints" class="large-text code" rows="6" placeholder="AA:BB:CC:..."><?php echo esc_textarea((string) $settings['fingerprints']); ?></textarea><p class="description"><?php esc_html_e('Enter one fingerprint per line. Add the Google Play App Signing fingerprint for production. You may also add the upload-key fingerprint for direct testing.', 'hausanovels-pwa'); ?></p></td>
                    </tr>
                </table>
                <p><button type="submit" class="button button-primary" name="hn_pwa_save" value="1"><?php esc_html_e('Save PWA & TWA Settings', 'hausanovels-pwa'); ?></button></p>
            </form>

            <p style="margin-top:16px;"><strong><?php esc_html_e('Verification status:', 'hausanovels-pwa'); ?></strong> <?php echo $valid_fingerprints ? esc_html(sprintf(_n('%d valid fingerprint configured.', '%d valid fingerprints configured.', count($valid_fingerprints), 'hausanovels-pwa'), count($valid_fingerprints))) : esc_html__('No valid fingerprint configured yet. The app will open as a Custom Tab until this is added.', 'hausanovels-pwa'); ?></p>
        </div>
        <?php
    }
}

HausaNovels_PWA_Plugin::init();
register_activation_hook(__FILE__, array('HausaNovels_PWA_Plugin', 'activate'));
register_deactivation_hook(__FILE__, array('HausaNovels_PWA_Plugin', 'deactivate'));

if (! function_exists('hn_pwa_is_twa_request')) {
    function hn_pwa_is_twa_request(): bool
    {
        return HausaNovels_PWA_Plugin::is_twa_request();
    }
}
