<?php
/**
 * Default WordPress page template.
 *
 * @package HausanovelsDark
 */

get_header();

while (have_posts()) :
    the_post();
    ?>
    <section class="hn-page-content">
        <article class="hn-standard-page">
            <header class="hn-page-header">
                <h1><?php echo esc_html(get_the_title()); ?></h1>
            </header>

            <div class="hn-page-body">
                <?php the_content(); ?>
            </div>
        </article>
    </section>
    <?php
endwhile;

get_footer();
