<?php
/**
 * Book archive template.
 *
 * @package HausanovelsDark
 */

get_header();
?>
<section class="hn-hero">
    <div>
        <p class="hn-eyebrow"><?php esc_html_e('Hausa ebook library', 'hausanovels'); ?></p>
        <h1><?php esc_html_e('Complete Hausa novels, latest books, and paid chapters.', 'hausanovels'); ?></h1>
    </div>
</section>

<section class="hn-section">
    <div class="hn-section-head">
        <h2><?php esc_html_e('All Books', 'hausanovels'); ?></h2>
        <span class="hn-section-line" aria-hidden="true"></span>
    </div>
    <?php if (have_posts()) : ?>
        <div class="hn-book-grid">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/book-card', null, array('book' => hausanovels_book_from_post(get_post())));
            endwhile;
            ?>
        </div>
    <?php else : ?>
        <div class="hn-empty-panel">
            <h2><?php esc_html_e('No books yet', 'hausanovels'); ?></h2>
            <p><?php esc_html_e('Published books will appear here once they are added.', 'hausanovels'); ?></p>
        </div>
    <?php endif; ?>
</section>

<?php
the_posts_pagination(array(
    'mid_size'  => 1,
    'prev_text' => __('Newer', 'hausanovels'),
    'next_text' => __('Older', 'hausanovels'),
));

get_footer();
