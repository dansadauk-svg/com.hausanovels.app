<?php
/**
 * Mobile-first app homepage.
 *
 * @package HausanovelsDark
 */

get_header();

$featured = hausanovels_get_featured_books(8);

$trending = hausanovels_get_trending_books(10);

$latest = hausanovels_get_books(array(
    'posts_per_page' => 10,
    'orderby'        => 'date',
    'order'          => 'DESC',
));

$continue_reading = array();
if (is_user_logged_in() && function_exists('hn_reader_get_continue_books')) {
    $continue_reading = hn_reader_get_continue_books(get_current_user_id(), 10);
}

$genres = hausanovels_get_genres();
?>

<?php
$hero_books = array_values(array_filter($featured));
$hero_main = $hero_books[0] ?? null;
$hero_description = $hero_main ? trim((string) ($hero_main['description'] ?? '')) : '';
if ('' === $hero_description) {
    $hero_description = __('A featured Hausa ebook from the library. Read fresh chapters and discover your next story.', 'hausanovels');
}
?>

<?php if ($hero_main) : ?>
    <section class="hn-home-hero" aria-labelledby="hn-home-title">
        <a class="hn-hero-feature" href="<?php echo esc_url($hero_main['permalink'] ?? '#'); ?>">
            <span class="hn-hero-feature-cover">
                <img src="<?php echo esc_url($hero_main['cover']); ?>" alt="<?php echo esc_attr(sprintf(__('%s book cover', 'hausanovels'), $hero_main['title'])); ?>" loading="eager" decoding="async">
            </span>
            <span class="hn-hero-feature-copy">
                <span class="hn-hero-kicker"><?php esc_html_e('Featured Hausa ebook', 'hausanovels'); ?></span>
                <h1 id="hn-home-title"><?php esc_html_e('Books', 'hausanovels'); ?></h1>
                <span class="hn-hero-book-title"><?php echo esc_html($hero_main['title']); ?></span>
                <span class="hn-hero-subtitle"><?php echo esc_html(wp_trim_words($hero_description, 18, '...')); ?></span>
                <span class="hn-hero-meta">
                    <span><?php esc_html_e('New stories', 'hausanovels'); ?></span>
                    <span><?php esc_html_e('Start reading', 'hausanovels'); ?></span>
                </span>
            </span>
            <?php if (count($hero_books) > 1) : ?>
                <span class="hn-hero-mini-stack" aria-hidden="true">
                    <?php foreach (array_slice($hero_books, 1, 3) as $stack_index => $book) : ?>
                        <span class="hn-hero-mini-cover is-<?php echo esc_attr((string) ($stack_index + 1)); ?>">
                            <img src="<?php echo esc_url($book['cover']); ?>" alt="" loading="lazy" decoding="async">
                        </span>
                    <?php endforeach; ?>
                </span>
            <?php endif; ?>
        </a>
    </section>
<?php else : ?>
    <section class="hn-home-hero hn-home-hero-empty" aria-labelledby="hn-home-title">
        <div class="hn-hero-feature-copy">
            <span class="hn-hero-kicker"><?php esc_html_e('Hausanovels.ng', 'hausanovels'); ?></span>
            <h1 id="hn-home-title"><?php esc_html_e('Books', 'hausanovels'); ?></h1>
            <span class="hn-hero-subtitle"><?php esc_html_e('Fresh Hausa ebooks, featured stories, and latest chapters in one mobile library.', 'hausanovels'); ?></span>
        </div>
    </section>
<?php endif; ?>

<?php if ($continue_reading) : ?>
    <?php hausanovels_render_section(__('Continue Reading', 'hausanovels'), $continue_reading, 'continue-reading'); ?>
<?php endif; ?>

<?php hausanovels_render_section(__('Featured Books', 'hausanovels'), $featured, 'featured-books'); ?>

<?php hausanovels_render_section(__('Trending This Week', 'hausanovels'), $trending, 'trending'); ?>

<?php hausanovels_render_section(__('Latest Books', 'hausanovels'), $latest, 'latest-books'); ?>

<?php if ($genres) : ?>
    <section class="hn-section" id="categories">
        <div class="hn-section-head">
            <h2><?php esc_html_e('Categories', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-category-strip" tabindex="0" aria-label="<?php esc_attr_e('Book categories', 'hausanovels'); ?>">
            <?php foreach ($genres as $genre) : ?>
                <a href="<?php echo esc_url($genre['url']); ?>"><?php echo esc_html($genre['name']); ?></a>
            <?php endforeach; ?>
        </div>
    </section>

    <?php
    foreach ($genres as $genre) {
        hausanovels_render_section($genre['name'], hausanovels_books_for_genre($genre['slug']), sanitize_title($genre['slug']));
    }
    ?>
<?php endif; ?>


<?php

get_footer();
