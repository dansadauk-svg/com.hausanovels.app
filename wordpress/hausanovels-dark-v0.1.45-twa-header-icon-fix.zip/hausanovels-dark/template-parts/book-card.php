<?php
/**
 * Book card.
 *
 * @package HausanovelsDark
 */

$book = $args['book'] ?? array();

if (! $book) {
    return;
}

$book_id = absint($book['id'] ?? 0);
$badge_label = __('Open', 'hausanovels');
$badge_icon = 'book';
?>
<article class="hn-book-card is-open" data-book-id="<?php echo esc_attr((string) $book_id); ?>">
    <a href="<?php echo esc_url($book['permalink'] ?? '#'); ?>">
        <span class="hn-book-cover">
            <img src="<?php echo esc_url($book['cover']); ?>" alt="<?php echo esc_attr(sprintf(__('%s book cover', 'hausanovels'), $book['title'])); ?>" loading="lazy" decoding="async">
            <span class="hn-book-badge">
                <?php echo hausanovels_icon($badge_icon); ?>
                <span><?php echo esc_html($badge_label); ?></span>
            </span>
        </span>
        <span class="hn-book-title"><?php echo esc_html($book['title']); ?></span>
    </a>
</article>
