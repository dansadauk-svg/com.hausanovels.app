<?php
/**
 * Written reader reviews for book pages.
 *
 * @package HausanovelsDark
 */

if (post_password_required()) {
    return;
}
?>
<div class="hn-comments" id="comments">
    <?php
    global $wp_query;
    $visible_review_count = isset($wp_query->comments) && is_array($wp_query->comments) ? count($wp_query->comments) : 0;
    $review_status = sanitize_key(wp_unslash($_GET['review'] ?? ''));
    ?>

    <?php if (in_array($review_status, array('submitted', 'published'), true)) : ?>
        <p class="hn-review-notice" role="status">
            <?php echo esc_html('published' === $review_status ? __('Your review has been posted.', 'hausanovels') : __('Your review was received and is awaiting approval.', 'hausanovels')); ?>
        </p>
    <?php endif; ?>

    <?php if (have_comments()) : ?>
        <div class="hn-comments-head">
            <h3>
                <?php
                echo esc_html(
                    sprintf(
                        _n('%d reader review', '%d reader reviews', $visible_review_count, 'hausanovels'),
                        $visible_review_count
                    )
                );
                ?>
            </h3>
        </div>

        <ol class="hn-comment-list">
            <?php
            wp_list_comments(array(
                'style'       => 'ol',
                'avatar_size' => 44,
                'short_ping'  => true,
            ));
            ?>
        </ol>

        <?php the_comments_navigation(); ?>
    <?php else : ?>
        <div class="hn-no-reviews">
            <p><?php esc_html_e('No reviews yet. Be the first reader to share your thoughts about this book.', 'hausanovels'); ?></p>
        </div>
    <?php endif; ?>

    <?php if (comments_open() && is_user_logged_in()) : ?>
        <?php
        comment_form(array(
            'title_reply'          => __('Write a Review', 'hausanovels'),
            'title_reply_before'   => '<h3 id="reply-title" class="comment-reply-title">',
            'title_reply_after'    => '</h3>',
            'label_submit'         => __('Post Review', 'hausanovels'),
            'comment_field'        => '<p class="comment-form-comment"><label for="comment">' . esc_html__('Your review', 'hausanovels') . '</label><textarea id="comment" name="comment" cols="45" rows="5" maxlength="65525" required placeholder="' . esc_attr__('Share a helpful and respectful review.', 'hausanovels') . '"></textarea></p>',
            'class_submit'         => 'hn-review-submit',
            'logged_in_as'         => '<p class="logged-in-as">' . wp_kses_post(sprintf(__('Signed in as %s.', 'hausanovels'), '<strong>' . esc_html(wp_get_current_user()->display_name) . '</strong>')) . '</p>',
            'comment_notes_before' => '<p class="comment-notes">' . esc_html__('Tell other readers what you liked about the story. Star ratings are temporarily unavailable.', 'hausanovels') . '</p>',
            'must_log_in'          => '<p class="must-log-in">' . wp_kses_post(sprintf(__('Please <a href="%s">sign in</a> to post a review.', 'hausanovels'), esc_url(hausanovels_signin_url(get_permalink() . '#reviews')))) . '</p>',
        ));
        ?>
    <?php elseif (comments_open()) : ?>
        <p class="must-log-in">
            <?php
            echo wp_kses_post(
                sprintf(
                    __('Please <a href="%s">sign in</a> to write a review.', 'hausanovels'),
                    esc_url(hausanovels_signin_url(get_permalink() . '#reviews'))
                )
            );
            ?>
        </p>
    <?php else : ?>
        <p class="hn-comments-closed"><?php esc_html_e('Reader reviews are closed for this book.', 'hausanovels'); ?></p>
    <?php endif; ?>
</div>
