const HN_CACHE = 'hausanovels-static-v0.1.44';
const HN_STATIC_DESTINATIONS = new Set(['style', 'script', 'image', 'font']);

self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys
        .filter((key) => key.startsWith('hausanovels-') && key !== HN_CACHE)
        .map((key) => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') {
    return;
  }

  if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
    return;
  }

  const url = new URL(event.request.url);

  // Let the browser, WordPress, and the CDN handle HTML and API requests.
  // This avoids duplicate network requests and keeps private reader pages private.
  if (
    event.request.mode === 'navigate'
    || url.origin !== self.location.origin
    || !HN_STATIC_DESTINATIONS.has(event.request.destination)
  ) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) {
        return cached;
      }

      return fetch(event.request).then((response) => {
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(HN_CACHE).then((cache) => cache.put(event.request, copy));
        }

        return response;
      });
    })
  );
});
