<?php
/**
 * Search template.
 *
 * @package HausanovelsDark
 */

get_header();
?>
<section class="hn-hero">
    <div>
        <p class="hn-eyebrow"><?php esc_html_e('Search Hausa novels', 'hausanovels'); ?></p>
        <h1><?php echo esc_html(sprintf(__('Results for "%s"', 'hausanovels'), get_search_query())); ?></h1>
    </div>
</section>

<?php
if (have_posts()) :
    ?>
    <section class="hn-section">
        <div class="hn-section-head">
            <h2><?php esc_html_e('Books and stories found', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-book-row">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/book-card', null, array('book' => hausanovels_search_result_from_post(get_post())));
            endwhile;
            ?>
        </div>
    </section>
    <?php
else :
    ?>
    <section class="hn-seo-copy">
        <h2><?php esc_html_e('No result yet', 'hausanovels'); ?></h2>
        <p><?php esc_html_e('Try searches like complete Hausa novels, romantic Hausa novels, labaran soyayya, littafin Hausa, or latest Hausa novel.', 'hausanovels'); ?></p>
        <p><a class="hn-page-link" href="<?php echo esc_url(hausanovels_app_url('discover')); ?>"><?php esc_html_e('Open Discover', 'hausanovels'); ?></a></p>
    </section>
    <?php
endif;

get_footer();
