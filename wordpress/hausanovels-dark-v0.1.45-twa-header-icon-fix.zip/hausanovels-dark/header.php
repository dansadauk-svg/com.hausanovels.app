<?php
/**
 * Header template.
 *
 * @package HausanovelsDark
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="hn-skip" href="#content"><?php esc_html_e('Skip to content', 'hausanovels'); ?></a>

<?php
$hn_publisher_only = function_exists('hausanovels_is_publisher_only') && hausanovels_is_publisher_only();
$hn_logged_in = is_user_logged_in();
?>

<div class="hn-app-shell">
    <header class="hn-topbar">
        <?php echo hausanovels_header_icon(); ?>
        <?php echo hausanovels_header_title(); ?>

        <nav class="hn-desktop-nav" aria-label="<?php esc_attr_e('Primary menu', 'hausanovels'); ?>">
            <?php if ($hn_publisher_only) : ?>
                <a href="<?php echo esc_url(hausanovels_app_url('publisher')); ?>"><?php esc_html_e('Publisher', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(home_url('/publisher/books/')); ?>"><?php esc_html_e('Books', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(home_url('/publisher/chapters/')); ?>"><?php esc_html_e('Chapters', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(home_url('/publisher/earnings/')); ?>"><?php esc_html_e('Earnings', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(hausanovels_app_url('account')); ?>"><?php esc_html_e('Account', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(hausanovels_logout_url(home_url('/'))); ?>"><?php esc_html_e('Logout', 'hausanovels'); ?></a>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(home_url('/?s=')); ?>"><?php esc_html_e('Search', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(hausanovels_app_url('discover')); ?>"><?php esc_html_e('Discover', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(hausanovels_app_url('library')); ?>"><?php esc_html_e('Library', 'hausanovels'); ?></a>
                <?php if ($hn_logged_in) : ?>
                    <a href="<?php echo esc_url(hausanovels_app_url('reading')); ?>"><?php esc_html_e('Reading', 'hausanovels'); ?></a>
                <?php endif; ?>
                <?php if (function_exists('hausanovels_can_access_publisher') && hausanovels_can_access_publisher()) : ?>
                    <a href="<?php echo esc_url(hausanovels_app_url('publisher')); ?>"><?php esc_html_e('Publisher', 'hausanovels'); ?></a>
                <?php endif; ?>
                <a href="<?php echo esc_url(hausanovels_app_url('wallet')); ?>"><?php esc_html_e('Wallet', 'hausanovels'); ?></a>
                <a href="<?php echo esc_url(hausanovels_app_url('account')); ?>"><?php esc_html_e('Account', 'hausanovels'); ?></a>
                <?php if ($hn_logged_in) : ?>
                    <a href="<?php echo esc_url(hausanovels_logout_url(home_url('/'))); ?>"><?php esc_html_e('Logout', 'hausanovels'); ?></a>
                <?php else : ?>
                    <a href="<?php echo esc_url(hausanovels_register_url(hausanovels_app_url('account'), 'reader')); ?>"><?php esc_html_e('Register', 'hausanovels'); ?></a>
                <?php endif; ?>
            <?php endif; ?>
        </nav>

        <button class="hn-icon-button hn-menu-toggle" type="button" aria-controls="hn-drawer" aria-expanded="false" aria-label="<?php esc_attr_e('Open menu', 'hausanovels'); ?>">
            <?php echo hausanovels_icon('menu'); ?>
        </button>
    </header>

    <div class="hn-drawer-backdrop" data-drawer-close></div>
    <aside class="hn-drawer" id="hn-drawer" aria-hidden="true">
        <div class="hn-drawer-head">
            <?php echo hausanovels_logo(); ?>
            <button class="hn-icon-button" type="button" data-drawer-close aria-label="<?php esc_attr_e('Close menu', 'hausanovels'); ?>">
                <?php echo hausanovels_icon('close'); ?>
            </button>
        </div>
        <?php if (! $hn_publisher_only) : ?>
            <form class="hn-drawer-search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <label class="screen-reader-text" for="hn-drawer-search"><?php esc_html_e('Search books', 'hausanovels'); ?></label>
                <input id="hn-drawer-search" type="search" name="s" placeholder="<?php esc_attr_e('Search novels', 'hausanovels'); ?>" value="<?php echo esc_attr(get_search_query()); ?>">
                <button type="submit"><?php echo hausanovels_icon('search'); ?></button>
            </form>
        <?php endif; ?>
        <nav class="hn-drawer-nav" aria-label="<?php esc_attr_e('Mobile drawer menu', 'hausanovels'); ?>">
            <?php if ($hn_publisher_only) : ?>
                <a href="<?php echo esc_url(hausanovels_app_url('publisher')); ?>"><?php echo hausanovels_icon('grid'); ?> <span><?php esc_html_e('Publisher Dashboard', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(home_url('/publisher/books/')); ?>"><?php echo hausanovels_icon('book'); ?> <span><?php esc_html_e('My Books', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(home_url('/publisher/chapters/')); ?>"><?php echo hausanovels_icon('book'); ?> <span><?php esc_html_e('My Chapters', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(home_url('/publisher/earnings/')); ?>"><?php echo hausanovels_icon('wallet'); ?> <span><?php esc_html_e('Earnings', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(hausanovels_app_url('account')); ?>"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('My Account', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(hausanovels_logout_url(home_url('/'))); ?>"><?php echo hausanovels_icon('close'); ?> <span><?php esc_html_e('Logout', 'hausanovels'); ?></span></a>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php echo hausanovels_icon('home'); ?> <span><?php esc_html_e('Home', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(hausanovels_app_url('discover')); ?>"><?php echo hausanovels_icon('search'); ?> <span><?php esc_html_e('Discover Books', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(hausanovels_app_url('library')); ?>"><?php echo hausanovels_icon('book'); ?> <span><?php esc_html_e('Library', 'hausanovels'); ?></span></a>
                <?php if ($hn_logged_in) : ?>
                    <a href="<?php echo esc_url(hausanovels_app_url('reading')); ?>"><?php echo hausanovels_icon('book'); ?> <span><?php esc_html_e('Continue Reading', 'hausanovels'); ?></span></a>
                <?php endif; ?>
                <?php if (function_exists('hausanovels_can_access_publisher') && hausanovels_can_access_publisher()) : ?>
                    <a href="<?php echo esc_url(hausanovels_app_url('publisher')); ?>"><?php echo hausanovels_icon('grid'); ?> <span><?php esc_html_e('Publisher Dashboard', 'hausanovels'); ?></span></a>
                <?php endif; ?>
                <a href="<?php echo esc_url(home_url('/#categories')); ?>"><?php echo hausanovels_icon('grid'); ?> <span><?php esc_html_e('Categories', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(hausanovels_app_url('wallet')); ?>"><?php echo hausanovels_icon('wallet'); ?> <span><?php esc_html_e('Wallet & Coins', 'hausanovels'); ?></span></a>
                <a href="<?php echo esc_url(hausanovels_app_url('account')); ?>"><?php echo hausanovels_icon('user'); ?> <span><?php echo esc_html($hn_logged_in ? __('My Account', 'hausanovels') : __('Sign In', 'hausanovels')); ?></span></a>
                <?php if ($hn_logged_in) : ?>
                    <a href="<?php echo esc_url(hausanovels_logout_url(home_url('/'))); ?>"><?php echo hausanovels_icon('close'); ?> <span><?php esc_html_e('Logout', 'hausanovels'); ?></span></a>
                <?php else : ?>
                    <a href="<?php echo esc_url(hausanovels_register_url(hausanovels_app_url('account'), 'reader')); ?>"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('Register', 'hausanovels'); ?></span></a>
                <?php endif; ?>
            <?php endif; ?>
        </nav>
    </aside>

    <main id="content" class="hn-main">
