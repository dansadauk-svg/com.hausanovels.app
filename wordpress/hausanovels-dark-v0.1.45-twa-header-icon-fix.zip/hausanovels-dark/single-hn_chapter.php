<?php
/**
 * Single chapter reader template.
 *
 * @package HausanovelsDark
 */

get_header();

while (have_posts()) :
    the_post();

    $chapter_id = get_the_ID();
    $book_id = function_exists('hausanovels_get_chapter_parent_book_id')
        ? hausanovels_get_chapter_parent_book_id($chapter_id)
        : (function_exists('hn_get_chapter_book_id') ? hn_get_chapter_book_id($chapter_id) : (int) get_post_meta($chapter_id, '_hn_book_id', true));
    $book_title = $book_id ? get_the_title($book_id) : __('Hausa novel', 'hausanovels');
    $book_url = $book_id ? get_permalink($book_id) : home_url('/library/');
    $chapters = ($book_id && function_exists('hausanovels_get_book_chapters_fresh'))
        ? hausanovels_get_book_chapters_fresh($book_id)
        : (($book_id && function_exists('hn_get_book_chapters')) ? hn_get_book_chapters($book_id) : array());
    $previous_chapter = null;
    $next_chapter = null;
    $chapter_position = 1;
    $chapter_total = count($chapters);

    foreach ($chapters as $index => $chapter) {
        if ((int) $chapter->ID !== $chapter_id) {
            continue;
        }

        $chapter_position = $index + 1;
        $previous_chapter = $chapters[$index - 1] ?? null;
        $next_chapter = $chapters[$index + 1] ?? null;
        break;
    }

    ?>
    <article class="hn-reader-shell" data-hn-reader data-reader-theme="dark">
        <div class="hn-reader-toolbar" aria-label="<?php esc_attr_e('Reading controls', 'hausanovels'); ?>">
            <?php if ($previous_chapter) : ?>
                <a class="hn-reader-step" href="<?php echo esc_url(get_permalink($previous_chapter)); ?>" aria-label="<?php esc_attr_e('Previous chapter', 'hausanovels'); ?>">←</a>
            <?php else : ?>
                <span class="hn-reader-step is-disabled" aria-hidden="true">←</span>
            <?php endif; ?>

            <div class="hn-reader-theme-switch" role="group" aria-label="<?php esc_attr_e('Reader appearance', 'hausanovels'); ?>">
                <button type="button" data-reader-theme-value="dark" aria-pressed="true"><?php esc_html_e('Dark', 'hausanovels'); ?></button>
                <button type="button" data-reader-theme-value="light" aria-pressed="false"><?php esc_html_e('Light', 'hausanovels'); ?></button>
            </div>

            <?php if ($next_chapter) : ?>
                <a class="hn-reader-step" href="<?php echo esc_url(get_permalink($next_chapter)); ?>" aria-label="<?php esc_attr_e('Next chapter', 'hausanovels'); ?>">→</a>
            <?php else : ?>
                <span class="hn-reader-step is-disabled" aria-hidden="true">→</span>
            <?php endif; ?>
        </div>

        <div class="hn-reader-meta-strip">
            <a class="hn-reader-book-link" href="<?php echo esc_url($book_url); ?>">← <?php echo esc_html($book_title); ?></a>
            <span class="hn-reader-chapter-count">
                <?php
                echo esc_html(
                    $chapter_total > 0
                        ? sprintf(__('Chapter %1$d of %2$d', 'hausanovels'), $chapter_position, $chapter_total)
                        : __('Chapter', 'hausanovels')
                );
                ?>
            </span>
        </div>

        <div class="hn-reader-content">
            <?php the_content(); ?>
        </div>

        <nav class="hn-chapter-nav" aria-label="<?php esc_attr_e('Chapter navigation', 'hausanovels'); ?>">
            <?php if ($previous_chapter) : ?>
                <a href="<?php echo esc_url(get_permalink($previous_chapter)); ?>">
                    <span class="hn-chapter-nav-direction">← <?php esc_html_e('Previous', 'hausanovels'); ?></span>
                    <strong><?php echo esc_html(get_the_title($previous_chapter)); ?></strong>
                </a>
            <?php else : ?>
                <span class="is-disabled">
                    <span class="hn-chapter-nav-direction"><?php esc_html_e('Beginning', 'hausanovels'); ?></span>
                    <strong><?php esc_html_e('First Chapter', 'hausanovels'); ?></strong>
                </span>
            <?php endif; ?>

            <?php if ($next_chapter) : ?>
                <a href="<?php echo esc_url(get_permalink($next_chapter)); ?>">
                    <span class="hn-chapter-nav-direction"><?php esc_html_e('Next', 'hausanovels'); ?> →</span>
                    <strong><?php echo esc_html(get_the_title($next_chapter)); ?></strong>
                </a>
            <?php else : ?>
                <span class="is-disabled">
                    <span class="hn-chapter-nav-direction"><?php esc_html_e('Finished', 'hausanovels'); ?></span>
                    <strong><?php esc_html_e('Last Chapter', 'hausanovels'); ?></strong>
                </span>
            <?php endif; ?>
        </nav>
    </article>
    <?php
endwhile;

get_footer();
