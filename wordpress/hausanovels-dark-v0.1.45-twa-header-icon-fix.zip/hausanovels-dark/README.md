# Hausanovels Dark Theme

Lightweight dark WordPress theme for Hausanovels.ng.

## Built For

- Mobile-first Hausa novel reading experience
- PWA/TWA packaging for Android APK
- SEO traffic from Hausa novel searches
- Coin wallet, Paystack funding, and paid chapter unlock plugins
- Cloudflare R2 cover/file URLs from the core plugin
- Theme-owned app routes without manually creating WordPress pages
- Reader dashboard, bookmarks, and chapter progress from the reader plugin

## App Routes

The theme creates these routes automatically:

- `/library/`
- `/wallet/`
- `/account/`
- `/signin/`
- `/register/`
- `/discover/`

These routes are used by the header, drawer, and bottom app navigation. The wallet route displays Wallet/Paystack shortcodes when those plugins are active. Sign in and register routes keep readers on the frontend app instead of the WordPress admin login screen.

Book pages show published chapter rows to guests. Chapter buttons send logged-out visitors to the frontend sign-in/register flow, while paid chapters still show their lock and coin value.

Homepage book sections are capped at 10 books. The homepage now has a compact professional ebook hero, a Featured Books row before Trending and Latest Books, and no extra SEO copy block at the bottom. Continue Reading is only shown to logged-in readers, Trending is not shown in the fixed bottom menu, and logged-in users get visible Logout links from the account page and navigation. The Discover route provides search, categories, trending books, and latest books without requiring a separate SEO plugin route.

The register route supports two account types:

- Reader account: can use library, wallet, reading dashboard, and chapter unlocks.
- Publisher account: receives the `Hausa Novels Publisher` role and is routed to the publisher dashboard.

Publisher accounts see publisher menus only and are redirected away from reader routes such as Library, Wallet, Reading, book pages, and chapter pages. A writer who wants to read books should create a separate reader account with a different email address.

The Reader Dashboard plugin adds:

- `/reading/`
- `/bookmarks/`

The theme links to `/reading/` in the desktop and drawer menus only for logged-in readers when the plugin is active.

The Publisher Dashboard plugin adds:

- `/publisher/`
- `/publisher/books/`
- `/publisher/chapters/`
- `/publisher/earnings/`

The theme shows publisher navigation when the logged-in account has the publisher role.

The SEO & Discovery plugin adds:

- `/hn-sitemap.xml`

When the SEO plugin is active, the theme automatically disables its fallback meta/schema output to avoid duplicates.

## SEO Targets

The theme metadata and homepage copy target natural search terms such as:

- Hausa novels
- complete Hausa novels
- read Hausa novels online
- romantic Hausa novels
- latest Hausa novel
- Arewa novels
- labaran soyayya
- littafin Hausa
- littattafan soyayya
- Hausa love stories
- free Hausa novels
- paid Hausa chapters
- Hausa novel app
- Hausa ebooks
- Nigerian Hausa novels

## Expected Plugin Data

The core plugin should register:

- Custom post type: `hn_book`
- Custom post type: `hn_chapter`
- Taxonomy: `hn_genre`
- Book cover meta: `_hn_cover_url`
- Chapter premium flag: `_hn_is_premium`
- Chapter coin price meta: `_hn_coin_price`
- Weekly reads meta: `_hn_weekly_reads`
- Featured book meta: `_hn_is_featured` set to `1` for curated homepage features. Legacy `_hn_featured` values are also supported.
- Chapter parent meta: `_hn_book_id`
- Chapter parent fallback: WordPress `post_parent`

When the core book post type is not available, the theme shows sample fallback books for design preview. When the core book post type is active, public catalog pages show the real published catalog only.

The service worker caches only versioned same-origin static files. HTML, API, account, wallet, and chapter access requests remain under WordPress and CDN control. Public catalogue pages support page/CDN caching, while signed-in and private reader pages send no-cache headers.

Version 0.1.25 adds fresh chapter queries and clears parent-book chapter cache keys when chapters are saved, published, trashed, restored, or deleted.

Version 0.1.27 makes frontend reader/publisher sign-ins persistent by default. The sign-in form always sends rememberme, frontend login requests force a persistent auth cookie, and remembered auth cookies are extended to one year while logout still signs the user out normally.


Version 0.1.28 removes the WordPress admin bar/header for normal reader and publisher accounts on the frontend, redirects non-admin users away from `/wp-admin/` to the correct app page, and keeps the WordPress dashboard visible only for administrators.


Version 0.1.30 fixes homepage catalogue sections. Trending This Week now includes only books with `_hn_weekly_reads` above `0`, so it no longer duplicates Latest Books when no trending score exists. Empty categories and empty book rows are hidden automatically. The Categories strip now lists only genres attached to published books.

Version 0.1.31 restores Trending This Week with automatic weekly popularity data from Hausanovels Core 0.1.7. The chapter reader now has clearer previous and next navigation, chapter progress, and persistent light and dark reading modes. Book cards and book pages display ratings, while book pages include reader reviews and a rating form.

Version 0.1.33 makes the mobile chapter reader compact. The top controls sit directly below the app header, while the small Previous and Next controls sit directly above the fixed bottom menu. It also removes repeated service-worker refresh requests, stops clearing the PWA cache on every page load, allows public catalogue pages to use page/CDN caching, caches catalogue queries briefly, and replaces broad cache purges with targeted post purges.

## Version 0.1.33

- Removed oversized introductory text from Account, Wallet, Discover, and Library app pages.
- Reduced top spacing on those utility pages.
- Added a clear review-submission confirmation message.
- Returned readers to the Ratings and Reviews section after posting.
- Replaced full catalogue cache clearing during comments with a lightweight book cache refresh.


## Version 0.1.34

- Removes the compulsory written-review requirement.
- Allows signed-in readers to submit a star rating without typing a review.
- Adds clear inline validation when neither a rating nor a review is supplied.
- Shows a confirmation after a star-only rating is saved.

## Version 0.1.35

- Standalone star rating form and separate written review form.
- Google Sign-In button integration when the Google Sign-In plugin is active.
- Android app chapter reader uses the same mobile viewport and spacing as the website.


## Version: 0.1.37

- Repairs the default Page template so normal pages no longer contain nested main elements.
- Adds defensive mobile rules for forms, tables, plugin panels, media, and long text.
- Redesigns single book pages with a compact mobile hero, author and category data, first chapter action, optimized chapter list, About section, and responsive reviews.
- Reuses the Core chapter query and passes the loaded chapters into the list renderer to avoid duplicate book-page queries.

## Version 0.1.37

- Packages the theme inside the permanent `hausanovels-dark` directory so manual uploads replace the installed theme instead of creating another theme.
- Removes the Continue Reading dashboard from the Account page. Reading history remains available from Library/Reading routes.
- Keeps the wallet route compatible with the Paystack Funding card layout.


## Version 0.1.38

- Places the Buy Coins section before wallet balance and transaction history.
- Shows a clear star rating, average, and rating count on every homepage, Library, Discover, category, and archive book card.
- Shows the featured book rating in the homepage hero.
- Keeps the existing theme directory slug `hausanovels-dark` so WordPress upgrades the active theme instead of installing a duplicate.

## Version 0.1.39

- Removes the large chapter title and chapter bookmark block from reader pages.
- Keeps only a compact back-to-book link, chapter position and progress indicator.
- Works with the Core 0.1.15 database-backed rating system.


## Version 0.1.41

- Removes the chapter progress bar from chapter reader pages.


## Version 0.1.41

- Detects the Android app with the secure `hn_android_app=1` cookie set by Android source v1.3.0.
- Reduces only the in-app mobile header height, icon size, title size, and spacing.
- Removes duplicated safe-area padding from the app header while leaving normal Chrome/mobile-browser layout unchanged.
- Keeps the chapter reader toolbar attached to the corrected app header height.

## Version 0.1.42

- Temporarily removes every star-rating form and rating display from book cards, homepage, Library, Discover, and book pages.
- Keeps written reader reviews available.
- Rebuilds the Account page as a compact app-style profile, wallet summary, and action menu without Continue Reading.
- Adds unified responsive styling for Wallet, Paystack, Reader, Publisher, Revenue, Discovery, authentication, and standard WordPress pages.
- Keeps two professional coin-package cards per row on mobile and four on wider screens.

## Version 0.1.43

- Adds the new professional HausaNovels ebook icon throughout the theme.
- Uses optimized transparent icon assets for the header, favicon, PWA manifest, Apple touch icon, social fallback image, and mobile app branding.
- Adds a compact icon-and-wordmark lockup to the mobile drawer.
- Updates the service-worker cache version so returning users receive the new branding.



## Version 0.1.45

- Defers manifest and service-worker output to the dedicated HausaNovels PWA & TWA plugin when active.
- Renders the wallet in the order: balance, buy coins, transaction history.
- Adds a TWA body class for small app-only spacing adjustments without changing Chrome mobile layout.


## 0.1.45

- Keeps the TWA header at the same visual height as mobile Chrome.
- Prevents an old WebView cookie from applying WebView-only header sizing inside the TWA.
- Uses contain sizing and a small safe inset so the brand icon is not cropped.
