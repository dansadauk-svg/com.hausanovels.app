<?php
/**
 * Hausanovels Dark theme functions.
 *
 * @package HausanovelsDark
 */

if (! defined('ABSPATH')) {
    exit;
}

define('HAUSANOVELS_THEME_VERSION', '0.1.45');

function hausanovels_setup(): void
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('custom-logo', array(
        'height'      => 160,
        'width'       => 560,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    add_image_size('hausanovels-cover', 420, 630, true);

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'hausanovels'),
        'drawer'  => __('Mobile Drawer Menu', 'hausanovels'),
    ));
}
add_action('after_setup_theme', 'hausanovels_setup');

function hausanovels_assets(): void
{
    wp_enqueue_style('hausanovels-style', get_stylesheet_uri(), array(), HAUSANOVELS_THEME_VERSION);
    wp_enqueue_script('hausanovels-theme', get_template_directory_uri() . '/assets/js/theme.js', array(), HAUSANOVELS_THEME_VERSION, true);

    if (is_singular('hn_book') && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'hausanovels_assets');


function hausanovels_native_app_body_class(array $classes): array
{
    $app_page = sanitize_key((string) get_query_var('hn_app_page'));
    if ('' !== $app_page) {
        $classes[] = 'hn-app-page';
        $classes[] = 'hn-app-page-' . sanitize_html_class($app_page);
    }

    if (is_singular('hn_book')) {
        $classes[] = 'hn-view-book';
    } elseif (is_singular('hn_chapter')) {
        $classes[] = 'hn-view-chapter';
    } elseif (is_post_type_archive('hn_book') || is_tax('hn_genre')) {
        $classes[] = 'hn-view-catalogue';
    }

    $user_agent = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''));
    $app_cookie = sanitize_text_field(wp_unslash($_COOKIE['hn_android_app'] ?? ''));
    $twa_cookie = sanitize_text_field(wp_unslash($_COOKIE['hn_twa'] ?? ''));
    $is_twa = '1' === $twa_cookie || (function_exists('hn_pwa_is_twa_request') && hn_pwa_is_twa_request());

    if ($is_twa) {
        $classes[] = 'hn-twa-app';
    } elseif ('1' === $app_cookie || false !== stripos($user_agent, 'HausaNovelsApp/')) {
        // The TWA uses Chrome rendering and must not inherit old WebView-only sizing.
        $classes[] = 'hn-native-app';
    }

    return array_values(array_unique($classes));
}
add_filter('body_class', 'hausanovels_native_app_body_class');

function hausanovels_register_app_routes(): void
{
    add_rewrite_rule('^library/?$', 'index.php?hn_app_page=library', 'top');
    add_rewrite_rule('^account/?$', 'index.php?hn_app_page=account', 'top');
    add_rewrite_rule('^wallet/?$', 'index.php?hn_app_page=wallet', 'top');
    add_rewrite_rule('^signin/?$', 'index.php?hn_app_page=signin', 'top');
    add_rewrite_rule('^register/?$', 'index.php?hn_app_page=register', 'top');
    add_rewrite_rule('^forgot-password/?$', 'index.php?hn_app_page=forgot-password', 'top');
    add_rewrite_rule('^reset-password/?$', 'index.php?hn_app_page=reset-password', 'top');
    add_rewrite_rule('^discover/?$', 'index.php?hn_app_page=discover', 'top');
}
add_action('init', 'hausanovels_register_app_routes');

function hausanovels_query_vars(array $vars): array
{
    $vars[] = 'hn_app_page';
    return $vars;
}
add_filter('query_vars', 'hausanovels_query_vars');

function hausanovels_flush_routes(): void
{
    hausanovels_register_app_routes();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'hausanovels_flush_routes');

function hausanovels_maybe_flush_routes(): void
{
    $stored_version = (string) get_option('hausanovels_theme_routes_version', '');

    if (HAUSANOVELS_THEME_VERSION === $stored_version) {
        return;
    }

    hausanovels_register_app_routes();
    flush_rewrite_rules(false);
    update_option('hausanovels_theme_routes_version', HAUSANOVELS_THEME_VERSION);
}
add_action('init', 'hausanovels_maybe_flush_routes', 20);

function hausanovels_app_url(string $page): string
{
    $routes = array(
        'library'   => '/library/',
        'account'   => '/account/',
        'wallet'    => '/wallet/',
        'signin'    => '/signin/',
        'register'  => '/register/',
        'forgot-password' => '/forgot-password/',
        'reset-password'  => '/reset-password/',
        'reading'   => '/reading/',
        'bookmarks' => '/bookmarks/',
        'publisher' => '/publisher/',
        'discover'  => '/discover/',
    );

    return home_url($routes[$page] ?? '/');
}

function hausanovels_clean_redirect_url(string $redirect = ''): string
{
    $fallback = hausanovels_app_url('account');
    $redirect = '' !== trim($redirect) ? $redirect : $fallback;

    return wp_validate_redirect($redirect, $fallback);
}

function hausanovels_signin_url(string $redirect = ''): string
{
    $url = hausanovels_app_url('signin');

    if ('' !== trim($redirect)) {
        $url = add_query_arg('redirect_to', hausanovels_clean_redirect_url($redirect), $url);
    }

    return $url;
}

function hausanovels_register_url(string $redirect = '', string $account_type = ''): string
{
    $url = hausanovels_app_url('register');

    if ('' !== trim($redirect)) {
        $url = add_query_arg('redirect_to', hausanovels_clean_redirect_url($redirect), $url);
    }

    $account_type = sanitize_key($account_type);
    if (in_array($account_type, array('reader', 'publisher'), true)) {
        $url = add_query_arg('account_type', $account_type, $url);
    }

    return $url;
}


function hausanovels_forgot_password_url(string $redirect = ''): string
{
    $url = hausanovels_app_url('forgot-password');

    if ('' !== trim($redirect)) {
        $url = add_query_arg('redirect_to', hausanovels_clean_redirect_url($redirect), $url);
    }

    return $url;
}

function hausanovels_reset_password_url(string $key = '', string $login = ''): string
{
    $url = hausanovels_app_url('reset-password');

    if ('' !== trim($key) && '' !== trim($login)) {
        $url = add_query_arg(array(
            'key'   => $key,
            'login' => $login,
        ), $url);
    }

    return $url;
}

function hausanovels_filter_lostpassword_url(string $lostpassword_url, string $redirect = ''): string
{
    return hausanovels_forgot_password_url($redirect);
}
add_filter('lostpassword_url', 'hausanovels_filter_lostpassword_url', 10, 2);

function hausanovels_redirect_wp_password_screens(): void
{
    $action = sanitize_key(wp_unslash($_REQUEST['action'] ?? ''));

    if ('lostpassword' === $action && 'POST' !== strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? ''))) {
        $redirect = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : '';
        wp_safe_redirect(hausanovels_forgot_password_url($redirect));
        exit;
    }

    if (in_array($action, array('rp', 'resetpass'), true) && 'POST' !== strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? ''))) {
        $key = sanitize_text_field(wp_unslash($_GET['key'] ?? ''));
        $login = sanitize_text_field(wp_unslash($_GET['login'] ?? ''));
        wp_safe_redirect(hausanovels_reset_password_url($key, $login));
        exit;
    }
}
add_action('login_init', 'hausanovels_redirect_wp_password_screens', 0);

function hausanovels_password_reset_email_message(string $message, string $key = '', string $user_login = '', $user_data = null): string
{
    $site_name = wp_specialchars_decode((string) get_option('blogname'), ENT_QUOTES);
    $reset_url = hausanovels_reset_password_url($key, $user_login);

    return sprintf(
        /* translators: 1: site name, 2: reset password URL */
        __('Someone requested a password reset for your %1$s account.\n\nTo choose a new password, open this secure link:\n%2$s\n\nIf you did not request this, you can ignore this email.', 'hausanovels'),
        $site_name,
        $reset_url
    );
}
add_filter('retrieve_password_message', 'hausanovels_password_reset_email_message', 10, 4);

function hausanovels_password_reset_email_title(string $title, string $user_login = '', $user_data = null): string
{
    $site_name = wp_specialchars_decode((string) get_option('blogname'), ENT_QUOTES);
    return sprintf(__('Reset your %s password', 'hausanovels'), $site_name);
}
add_filter('retrieve_password_title', 'hausanovels_password_reset_email_title', 10, 3);

function hausanovels_logout_url(string $redirect = ''): string
{
    return wp_logout_url(hausanovels_clean_redirect_url($redirect ?: home_url('/')));
}

function hausanovels_filter_login_url(string $login_url, string $redirect = '', bool $force_reauth = false): string
{
    $url = hausanovels_signin_url($redirect);

    if ($force_reauth) {
        $url = add_query_arg('reauth', '1', $url);
    }

    return $url;
}
add_filter('login_url', 'hausanovels_filter_login_url', 10, 3);

function hausanovels_filter_register_url(string $register_url): string
{
    return hausanovels_register_url();
}
add_filter('register_url', 'hausanovels_filter_register_url');

/**
 * Keep frontend readers signed in for a long period by default.
 * Users are still signed out immediately when they tap Logout.
 */
function hausanovels_force_frontend_rememberme(): void
{
    if ('POST' !== strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) || empty($_POST['hn_frontend_login'])) {
        return;
    }

    $_POST['rememberme'] = 'forever';
}
add_action('login_init', 'hausanovels_force_frontend_rememberme', 1);

function hausanovels_auth_cookie_expiration(int $expiration, int $user_id, bool $remember): int
{
    $is_frontend_login = ! empty($_POST['hn_frontend_login']);
    $is_frontend_register = isset($_POST['hn_auth_action']) && 'register' === sanitize_key(wp_unslash($_POST['hn_auth_action']));

    if ($remember || $is_frontend_login || $is_frontend_register) {
        return YEAR_IN_SECONDS;
    }

    return $expiration;
}
add_filter('auth_cookie_expiration', 'hausanovels_auth_cookie_expiration', 10, 3);


function hausanovels_ensure_publisher_role(): void
{
    $role = get_role('hn_publisher');

    if (! $role) {
        add_role('hn_publisher', __('Hausa Novels Publisher', 'hausanovels'), array(
            'read'         => true,
            'edit_posts'   => true,
            'upload_files' => true,
        ));
        return;
    }

    $role->add_cap('read');
    $role->add_cap('edit_posts');
    $role->add_cap('upload_files');
}
add_action('init', 'hausanovels_ensure_publisher_role', 5);

function hausanovels_user_has_role(int $user_id, string $role): bool
{
    $user = $user_id > 0 ? get_userdata($user_id) : false;

    if (! $user instanceof WP_User) {
        return false;
    }

    return in_array($role, (array) $user->roles, true);
}

function hausanovels_is_publisher_only(int $user_id = 0): bool
{
    $user_id = $user_id > 0 ? $user_id : get_current_user_id();

    if ($user_id <= 0 || user_can($user_id, 'manage_options')) {
        return false;
    }

    $user = get_userdata($user_id);

    if (! $user instanceof WP_User) {
        return false;
    }

    return in_array('hn_publisher', (array) $user->roles, true);
}

function hausanovels_can_access_publisher(int $user_id = 0): bool
{
    $user_id = $user_id > 0 ? $user_id : get_current_user_id();

    if ($user_id <= 0) {
        return false;
    }

    return user_can($user_id, 'manage_options') || hausanovels_user_has_role($user_id, 'hn_publisher');
}

function hausanovels_account_home_for_user(int $user_id = 0): string
{
    return hausanovels_is_publisher_only($user_id) ? hausanovels_app_url('publisher') : hausanovels_app_url('account');
}

function hausanovels_auth_redirect_for_user(int $user_id, string $redirect = ''): string
{
    if (hausanovels_is_publisher_only($user_id)) {
        return hausanovels_app_url('publisher');
    }

    return hausanovels_clean_redirect_url($redirect);
}

function hausanovels_is_app_page(string $page): bool
{
    return get_query_var('hn_app_page') === $page;
}

function hausanovels_add_featured_book_meta_box(): void
{
    add_meta_box(
        'hausanovels_featured_book',
        __('Featured Book', 'hausanovels'),
        'hausanovels_render_featured_book_meta_box',
        'hn_book',
        'side',
        'high'
    );
}
add_action('add_meta_boxes_hn_book', 'hausanovels_add_featured_book_meta_box');

function hausanovels_render_featured_book_meta_box(WP_Post $post): void
{
    wp_nonce_field('hausanovels_save_featured_book', 'hausanovels_featured_book_nonce');
    $is_featured = '1' === (string) get_post_meta($post->ID, '_hn_featured', true);
    ?>
    <p>
        <label>
            <input type="checkbox" name="hn_featured_book" value="1" <?php checked($is_featured); ?>>
            <?php esc_html_e('Show this book in Featured Books on the homepage.', 'hausanovels'); ?>
        </label>
    </p>
    <?php
}

function hausanovels_save_featured_book_meta(int $post_id): void
{
    if (! isset($_POST['hausanovels_featured_book_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hausanovels_featured_book_nonce'])), 'hausanovels_save_featured_book')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (! current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['hn_featured_book'])) {
        update_post_meta($post_id, '_hn_featured', '1');
        return;
    }

    delete_post_meta($post_id, '_hn_featured');
}
add_action('save_post_hn_book', 'hausanovels_save_featured_book_meta');

function hausanovels_is_reader_page(string $page = ''): bool
{
    $reader_page = (string) get_query_var('hn_reader_page');

    if ('' === $page) {
        return '' !== $reader_page;
    }

    return $reader_page === $page;
}

function hausanovels_is_publisher_page(): bool
{
    return '' !== (string) get_query_var('hn_publisher_page');
}

function hausanovels_render_app_page(): void
{
    $page = (string) get_query_var('hn_app_page');

    if (! in_array($page, array('library', 'account', 'wallet', 'signin', 'register', 'forgot-password', 'reset-password', 'discover'), true)) {
        return;
    }

    if (is_user_logged_in() && in_array($page, array('signin', 'register'), true)) {
        $redirect = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : hausanovels_account_home_for_user();
        wp_safe_redirect(hausanovels_auth_redirect_for_user(get_current_user_id(), $redirect));
        exit;
    }

    status_header(200);
    if (hausanovels_should_disable_page_cache($page)) {
        hausanovels_send_private_headers();
    }
    get_header();

    if ('library' === $page) {
        hausanovels_render_library_page();
    } elseif ('discover' === $page) {
        hausanovels_render_discover_page();
    } elseif ('account' === $page) {
        hausanovels_render_account_page();
    } elseif ('wallet' === $page) {
        hausanovels_render_wallet_page();
    } elseif ('signin' === $page) {
        hausanovels_render_signin_page();
    } elseif ('register' === $page) {
        hausanovels_render_register_page();
    } elseif ('forgot-password' === $page) {
        hausanovels_render_forgot_password_page();
    } elseif ('reset-password' === $page) {
        hausanovels_render_reset_password_page();
    }

    get_footer();
    exit;
}
add_action('template_redirect', 'hausanovels_render_app_page', 2);

function hausanovels_is_public_catalog_request(): bool
{
    if (is_admin()) {
        return false;
    }

    $app_page = (string) get_query_var('hn_app_page');

    return is_front_page()
        || is_home()
        || is_search()
        || is_post_type_archive('hn_book')
        || is_tax('hn_genre')
        || is_singular('hn_book')
        || in_array($app_page, array('library', 'discover'), true);
}

function hausanovels_should_disable_page_cache(string $app_page = ''): bool
{
    if (is_admin() || wp_doing_ajax()) {
        return false;
    }

    if (is_user_logged_in() || is_singular('hn_chapter')) {
        return true;
    }

    if ('' === $app_page) {
        $app_page = (string) get_query_var('hn_app_page');
    }

    return in_array($app_page, array(
        'account',
        'wallet',
        'signin',
        'register',
        'forgot-password',
        'reset-password',
        'reading',
        'bookmarks',
        'publisher',
    ), true);
}

function hausanovels_send_private_headers(): void
{
    if (headers_sent()) {
        return;
    }

    nocache_headers();
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
    header('Pragma: no-cache');
    header('Expires: Wed, 11 Jan 1984 05:00:00 GMT');
    header('X-Hausanovels-Version: ' . HAUSANOVELS_THEME_VERSION);
}

function hausanovels_private_page_nocache(): void
{
    if (hausanovels_should_disable_page_cache()) {
        hausanovels_send_private_headers();
    }
}
add_action('template_redirect', 'hausanovels_private_page_nocache', 1);

function hausanovels_content_version(): string
{
    $version = (string) get_option('hausanovels_content_version', '1');
    return '' !== $version ? $version : '1';
}

function hausanovels_touch_content_version(): void
{
    update_option('hausanovels_content_version', (string) time(), false);
}

function hausanovels_catalog_main_query(WP_Query $query): void
{
    if (is_admin() || ! $query->is_main_query()) {
        return;
    }

    if ($query->is_search()) {
        $query->set('post_type', array('hn_book', 'hn_chapter'));
        $query->set('post_status', 'publish');
    }

    if ($query->is_post_type_archive('hn_book') || $query->is_tax('hn_genre')) {
        $query->set('post_status', 'publish');
        $query->set('posts_per_page', 36);
        $query->set('orderby', 'date');
        $query->set('order', 'DESC');
    }
}
add_action('pre_get_posts', 'hausanovels_catalog_main_query');

function hausanovels_get_chapter_parent_book_id(int $chapter_id): int
{
    if ($chapter_id <= 0) {
        return 0;
    }

    if (function_exists('hn_get_chapter_book_id')) {
        $book_id = (int) hn_get_chapter_book_id($chapter_id);
        if ($book_id > 0) {
            return $book_id;
        }
    }

    $book_id = (int) get_post_meta($chapter_id, '_hn_book_id', true);
    if ($book_id > 0) {
        return $book_id;
    }

    $chapter = get_post($chapter_id);
    return ($chapter instanceof WP_Post && 'hn_book' === get_post_type($chapter->post_parent)) ? (int) $chapter->post_parent : 0;
}

function hausanovels_delete_chapter_cache_keys(int $book_id, int $chapter_id = 0): void
{
    $keys = array(
        'hn_book_chapters_' . $book_id,
        'hn_chapters_' . $book_id,
        'hn_access_chapter_list_' . $book_id,
        'hausanovels_book_chapters_' . $book_id,
        'hausanovels_chapters_' . $book_id,
    );

    if ($chapter_id > 0) {
        $keys[] = 'hn_chapter_' . $chapter_id;
        $keys[] = 'hausanovels_chapter_' . $chapter_id;
    }

    foreach ($keys as $key) {
        delete_transient($key);
        wp_cache_delete($key);
        wp_cache_delete($key, 'posts');
        wp_cache_delete($key, 'post_meta');
        wp_cache_delete($key, 'hausanovels');
        wp_cache_delete($key, 'hn');
    }
}

function hausanovels_clear_catalog_caches(int $post_id = 0): void
{
    static $handled = array();

    if ($post_id > 0) {
        if (isset($handled[$post_id]) || wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
            return;
        }

        $post_type = get_post_type($post_id);
        if (! in_array($post_type, array('hn_book', 'hn_chapter'), true)) {
            return;
        }

        $handled[$post_id] = true;
        clean_post_cache($post_id);

        $book_id = 'hn_chapter' === $post_type ? hausanovels_get_chapter_parent_book_id($post_id) : $post_id;
        if ($book_id > 0) {
            clean_post_cache($book_id);
            hausanovels_delete_chapter_cache_keys($book_id, $post_id);
        }

        foreach (array_unique(array_filter(array($post_id, $book_id))) as $purge_post_id) {
            if (function_exists('w3tc_flush_post')) {
                w3tc_flush_post((int) $purge_post_id);
            }

            if (function_exists('rocket_clean_post')) {
                rocket_clean_post((int) $purge_post_id);
            }

            if (function_exists('wp_cache_post_change')) {
                wp_cache_post_change((int) $purge_post_id);
            }

            if (class_exists('LiteSpeed_Cache_API') && method_exists('LiteSpeed_Cache_API', 'purge_post')) {
                LiteSpeed_Cache_API::purge_post((int) $purge_post_id);
            }

            do_action('litespeed_purge_post', (int) $purge_post_id);
        }
    }

    hausanovels_touch_content_version();
}
add_action('save_post_hn_book', 'hausanovels_clear_catalog_caches', 99);
add_action('save_post_hn_chapter', 'hausanovels_clear_catalog_caches', 99);
add_action('trashed_post', 'hausanovels_clear_catalog_caches', 99);
add_action('deleted_post', 'hausanovels_clear_catalog_caches', 99);
add_action('untrashed_post', 'hausanovels_clear_catalog_caches', 99);
add_action('transition_post_status', static function (string $new_status, string $old_status, WP_Post $post): void {
    if ($new_status === $old_status || ! in_array($post->post_type, array('hn_book', 'hn_chapter'), true)) {
        return;
    }

    hausanovels_clear_catalog_caches((int) $post->ID);
}, 99, 3);
add_action('set_object_terms', static function ($object_id): void {
    hausanovels_clear_catalog_caches((int) $object_id);
}, 99);

function hausanovels_clear_review_cache(int $comment_id): void
{
    $comment = get_comment($comment_id);
    if (! $comment || 'hn_book' !== get_post_type((int) $comment->comment_post_ID)) {
        return;
    }

    // Review changes only affect the current book review list.
    // Avoid a full catalogue purge during a reader comment request.
    clean_post_cache((int) $comment->comment_post_ID);
}
add_action('comment_post', 'hausanovels_clear_review_cache', 99);
add_action('edit_comment', 'hausanovels_clear_review_cache', 99);
add_action('deleted_comment', static function (int $comment_id, WP_Comment $comment): void {
    if ('hn_book' === get_post_type((int) $comment->comment_post_ID)) {
        clean_post_cache((int) $comment->comment_post_ID);
    }
}, 99, 2);
add_action('transition_comment_status', static function (string $new_status, string $old_status, WP_Comment $comment): void {
    if ($new_status !== $old_status && 'hn_book' === get_post_type((int) $comment->comment_post_ID)) {
        clean_post_cache((int) $comment->comment_post_ID);
    }
}, 99, 3);


function hausanovels_review_post_redirect(string $location, WP_Comment $comment): string
{
    if ('hn_book' !== get_post_type((int) $comment->comment_post_ID)) {
        return $location;
    }

    $status = '1' === (string) $comment->comment_approved ? 'published' : 'submitted';

    return add_query_arg('review', $status, get_permalink((int) $comment->comment_post_ID)) . '#reviews';
}
add_filter('comment_post_redirect', 'hausanovels_review_post_redirect', 10, 2);


function hausanovels_handle_forgot_password_request(): void
{
    if (! isset($_POST['hn_auth_action']) || 'forgot_password' !== sanitize_key(wp_unslash($_POST['hn_auth_action']))) {
        return;
    }

    $forgot_url = hausanovels_forgot_password_url();

    if (! isset($_POST['hn_forgot_password_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hn_forgot_password_nonce'])), 'hn_frontend_forgot_password')) {
        wp_safe_redirect(add_query_arg('reset', 'security', $forgot_url));
        exit;
    }

    $login_or_email = trim((string) wp_unslash($_POST['user_login'] ?? ''));

    if ('' === $login_or_email) {
        wp_safe_redirect(add_query_arg('reset', 'missing', $forgot_url));
        exit;
    }

    $user = is_email($login_or_email)
        ? get_user_by('email', sanitize_email($login_or_email))
        : get_user_by('login', sanitize_user($login_or_email, true));

    if ($user instanceof WP_User) {
        $reset_key = get_password_reset_key($user);

        if (! is_wp_error($reset_key)) {
            $site_name = wp_specialchars_decode((string) get_option('blogname'), ENT_QUOTES);
            $reset_url = hausanovels_reset_password_url($reset_key, $user->user_login);
            $subject = sprintf(__('Reset your %s password', 'hausanovels'), $site_name);
            $message = sprintf(
                /* translators: 1: site name, 2: reset password URL */
                __('Someone requested a password reset for your %1$s account.\n\nChoose a new password here:\n%2$s\n\nIf you did not request this, you can ignore this email.', 'hausanovels'),
                $site_name,
                $reset_url
            );

            wp_mail($user->user_email, $subject, $message);
        }
    }

    wp_safe_redirect(add_query_arg('reset', 'sent', $forgot_url));
    exit;
}
add_action('template_redirect', 'hausanovels_handle_forgot_password_request', 1);

function hausanovels_handle_reset_password_request(): void
{
    if (! isset($_POST['hn_auth_action']) || 'reset_password' !== sanitize_key(wp_unslash($_POST['hn_auth_action']))) {
        return;
    }

    $key = sanitize_text_field(wp_unslash($_POST['key'] ?? ''));
    $login = sanitize_text_field(wp_unslash($_POST['login'] ?? ''));
    $reset_url = hausanovels_reset_password_url($key, $login);

    if (! isset($_POST['hn_reset_password_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hn_reset_password_nonce'])), 'hn_frontend_reset_password')) {
        wp_safe_redirect(add_query_arg('reset', 'security', $reset_url));
        exit;
    }

    $password = (string) wp_unslash($_POST['user_pass'] ?? '');
    $password_confirm = (string) wp_unslash($_POST['user_pass_confirm'] ?? '');

    if ('' === $key || '' === $login || '' === $password || '' === $password_confirm) {
        wp_safe_redirect(add_query_arg('reset', 'missing', $reset_url));
        exit;
    }

    if ($password !== $password_confirm) {
        wp_safe_redirect(add_query_arg('reset', 'mismatch', $reset_url));
        exit;
    }

    if (strlen($password) < 6) {
        wp_safe_redirect(add_query_arg('reset', 'password_short', $reset_url));
        exit;
    }

    $user = check_password_reset_key($key, $login);

    if (is_wp_error($user) || ! $user instanceof WP_User) {
        wp_safe_redirect(add_query_arg('reset', 'invalid', hausanovels_app_url('reset-password')));
        exit;
    }

    reset_password($user, $password);
    wp_set_current_user((int) $user->ID);
    wp_set_auth_cookie((int) $user->ID, true);
    do_action('wp_login', $user->user_login, $user);

    wp_safe_redirect(add_query_arg('password', 'changed', hausanovels_auth_redirect_for_user((int) $user->ID, hausanovels_app_url('account'))));
    exit;
}
add_action('template_redirect', 'hausanovels_handle_reset_password_request', 1);

function hausanovels_handle_register_request(): void
{
    if (! isset($_POST['hn_auth_action']) || 'register' !== sanitize_key(wp_unslash($_POST['hn_auth_action']))) {
        return;
    }

    $redirect = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : hausanovels_app_url('account');
    $redirect = hausanovels_clean_redirect_url($redirect);

    if (is_user_logged_in()) {
        wp_safe_redirect($redirect);
        exit;
    }

    if (! isset($_POST['hn_register_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hn_register_nonce'])), 'hn_frontend_register')) {
        wp_safe_redirect(add_query_arg('register', 'security', hausanovels_register_url($redirect)));
        exit;
    }

    $account_type = sanitize_key(wp_unslash($_POST['account_type'] ?? 'reader'));
    if (! in_array($account_type, array('reader', 'publisher'), true)) {
        $account_type = 'reader';
    }

    $register_url = hausanovels_register_url($redirect, $account_type);
    $username = sanitize_user(wp_unslash($_POST['user_login'] ?? ''), true);
    $email = sanitize_email(wp_unslash($_POST['user_email'] ?? ''));
    $password = (string) wp_unslash($_POST['user_pass'] ?? '');

    if ('' === $username || '' === $email || '' === $password) {
        wp_safe_redirect(add_query_arg('register', 'missing', $register_url));
        exit;
    }

    if (! is_email($email)) {
        wp_safe_redirect(add_query_arg('register', 'email', $register_url));
        exit;
    }

    if (username_exists($username)) {
        wp_safe_redirect(add_query_arg('register', 'username_exists', $register_url));
        exit;
    }

    if (email_exists($email)) {
        wp_safe_redirect(add_query_arg('register', 'email_exists', $register_url));
        exit;
    }

    if (strlen($password) < 6) {
        wp_safe_redirect(add_query_arg('register', 'password_short', $register_url));
        exit;
    }

    $user_id = wp_create_user($username, $password, $email);

    if (is_wp_error($user_id)) {
        wp_safe_redirect(add_query_arg('register', 'failed', $register_url));
        exit;
    }

    $user = get_user_by('id', (int) $user_id);

    if ($user instanceof WP_User) {
        if ('publisher' === $account_type) {
            hausanovels_ensure_publisher_role();
            $user->set_role('hn_publisher');
            update_user_meta((int) $user_id, '_hn_account_type', 'publisher');
            $redirect = hausanovels_app_url('publisher');
        } else {
            $user->set_role('subscriber');
            update_user_meta((int) $user_id, '_hn_account_type', 'reader');
            $redirect = hausanovels_clean_redirect_url($redirect);
        }

        wp_set_current_user((int) $user_id);
        wp_set_auth_cookie((int) $user_id, true);
        do_action('wp_login', $user->user_login, $user);
    }

    wp_safe_redirect($redirect);
    exit;
}
add_action('template_redirect', 'hausanovels_handle_register_request', 1);

function hausanovels_frontend_login_failed(string $username): void
{
    if (empty($_POST['hn_frontend_login'])) {
        return;
    }

    $redirect = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : hausanovels_app_url('account');
    wp_safe_redirect(add_query_arg('login', 'failed', hausanovels_signin_url($redirect)));
    exit;
}
add_action('wp_login_failed', 'hausanovels_frontend_login_failed');

function hausanovels_frontend_empty_login($user, string $username, string $password)
{
    if (empty($_POST['hn_frontend_login']) || ('' !== $username && '' !== $password)) {
        return $user;
    }

    $redirect = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : hausanovels_app_url('account');
    wp_safe_redirect(add_query_arg('login', 'empty', hausanovels_signin_url($redirect)));
    exit;
}
add_filter('authenticate', 'hausanovels_frontend_empty_login', 30, 3);

function hausanovels_frontend_login_redirect(string $redirect_to, string $requested_redirect_to, $user): string
{
    if (! $user instanceof WP_User) {
        return $redirect_to;
    }

    if (user_can((int) $user->ID, 'manage_options')) {
        return $redirect_to;
    }

    if (hausanovels_is_publisher_only((int) $user->ID)) {
        return hausanovels_app_url('publisher');
    }

    if (! empty($_POST['hn_frontend_login'])) {
        return hausanovels_clean_redirect_url($requested_redirect_to ?: $redirect_to ?: hausanovels_app_url('account'));
    }

    $target = $requested_redirect_to ?: $redirect_to;
    if ('' === trim((string) $target) || false !== strpos((string) $target, 'wp-admin')) {
        return hausanovels_app_url('account');
    }

    return hausanovels_clean_redirect_url((string) $target);
}
add_filter('login_redirect', 'hausanovels_frontend_login_redirect', 10, 3);

function hausanovels_redirect_publisher_only_reader_pages(): void
{
    if (! is_user_logged_in() || ! hausanovels_is_publisher_only()) {
        return;
    }

    $app_page = (string) get_query_var('hn_app_page');
    $reader_page = (string) get_query_var('hn_reader_page');
    $blocked_app_pages = array('library', 'wallet');

    if (
        in_array($app_page, $blocked_app_pages, true)
        || '' !== $reader_page
        || is_singular(array('hn_book', 'hn_chapter'))
        || is_post_type_archive('hn_book')
        || is_tax('hn_genre')
    ) {
        wp_safe_redirect(hausanovels_app_url('publisher'));
        exit;
    }
}
add_action('template_redirect', 'hausanovels_redirect_publisher_only_reader_pages', 0);

function hausanovels_is_frontend_app_user(int $user_id = 0): bool
{
    $user_id = $user_id > 0 ? $user_id : get_current_user_id();

    if ($user_id <= 0) {
        return false;
    }

    return ! user_can($user_id, 'manage_options');
}

function hausanovels_redirect_frontend_roles_from_admin(): void
{
    if (wp_doing_ajax() || ! is_user_logged_in() || current_user_can('manage_options')) {
        return;
    }

    $redirect = hausanovels_is_publisher_only() ? hausanovels_app_url('publisher') : hausanovels_app_url('account');
    wp_safe_redirect($redirect);
    exit;
}
add_action('admin_init', 'hausanovels_redirect_frontend_roles_from_admin');

function hausanovels_hide_admin_bar_for_frontend_roles(bool $show): bool
{
    if (is_user_logged_in() && hausanovels_is_frontend_app_user()) {
        return false;
    }

    return $show;
}
add_filter('show_admin_bar', 'hausanovels_hide_admin_bar_for_frontend_roles', 100);

function hausanovels_remove_admin_bar_body_class(array $classes): array
{
    if (is_user_logged_in() && hausanovels_is_frontend_app_user()) {
        $classes = array_diff($classes, array('admin-bar'));
    }

    return array_values($classes);
}
add_filter('body_class', 'hausanovels_remove_admin_bar_body_class', 100);

function hausanovels_force_frontend_without_admin_bar(): void
{
    if (! is_user_logged_in() || ! hausanovels_is_frontend_app_user()) {
        return;
    }

    echo '<style id="hausanovels-no-wp-adminbar">html{margin-top:0!important;}body.admin-bar{margin-top:0!important;}#wpadminbar{display:none!important;}</style>' . "\n";
}
add_action('wp_head', 'hausanovels_force_frontend_without_admin_bar', 1);

function hausanovels_render_signin_page(): void
{
    $redirect = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : hausanovels_app_url('account');
    $redirect = hausanovels_clean_redirect_url($redirect);
    $login_status = sanitize_key(wp_unslash($_GET['login'] ?? ''));
    $reader_register_url = hausanovels_register_url($redirect, 'reader');
    $publisher_register_url = hausanovels_register_url(hausanovels_app_url('publisher'), 'publisher');
    ?>
    <section class="hn-hero hn-compact-hero">
        <div>
            <p class="hn-eyebrow"><?php esc_html_e('Sign in', 'hausanovels'); ?></p>
            <h1><?php esc_html_e('Sign in as a reader or publisher.', 'hausanovels'); ?></h1>
        </div>
    </section>

    <section class="hn-section">
        <div class="hn-auth-card">
            <?php if ('failed' === $login_status || 'empty' === $login_status) : ?>
                <p class="hn-auth-alert"><?php echo esc_html('empty' === $login_status ? __('Please enter your username/email and password.', 'hausanovels') : __('The username/email or password is not correct. Please try again.', 'hausanovels')); ?></p>
            <?php endif; ?>
            <?php if (shortcode_exists('hn_google_signin')) : ?>
                <?php echo do_shortcode('[hn_google_signin redirect_to="' . esc_url($redirect) . '"]'); ?>
                <div class="hn-auth-divider"><span><?php esc_html_e('or use your password', 'hausanovels'); ?></span></div>
            <?php endif; ?>
            <form class="hn-auth-form" method="post" action="<?php echo esc_url(site_url('wp-login.php', 'login_post')); ?>">
                <input type="hidden" name="hn_frontend_login" value="1">
                <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect); ?>">
                <p class="hn-auth-field">
                    <label for="hn-login-user"><?php esc_html_e('Username or Email', 'hausanovels'); ?></label>
                    <input id="hn-login-user" type="text" name="log" autocomplete="username" required>
                </p>
                <p class="hn-auth-field">
                    <label for="hn-login-password"><?php esc_html_e('Password', 'hausanovels'); ?></label>
                    <input id="hn-login-password" type="password" name="pwd" autocomplete="current-password" required>
                </p>
                <input type="hidden" name="rememberme" value="forever">
                <p class="hn-auth-note"><?php esc_html_e('You will stay signed in on this device unless you logout.', 'hausanovels'); ?></p>
                <div class="hn-page-actions">
                    <button class="hn-hero-action" type="submit"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('Sign In', 'hausanovels'); ?></span></button>
                    <a class="hn-page-link" href="<?php echo esc_url($reader_register_url); ?>"><?php esc_html_e('Register as Reader', 'hausanovels'); ?></a>
                    <a class="hn-page-link" href="<?php echo esc_url($publisher_register_url); ?>"><?php esc_html_e('Register as Publisher', 'hausanovels'); ?></a>
                    <a class="hn-page-link" href="<?php echo esc_url(hausanovels_forgot_password_url($redirect)); ?>"><?php esc_html_e('Forgot Password?', 'hausanovels'); ?></a>
                </div>
            </form>
        </div>
    </section>
    <?php
}


function hausanovels_render_forgot_password_page(): void
{
    $reset_status = sanitize_key(wp_unslash($_GET['reset'] ?? ''));
    $messages = array(
        'sent'     => __('If an account exists with that username or email, a reset link has been sent.', 'hausanovels'),
        'missing'  => __('Please enter your username or email address.', 'hausanovels'),
        'security' => __('Security check failed. Please try again.', 'hausanovels'),
    );
    ?>
    <section class="hn-hero hn-compact-hero">
        <div>
            <p class="hn-eyebrow"><?php esc_html_e('Forgot password', 'hausanovels'); ?></p>
            <h1><?php esc_html_e('Reset your password without leaving the app.', 'hausanovels'); ?></h1>
        </div>
    </section>

    <section class="hn-section">
        <div class="hn-auth-card">
            <?php if (isset($messages[$reset_status])) : ?>
                <p class="hn-auth-alert <?php echo esc_attr('sent' === $reset_status ? 'hn-auth-success' : ''); ?>"><?php echo esc_html($messages[$reset_status]); ?></p>
            <?php endif; ?>
            <form class="hn-auth-form" method="post">
                <?php wp_nonce_field('hn_frontend_forgot_password', 'hn_forgot_password_nonce'); ?>
                <input type="hidden" name="hn_auth_action" value="forgot_password">
                <p class="hn-auth-field">
                    <label for="hn-forgot-user"><?php esc_html_e('Username or Email', 'hausanovels'); ?></label>
                    <input id="hn-forgot-user" type="text" name="user_login" autocomplete="username" required>
                </p>
                <p class="hn-auth-note"><?php esc_html_e('We will email you a secure link. The link opens a frontend page where you can choose a new password.', 'hausanovels'); ?></p>
                <div class="hn-page-actions">
                    <button class="hn-hero-action" type="submit"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('Send Reset Link', 'hausanovels'); ?></span></button>
                    <a class="hn-page-link" href="<?php echo esc_url(hausanovels_signin_url()); ?>"><?php esc_html_e('Back to Sign In', 'hausanovels'); ?></a>
                </div>
            </form>
        </div>
    </section>
    <?php
}

function hausanovels_render_reset_password_page(): void
{
    $key = sanitize_text_field(wp_unslash($_GET['key'] ?? ''));
    $login = sanitize_text_field(wp_unslash($_GET['login'] ?? ''));
    $reset_status = sanitize_key(wp_unslash($_GET['reset'] ?? ''));
    $messages = array(
        'invalid'        => __('This password reset link is invalid or expired. Please request a new one.', 'hausanovels'),
        'missing'        => __('Please fill in the password fields.', 'hausanovels'),
        'mismatch'       => __('Both password fields must match.', 'hausanovels'),
        'password_short' => __('Password must be at least 6 characters.', 'hausanovels'),
        'security'       => __('Security check failed. Please try again.', 'hausanovels'),
    );
    $reset_user = ('' !== $key && '' !== $login) ? check_password_reset_key($key, $login) : new WP_Error('missing_key', __('Missing reset key.', 'hausanovels'));
    $can_reset = $reset_user instanceof WP_User;
    ?>
    <section class="hn-hero hn-compact-hero">
        <div>
            <p class="hn-eyebrow"><?php esc_html_e('New password', 'hausanovels'); ?></p>
            <h1><?php esc_html_e('Choose a new password for your account.', 'hausanovels'); ?></h1>
        </div>
    </section>

    <section class="hn-section">
        <div class="hn-auth-card">
            <?php if (isset($messages[$reset_status])) : ?>
                <p class="hn-auth-alert"><?php echo esc_html($messages[$reset_status]); ?></p>
            <?php elseif (! $can_reset) : ?>
                <p class="hn-auth-alert"><?php echo esc_html($messages['invalid']); ?></p>
            <?php endif; ?>

            <?php if ($can_reset) : ?>
                <form class="hn-auth-form" method="post">
                    <?php wp_nonce_field('hn_frontend_reset_password', 'hn_reset_password_nonce'); ?>
                    <input type="hidden" name="hn_auth_action" value="reset_password">
                    <input type="hidden" name="key" value="<?php echo esc_attr($key); ?>">
                    <input type="hidden" name="login" value="<?php echo esc_attr($login); ?>">
                    <p class="hn-auth-field">
                        <label for="hn-reset-password"><?php esc_html_e('New Password', 'hausanovels'); ?></label>
                        <input id="hn-reset-password" type="password" name="user_pass" autocomplete="new-password" minlength="6" required>
                    </p>
                    <p class="hn-auth-field">
                        <label for="hn-reset-password-confirm"><?php esc_html_e('Confirm New Password', 'hausanovels'); ?></label>
                        <input id="hn-reset-password-confirm" type="password" name="user_pass_confirm" autocomplete="new-password" minlength="6" required>
                    </p>
                    <p class="hn-auth-note"><?php esc_html_e('After saving, you will be signed in automatically on this device.', 'hausanovels'); ?></p>
                    <div class="hn-page-actions">
                        <button class="hn-hero-action" type="submit"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('Save New Password', 'hausanovels'); ?></span></button>
                    </div>
                </form>
            <?php else : ?>
                <div class="hn-page-actions">
                    <a class="hn-hero-action" href="<?php echo esc_url(hausanovels_forgot_password_url()); ?>"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('Request New Link', 'hausanovels'); ?></span></a>
                    <a class="hn-page-link" href="<?php echo esc_url(hausanovels_signin_url()); ?>"><?php esc_html_e('Back to Sign In', 'hausanovels'); ?></a>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php
}

function hausanovels_render_register_page(): void
{
    $redirect = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : hausanovels_app_url('account');
    $redirect = hausanovels_clean_redirect_url($redirect);
    $register_status = sanitize_key(wp_unslash($_GET['register'] ?? ''));
    $account_type = sanitize_key(wp_unslash($_GET['account_type'] ?? 'reader'));

    if (! in_array($account_type, array('reader', 'publisher'), true)) {
        $account_type = 'reader';
    }

    $messages = array(
        'security'        => __('Security check failed. Please try again.', 'hausanovels'),
        'missing'         => __('Please fill all required fields.', 'hausanovels'),
        'email'           => __('Please enter a valid email address.', 'hausanovels'),
        'username_exists' => __('That username is already taken.', 'hausanovels'),
        'email_exists'    => __('That email is already registered. Please sign in instead.', 'hausanovels'),
        'password_short'  => __('Password must be at least 6 characters.', 'hausanovels'),
        'failed'          => __('Account could not be created. Please try again.', 'hausanovels'),
    );
    ?>
    <section class="hn-hero hn-compact-hero">
        <div>
            <p class="hn-eyebrow"><?php esc_html_e('Create account', 'hausanovels'); ?></p>
            <h1><?php esc_html_e('Choose reader or publisher registration.', 'hausanovels'); ?></h1>
        </div>
    </section>

    <section class="hn-section">
        <div class="hn-auth-card">
            <?php if (isset($messages[$register_status])) : ?>
                <p class="hn-auth-alert"><?php echo esc_html($messages[$register_status]); ?></p>
            <?php endif; ?>
            <?php if (shortcode_exists('hn_google_signin')) : ?>
                <?php echo do_shortcode('[hn_google_signin redirect_to="' . esc_url($redirect) . '"]'); ?>
                <div class="hn-auth-divider"><span><?php esc_html_e('or create an account manually', 'hausanovels'); ?></span></div>
            <?php endif; ?>
            <form class="hn-auth-form" method="post">
                <?php wp_nonce_field('hn_frontend_register', 'hn_register_nonce'); ?>
                <input type="hidden" name="hn_auth_action" value="register">
                <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect); ?>">
                <fieldset class="hn-auth-role-choice">
                    <legend><?php esc_html_e('Register as', 'hausanovels'); ?></legend>
                    <label class="hn-auth-option">
                        <input type="radio" name="account_type" value="reader" <?php checked('reader', $account_type); ?>>
                        <span>
                            <strong><?php esc_html_e('Reader', 'hausanovels'); ?></strong>
                            <small><?php esc_html_e('Read books, fund wallet, and unlock paid chapters.', 'hausanovels'); ?></small>
                        </span>
                    </label>
                    <label class="hn-auth-option">
                        <input type="radio" name="account_type" value="publisher" <?php checked('publisher', $account_type); ?>>
                        <span>
                            <strong><?php esc_html_e('Publisher', 'hausanovels'); ?></strong>
                            <small><?php esc_html_e('Upload books, add chapters, and track writer earnings.', 'hausanovels'); ?></small>
                        </span>
                    </label>
                </fieldset>
                <p class="hn-auth-field">
                    <label for="hn-register-user"><?php esc_html_e('Username', 'hausanovels'); ?></label>
                    <input id="hn-register-user" type="text" name="user_login" autocomplete="username" required>
                </p>
                <p class="hn-auth-field">
                    <label for="hn-register-email"><?php esc_html_e('Email', 'hausanovels'); ?></label>
                    <input id="hn-register-email" type="email" name="user_email" autocomplete="email" required>
                </p>
                <p class="hn-auth-field">
                    <label for="hn-register-password"><?php esc_html_e('Password', 'hausanovels'); ?></label>
                    <input id="hn-register-password" type="password" name="user_pass" autocomplete="new-password" minlength="6" required>
                </p>
                <div class="hn-page-actions">
                    <button class="hn-hero-action" type="submit"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('Create Account', 'hausanovels'); ?></span></button>
                    <a class="hn-page-link" href="<?php echo esc_url(hausanovels_signin_url($redirect)); ?>"><?php esc_html_e('Sign In', 'hausanovels'); ?></a>
                </div>
            </form>
        </div>
    </section>
    <?php
}

function hausanovels_render_discover_page(): void
{
    $trending = hausanovels_get_trending_books(10);
    $latest = hausanovels_get_books(array(
        'posts_per_page' => 10,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ));
    $genres = hausanovels_get_genres();
    ?>

    <section class="hn-section hn-app-page-first">
        <form class="hn-discover-search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
            <label class="screen-reader-text" for="hn-discover-search"><?php esc_html_e('Search novels', 'hausanovels'); ?></label>
            <input id="hn-discover-search" type="search" name="s" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="<?php esc_attr_e('Search title, author, or chapter', 'hausanovels'); ?>">
            <button type="submit"><?php echo hausanovels_icon('search'); ?> <span><?php esc_html_e('Search', 'hausanovels'); ?></span></button>
        </form>
    </section>

    <section class="hn-section" id="discover-categories">
        <div class="hn-section-head">
            <h2><?php esc_html_e('Categories', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-category-strip" tabindex="0" aria-label="<?php esc_attr_e('Book categories', 'hausanovels'); ?>">
            <?php foreach ($genres as $genre) : ?>
                <a href="<?php echo esc_url($genre['url']); ?>"><?php echo esc_html($genre['name']); ?></a>
            <?php endforeach; ?>
        </div>
    </section>

    <?php
    hausanovels_render_section(__('Trending This Week', 'hausanovels'), $trending, 'discover-trending');
    hausanovels_render_section(__('Latest Books', 'hausanovels'), $latest, 'discover-latest');
}

function hausanovels_render_library_page(): void
{
    $books = hausanovels_get_books(array(
        'posts_per_page' => 36,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ));
    $genres = hausanovels_get_genres();
    ?>

    <section class="hn-section hn-app-page-first">
        <div class="hn-section-head">
            <h2><?php esc_html_e('Categories', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-category-strip" tabindex="0" aria-label="<?php esc_attr_e('Book categories', 'hausanovels'); ?>">
            <?php foreach ($genres as $genre) : ?>
                <a href="<?php echo esc_url($genre['url']); ?>"><?php echo esc_html($genre['name']); ?></a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="hn-section">
        <div class="hn-section-head">
            <h2><?php esc_html_e('All Books', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-book-grid">
            <?php
            if ($books) {
                foreach ($books as $book) {
                    get_template_part('template-parts/book-card', null, array('book' => $book));
                }
            } else {
                echo '<div class="hn-empty-panel"><h2>' . esc_html__('No books yet', 'hausanovels') . '</h2><p>' . esc_html__('Published books will appear here after they are added from the publisher dashboard or WordPress admin.', 'hausanovels') . '</p></div>';
            }
            ?>
        </div>
    </section>
    <?php
}

function hausanovels_render_account_page(): void
{
    $logout_url = hausanovels_logout_url(home_url('/'));
    ?>

    <section class="hn-section hn-app-page-first hn-account-page">
        <?php if (is_user_logged_in() && 'changed' === sanitize_key(wp_unslash($_GET['password'] ?? ''))) : ?>
            <p class="hn-auth-alert hn-auth-success"><?php esc_html_e('Your password has been changed and you are now signed in.', 'hausanovels'); ?></p>
        <?php endif; ?>

        <?php if (is_user_logged_in()) : ?>
            <?php
            $user = wp_get_current_user();
            $display_name = trim((string) $user->display_name) ?: (string) $user->user_login;
            $email = sanitize_email((string) $user->user_email);
            $initial = function_exists('mb_substr') && function_exists('mb_strtoupper') ? mb_strtoupper(mb_substr($display_name, 0, 1)) : strtoupper(substr($display_name, 0, 1));
            $publisher_only = hausanovels_is_publisher_only((int) $user->ID);
            $account_label = $publisher_only ? __('Publisher', 'hausanovels') : __('Reader', 'hausanovels');
            $balance = ! $publisher_only && function_exists('hn_wallet_get_balance') ? hn_wallet_get_balance((int) $user->ID) : 0;
            ?>

            <div class="hn-account-app">
                <header class="hn-account-profile-card">
                    <div class="hn-account-avatar" aria-hidden="true"><?php echo esc_html($initial); ?></div>
                    <div class="hn-account-profile-copy">
                        <span class="hn-account-kicker"><?php esc_html_e('My account', 'hausanovels'); ?></span>
                        <h1><?php echo esc_html($display_name); ?></h1>
                        <?php if ($email) : ?><p><?php echo esc_html($email); ?></p><?php endif; ?>
                    </div>
                    <span class="hn-account-type-badge"><?php echo esc_html($account_label); ?></span>
                </header>

                <?php if (! $publisher_only) : ?>
                    <section class="hn-account-wallet-card" aria-label="<?php esc_attr_e('Wallet summary', 'hausanovels'); ?>">
                        <div class="hn-account-wallet-icon"><?php echo hausanovels_icon('wallet'); ?></div>
                        <div>
                            <span><?php esc_html_e('Available balance', 'hausanovels'); ?></span>
                            <strong><?php echo esc_html(number_format_i18n((int) $balance)); ?> <?php esc_html_e('coins', 'hausanovels'); ?></strong>
                        </div>
                        <a href="<?php echo esc_url(hausanovels_app_url('wallet')); ?>"><?php esc_html_e('Buy coins', 'hausanovels'); ?></a>
                    </section>

                    <nav class="hn-account-menu" aria-label="<?php esc_attr_e('Reader account options', 'hausanovels'); ?>">
                        <a href="<?php echo esc_url(hausanovels_app_url('library')); ?>">
                            <span class="hn-account-menu-icon"><?php echo hausanovels_icon('book'); ?></span>
                            <span><strong><?php esc_html_e('Library', 'hausanovels'); ?></strong><small><?php esc_html_e('Browse all published Hausa books', 'hausanovels'); ?></small></span>
                            <span class="hn-account-chevron" aria-hidden="true">›</span>
                        </a>
                        <a href="<?php echo esc_url(hausanovels_app_url('discover')); ?>">
                            <span class="hn-account-menu-icon"><?php echo hausanovels_icon('search'); ?></span>
                            <span><strong><?php esc_html_e('Discover', 'hausanovels'); ?></strong><small><?php esc_html_e('Find trending, latest, and category books', 'hausanovels'); ?></small></span>
                            <span class="hn-account-chevron" aria-hidden="true">›</span>
                        </a>
                        <?php if (shortcode_exists('hn_bookmarks')) : ?>
                            <a href="<?php echo esc_url(hausanovels_app_url('bookmarks')); ?>">
                                <span class="hn-account-menu-icon"><?php echo hausanovels_icon('book'); ?></span>
                                <span><strong><?php esc_html_e('Bookmarks', 'hausanovels'); ?></strong><small><?php esc_html_e('Open books and chapters you saved', 'hausanovels'); ?></small></span>
                                <span class="hn-account-chevron" aria-hidden="true">›</span>
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(hausanovels_app_url('wallet')); ?>">
                            <span class="hn-account-menu-icon"><?php echo hausanovels_icon('wallet'); ?></span>
                            <span><strong><?php esc_html_e('Wallet and payments', 'hausanovels'); ?></strong><small><?php esc_html_e('Buy coins and view transactions', 'hausanovels'); ?></small></span>
                            <span class="hn-account-chevron" aria-hidden="true">›</span>
                        </a>
                    </nav>
                <?php else : ?>
                    <nav class="hn-account-menu" aria-label="<?php esc_attr_e('Publisher account options', 'hausanovels'); ?>">
                        <a href="<?php echo esc_url(hausanovels_app_url('publisher')); ?>">
                            <span class="hn-account-menu-icon"><?php echo hausanovels_icon('grid'); ?></span>
                            <span><strong><?php esc_html_e('Publisher dashboard', 'hausanovels'); ?></strong><small><?php esc_html_e('Manage your books and publishing activity', 'hausanovels'); ?></small></span>
                            <span class="hn-account-chevron" aria-hidden="true">›</span>
                        </a>
                        <a href="<?php echo esc_url(home_url('/publisher/books/')); ?>">
                            <span class="hn-account-menu-icon"><?php echo hausanovels_icon('book'); ?></span>
                            <span><strong><?php esc_html_e('My books', 'hausanovels'); ?></strong><small><?php esc_html_e('Create, edit, and review your books', 'hausanovels'); ?></small></span>
                            <span class="hn-account-chevron" aria-hidden="true">›</span>
                        </a>
                        <a href="<?php echo esc_url(home_url('/publisher/chapters/')); ?>">
                            <span class="hn-account-menu-icon"><?php echo hausanovels_icon('book'); ?></span>
                            <span><strong><?php esc_html_e('My chapters', 'hausanovels'); ?></strong><small><?php esc_html_e('Add and manage book chapters', 'hausanovels'); ?></small></span>
                            <span class="hn-account-chevron" aria-hidden="true">›</span>
                        </a>
                        <a href="<?php echo esc_url(home_url('/publisher/earnings/')); ?>">
                            <span class="hn-account-menu-icon"><?php echo hausanovels_icon('wallet'); ?></span>
                            <span><strong><?php esc_html_e('Earnings and withdrawals', 'hausanovels'); ?></strong><small><?php esc_html_e('View revenue and payout activity', 'hausanovels'); ?></small></span>
                            <span class="hn-account-chevron" aria-hidden="true">›</span>
                        </a>
                    </nav>
                <?php endif; ?>

                <?php if (hausanovels_can_access_publisher() && ! $publisher_only) : ?>
                    <a class="hn-account-publisher-link" href="<?php echo esc_url(hausanovels_app_url('publisher')); ?>">
                        <?php echo hausanovels_icon('grid'); ?>
                        <span><strong><?php esc_html_e('Open publisher tools', 'hausanovels'); ?></strong><small><?php esc_html_e('Manage books, chapters, and earnings', 'hausanovels'); ?></small></span>
                    </a>
                <?php endif; ?>

                <a class="hn-account-logout" href="<?php echo esc_url($logout_url); ?>">
                    <?php echo hausanovels_icon('close'); ?>
                    <span><?php esc_html_e('Sign out', 'hausanovels'); ?></span>
                </a>
            </div>
        <?php else : ?>
            <div class="hn-account-guest-card">
                <div class="hn-account-guest-icon"><?php echo hausanovels_icon('user'); ?></div>
                <span class="hn-account-kicker"><?php esc_html_e('Your reading account', 'hausanovels'); ?></span>
                <h1><?php esc_html_e('Sign in to manage books, coins, and bookmarks.', 'hausanovels'); ?></h1>
                <p><?php esc_html_e('Use one secure account across the website and HausaNovels app.', 'hausanovels'); ?></p>

                <?php if (shortcode_exists('hn_google_signin')) : ?>
                    <div class="hn-account-google-signin"><?php echo do_shortcode('[hn_google_signin redirect_to="' . esc_url(hausanovels_app_url('account')) . '"]'); ?></div>
                <?php endif; ?>

                <div class="hn-account-guest-actions">
                    <a class="hn-hero-action" href="<?php echo esc_url(hausanovels_signin_url(hausanovels_app_url('account'))); ?>"><?php echo hausanovels_icon('user'); ?> <span><?php esc_html_e('Sign In', 'hausanovels'); ?></span></a>
                    <a class="hn-page-link" href="<?php echo esc_url(hausanovels_register_url(hausanovels_app_url('account'), 'reader')); ?>"><?php esc_html_e('Create Reader Account', 'hausanovels'); ?></a>
                    <a class="hn-page-link is-subtle" href="<?php echo esc_url(hausanovels_register_url(hausanovels_app_url('publisher'), 'publisher')); ?>"><?php esc_html_e('Register as Publisher', 'hausanovels'); ?></a>
                </div>
            </div>
        <?php endif; ?>
    </section>
    <?php
}

function hausanovels_render_wallet_page(): void
{
    ?>

    <section class="hn-section hn-app-page-first hn-wallet-page-stack">
        <?php
        // Keep the wallet hierarchy consistent across the website, PWA and TWA:
        // balance first, coin purchase second, transaction history last.
        if (shortcode_exists('hn_wallet_balance') && shortcode_exists('hn_wallet_history')) {
            echo do_shortcode('[hn_wallet_balance]');

            if (shortcode_exists('hn_paystack_topup')) {
                echo do_shortcode('[hn_paystack_topup]');
            } elseif (shortcode_exists('hn_bank_transfer_topup')) {
                echo do_shortcode('[hn_bank_transfer_topup]');
            }

            if (! shortcode_exists('hn_paystack_topup') && ! shortcode_exists('hn_bank_transfer_topup') && shortcode_exists('hn_paystack_dedicated_account')) {
                echo do_shortcode('[hn_paystack_dedicated_account]');
            }

            echo do_shortcode('[hn_wallet_history]');
        } elseif (shortcode_exists('hn_wallet')) {
            // Backward-compatible fallback for an older Wallet plugin.
            echo do_shortcode('[hn_wallet]');

            if (shortcode_exists('hn_paystack_topup')) {
                echo do_shortcode('[hn_paystack_topup]');
            } elseif (shortcode_exists('hn_bank_transfer_topup')) {
                echo do_shortcode('[hn_bank_transfer_topup]');
            }
        } else {
            echo '<div class="hn-empty-panel"><h2>' . esc_html__('Wallet plugin not active', 'hausanovels') . '</h2><p>' . esc_html__('Install Hausanovels Wallet & Coins to enable balances and chapter unlocks.', 'hausanovels') . '</p></div>';
        }
        ?>
    </section>
    <?php
}

function hausanovels_pwa_meta(): void
{
    if (defined('HAUSANOVELS_PWA_VERSION')) {
        return;
    }

    $icon_192 = get_template_directory_uri() . '/assets/brand/icon-192.png';
    $icon_512 = get_template_directory_uri() . '/assets/brand/icon-512.png';
    ?>
    <meta name="theme-color" content="#050816">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Hausanovels">
    <link rel="manifest" href="<?php echo esc_url(home_url('/?hn_manifest=1')); ?>">
    <link rel="icon" sizes="192x192" href="<?php echo esc_url($icon_192); ?>">
    <link rel="apple-touch-icon" href="<?php echo esc_url($icon_512); ?>">
    <?php
}
add_action('wp_head', 'hausanovels_pwa_meta', 2);

function hausanovels_seo_meta(): void
{
    if (is_admin() || function_exists('rank_math') || defined('WPSEO_VERSION') || function_exists('hn_seo_plugin_active')) {
        return;
    }

    $description = get_bloginfo('description');
    $keywords = hausanovels_seo_keywords();
    $current_url = is_singular() ? get_permalink() : home_url(add_query_arg(array(), $GLOBALS['wp']->request ?? ''));
    $image = get_template_directory_uri() . '/assets/brand/icon-512.png';

    if (is_front_page()) {
        $description = 'Read complete Hausa novels online on Hausanovels.ng. Discover romantic Hausa novels, Arewa novels, labaran soyayya, latest chapters, free books, and paid chapters.';
    } elseif (is_singular()) {
        $description = wp_strip_all_tags(get_the_excerpt());
        $post_image = get_the_post_thumbnail_url(get_the_ID(), 'large');
        $r2_cover = get_post_meta(get_the_ID(), '_hn_cover_url', true);
        $image = $r2_cover ?: ($post_image ?: $image);
    } elseif (is_search()) {
        $description = 'Search complete Hausa novels, romantic Hausa stories, Arewa novels, labaran soyayya, littafin Hausa, authors, and latest chapters on Hausanovels.ng.';
    }

    if (! empty($description)) {
        echo '<meta name="description" content="' . esc_attr(wp_trim_words($description, 28, '')) . '">' . "\n";
    }

    echo '<meta name="keywords" content="' . esc_attr(implode(', ', $keywords)) . '">' . "\n";
    echo '<link rel="canonical" href="' . esc_url($current_url) . '">' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . '">' . "\n";
    echo '<meta property="og:type" content="' . (is_singular() ? 'article' : 'website') . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr(wp_get_document_title()) . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr(wp_trim_words($description, 28, '')) . '">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($current_url) . '">' . "\n";
    echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    echo '<meta name="twitter:title" content="' . esc_attr(wp_get_document_title()) . '">' . "\n";
    echo '<meta name="twitter:description" content="' . esc_attr(wp_trim_words($description, 28, '')) . '">' . "\n";
    echo '<meta name="twitter:image" content="' . esc_url($image) . '">' . "\n";
}
add_action('wp_head', 'hausanovels_seo_meta', 3);

function hausanovels_seo_keywords(): array
{
    return array(
        'Hausa novels',
        'complete Hausa novels',
        'read Hausa novels online',
        'romantic Hausa novels',
        'latest Hausa novel',
        'Arewa novels',
        'Hausa stories',
        'labaran soyayya',
        'littafin Hausa',
        'littattafan soyayya',
        'Hausa love stories',
        'free Hausa novels',
        'paid Hausa chapters',
        'Hausa novel app',
        'Hausa ebooks',
        'Kannywood stories',
        'Nigerian Hausa novels',
        'Hausa romance books',
    );
}

function hausanovels_schema(): void
{
    if (is_admin() || function_exists('hn_seo_plugin_active')) {
        return;
    }

    $schema = array(
        array(
            '@context'        => 'https://schema.org',
            '@type'           => 'WebSite',
            'name'            => 'Hausanovels.ng',
            'url'             => home_url('/'),
            'inLanguage'      => array('ha', 'en-NG'),
            'potentialAction' => array(
                '@type'       => 'SearchAction',
                'target'      => home_url('/?s={search_term_string}'),
                'query-input' => 'required name=search_term_string',
            ),
        ),
        array(
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            'name'     => 'Hausanovels.ng',
            'url'      => home_url('/'),
            'logo'     => get_template_directory_uri() . '/assets/brand/icon-512.png',
        ),
    );

    if (is_front_page()) {
        $books = array_slice(hausanovels_get_books(), 0, 10);
        $schema[] = array(
            '@context'        => 'https://schema.org',
            '@type'           => 'ItemList',
            'name'            => 'Trending Hausa novels and latest books',
            'itemListElement' => array_map(
                static function (array $book, int $index): array {
                    return array(
                        '@type'    => 'ListItem',
                        'position' => $index + 1,
                        'url'      => $book['permalink'],
                        'name'     => $book['title'],
                    );
                },
                $books,
                array_keys($books)
            ),
        );
    }

    if (is_singular('hn_book')) {
        $image = get_post_meta(get_the_ID(), '_hn_cover_url', true) ?: get_the_post_thumbnail_url(get_the_ID(), 'large');
        $schema[] = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Book',
            'name'        => get_the_title(),
            'url'         => get_permalink(),
            'image'       => $image ?: get_template_directory_uri() . '/assets/brand/icon-512.png',
            'inLanguage'  => 'ha',
            'description' => wp_strip_all_tags(get_the_excerpt()),
            'isAccessibleForFree' => true,
        );
    }

    if (is_singular('hn_chapter')) {
        $book_id = function_exists('hn_get_chapter_book_id') ? hn_get_chapter_book_id(get_the_ID()) : (int) get_post_meta(get_the_ID(), '_hn_book_id', true);
        $chapter_schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Chapter',
            'name'        => get_the_title(),
            'url'         => get_permalink(),
            'inLanguage'  => 'ha',
            'description' => wp_strip_all_tags(get_the_excerpt()),
        );

        if ($book_id) {
            $chapter_schema['isPartOf'] = array(
                '@type' => 'Book',
                'name'  => get_the_title($book_id),
                'url'   => get_permalink($book_id),
            );
        }

        $schema[] = $chapter_schema;
    }

    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}
add_action('wp_head', 'hausanovels_schema', 4);

function hausanovels_pwa_endpoints(): void
{
    if (isset($_GET['hn_content_version'])) {
        hausanovels_send_private_headers();
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode(array(
            'version' => hausanovels_content_version(),
            'theme'   => HAUSANOVELS_THEME_VERSION,
        ));
        exit;
    }

    if (defined('HAUSANOVELS_PWA_VERSION')) {
        return;
    }

    if (isset($_GET['hn_manifest'])) {
        header('Content-Type: application/manifest+json; charset=utf-8');

        echo wp_json_encode(array(
            'name'             => 'Hausanovels.ng',
            'short_name'       => 'Hausanovels',
            'description'      => 'Read Hausa novels, unlock paid chapters with coins, and continue reading anywhere.',
            'start_url'        => home_url('/'),
            'scope'            => home_url('/'),
            'display'          => 'standalone',
            'orientation'      => 'portrait',
            'background_color' => '#050816',
            'theme_color'      => '#050816',
            'categories'       => array('books', 'entertainment', 'education'),
            'icons'            => array(
                array(
                    'src'     => get_template_directory_uri() . '/assets/brand/icon-192.png',
                    'sizes'   => '192x192',
                    'type'    => 'image/png',
                    'purpose' => 'any maskable',
                ),
                array(
                    'src'     => get_template_directory_uri() . '/assets/brand/icon-512.png',
                    'sizes'   => '512x512',
                    'type'    => 'image/png',
                    'purpose' => 'any maskable',
                ),
            ),
        ), JSON_UNESCAPED_SLASHES);
        exit;
    }

    if (isset($_GET['hn_sw'])) {
        header('Content-Type: application/javascript; charset=utf-8');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Service-Worker-Allowed: /');
        readfile(get_template_directory() . '/service-worker.js');
        exit;
    }
}
add_action('template_redirect', 'hausanovels_pwa_endpoints');

function hausanovels_register_service_worker(): void
{
    if (defined('HAUSANOVELS_PWA_VERSION')) {
        return;
    }
    ?>
    <script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            var swUrl = <?php echo wp_json_encode(add_query_arg(array('v' => HAUSANOVELS_THEME_VERSION, 'cv' => hausanovels_content_version()), home_url('/?hn_sw=1'))); ?>;
            navigator.serviceWorker.register(swUrl, { scope: '/', updateViaCache: 'none' }).catch(function () {});
        }, { once: true });
    }
    </script>
    <?php
}
add_action('wp_footer', 'hausanovels_register_service_worker', 20);

function hausanovels_icon(string $name): string
{
    $icons = array(
        'home' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10.8 12 3l9 7.8v9.4a.8.8 0 0 1-.8.8h-5.1v-6.4H8.9V21H3.8a.8.8 0 0 1-.8-.8v-9.4Z"/></svg>',
        'menu' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
        'search' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m20 20-4.2-4.2M10.8 18a7.2 7.2 0 1 1 0-14.4 7.2 7.2 0 0 1 0 14.4Z"/></svg>',
        'book' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 5.5c2.9-1.3 5.3-.8 7.5 1.2 2.2-2 4.6-2.5 7.5-1.2v13c-2.9-1.3-5.3-.8-7.5 1.2-2.2-2-4.6-2.5-7.5-1.2v-13Z"/><path d="M12 6.7v13"/></svg>',
        'trend' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 15.8 5.2-5.2 3.5 3.5L20 6.8"/><path d="M15 6.8h5v5"/></svg>',
        'grid' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/></svg>',
        'wallet' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7.2A2.2 2.2 0 0 1 6.2 5h12.2A1.6 1.6 0 0 1 20 6.6V9H6.5A2.5 2.5 0 0 0 4 11.5v5.3A2.2 2.2 0 0 0 6.2 19H20v-4.2h-4.2a2.3 2.3 0 1 1 0-4.6H20V9"/><path d="M16 12.5h.1"/></svg>',
        'user' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12a4.2 4.2 0 1 0 0-8.4 4.2 4.2 0 0 0 0 8.4Z"/><path d="M4.5 20.5c1.1-4 4-6 7.5-6s6.4 2 7.5 6"/></svg>',
        'lock' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10V8a5 5 0 0 1 10 0v2"/><path d="M6.4 10h11.2c.8 0 1.4.6 1.4 1.4v7.2c0 .8-.6 1.4-1.4 1.4H6.4c-.8 0-1.4-.6-1.4-1.4v-7.2c0-.8.6-1.4 1.4-1.4Z"/></svg>',
        'unlock' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 10V8.3a4.7 4.7 0 0 1 8.6-2.6"/><path d="M6.4 10h11.2c.8 0 1.4.6 1.4 1.4v7.2c0 .8-.6 1.4-1.4 1.4H6.4c-.8 0-1.4-.6-1.4-1.4v-7.2c0-.8.6-1.4 1.4-1.4Z"/></svg>',
        'close' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>',
    );

    return $icons[$name] ?? '';
}

function hausanovels_logo(): string
{
    if (has_custom_logo()) {
        return get_custom_logo();
    }

    $icon_url = get_template_directory_uri() . '/assets/brand/icon-192.png';

    return '<a class="hn-logo hn-brand-lockup" href="' . esc_url(home_url('/')) . '" aria-label="' . esc_attr(get_bloginfo('name')) . '">'
        . '<img class="hn-brand-lockup-icon" src="' . esc_url($icon_url) . '" alt="">'
        . '<span class="hn-brand-lockup-text"><span>Hausa</span><strong>Novels</strong></span>'
        . '</a>';
}

function hausanovels_header_icon(): string
{
    return '<a class="hn-header-icon" href="' . esc_url(home_url('/')) . '" aria-label="' . esc_attr(get_bloginfo('name')) . '">'
        . '<img src="' . esc_url(get_template_directory_uri() . '/assets/brand/icon-192.png') . '" alt="">'
        . '</a>';
}

function hausanovels_header_title(): string
{
    return '<a class="hn-header-title" href="' . esc_url(home_url('/')) . '" aria-label="Hausa Novels">'
        . '<span class="hn-header-title-main">Hausa</span>'
        . '<span class="hn-header-title-accent">Novels</span>'
        . '</a>';
}

function hausanovels_sample_cover(string $seed): string
{
    $palettes = array(
        array('#111827', '#21C77A', '#F3B348'),
        array('#10131F', '#F3B348', '#F8FAFC'),
        array('#0B1020', '#1EA768', '#F0A928'),
        array('#121826', '#F8FAFC', '#21C77A'),
    );
    $palette = $palettes[abs(crc32($seed)) % count($palettes)];
    $svg = '<svg width="420" height="630" viewBox="0 0 420 630" xmlns="http://www.w3.org/2000/svg">'
        . '<defs><linearGradient id="g" x1="0" x2="1" y1="0" y2="1"><stop stop-color="' . $palette[0] . '"/><stop offset="1" stop-color="#050816"/></linearGradient></defs>'
        . '<rect width="420" height="630" rx="28" fill="url(#g)"/>'
        . '<circle cx="310" cy="90" r="82" fill="' . $palette[1] . '" opacity=".22"/>'
        . '<path d="M78 340c62-42 127-37 195 15v130c-65-50-130-55-195-15V340Z" fill="' . $palette[2] . '"/>'
        . '<path d="M273 355c39-33 77-38 116-15v130c-39-23-77-18-116 15V355Z" fill="#C88418"/>'
        . '<path d="M273 355v134" stroke="' . $palette[1] . '" stroke-width="12" stroke-linecap="round"/>'
        . '<text x="46" y="130" font-family="Arial, sans-serif" font-size="42" font-weight="800" fill="#F8FAFC">HN</text>'
        . '<text x="46" y="176" font-family="Arial, sans-serif" font-size="22" font-weight="700" fill="#A8B3C7">HAUSA NOVELS</text>'
        . '</svg>';

    return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
}

function hausanovels_sample_books(): array
{
    $titles = array(
        array('Soyayya A Birni', 'Romance', true),
        array('Sirrin Zuciya', 'Mystery', true),
        array('Gidan Sarauta', 'Royal', false),
        array('Daren Alkawari', 'Adventure', true),
        array('Rayuwar Amina', 'Family', false),
        array('Hanyar Kano', 'Drama', true),
        array('Auren Sirri', 'Romance', true),
        array('Kaddarar Rai', 'Drama', false),
        array('Matar Gida', 'Family', true),
        array('Sarkin Dare', 'Royal', true),
    );

    return array_map(
        static function (array $item, int $index): array {
            return array(
                'id'         => $index + 1,
                'title'      => $item[0],
                'genre'      => $item[1],
                'premium'     => false,
                'coin_price'  => 0,
                'author'      => __('Hausanovels', 'hausanovels'),
                'description'    => __('A selected Hausa story with romance, family drama, and fresh chapters for mobile reading.', 'hausanovels'),
                'permalink'      => '#',
                'cover'          => hausanovels_sample_cover($item[0]),
            );
        },
        $titles,
        array_keys($titles)
    );
}

function hausanovels_book_from_post(WP_Post $post): array
{
    $cover = get_the_post_thumbnail_url($post, 'hausanovels-cover');
    $r2_cover = get_post_meta($post->ID, '_hn_cover_url', true);
    $description_source = '' !== trim((string) $post->post_excerpt) ? $post->post_excerpt : wp_strip_all_tags((string) $post->post_content);

    return array(
        'id'          => $post->ID,
        'title'       => get_the_title($post),
        'genre'       => '',
        'premium'     => false,
        'coin_price'  => 0,
        'author'         => (string) get_post_meta($post->ID, '_hn_author_name', true),
        'description'    => wp_trim_words(wp_strip_all_tags($description_source), 22, '...'),
        'permalink'      => get_permalink($post),
        'cover'          => $r2_cover ?: ($cover ?: hausanovels_sample_cover(get_the_title($post))),
    );
}

function hausanovels_search_result_from_post(WP_Post $post): array
{
    if ('hn_chapter' === $post->post_type) {
        $book_id = function_exists('hn_get_chapter_book_id') ? hn_get_chapter_book_id($post->ID) : (int) get_post_meta($post->ID, '_hn_book_id', true);
        $book_title = $book_id ? get_the_title($book_id) : __('Chapter', 'hausanovels');
        $cover = $book_id ? (get_post_meta($book_id, '_hn_cover_url', true) ?: get_the_post_thumbnail_url($book_id, 'hausanovels-cover')) : '';

        return array(
            'id'         => $post->ID,
            'title'      => sprintf(__('%1$s: %2$s', 'hausanovels'), $book_title, get_the_title($post)),
            'genre'      => '',
            'premium'    => false,
            'coin_price' => 0,
            'permalink'  => get_permalink($post),
            'cover'      => $cover ?: hausanovels_sample_cover($book_title . get_the_title($post)),
        );
    }

    return hausanovels_book_from_post($post);
}


function hausanovels_chapter_sort_value(WP_Post $chapter): array
{
    $order_keys = array('_hn_chapter_order', '_hn_chapter_number', '_hn_order', '_hn_episode_number');

    foreach ($order_keys as $key) {
        $value = get_post_meta($chapter->ID, $key, true);
        if ('' !== (string) $value) {
            return array(0, (float) $value, strtotime((string) $chapter->post_date_gmt), (int) $chapter->ID);
        }
    }

    if ((int) $chapter->menu_order > 0) {
        return array(1, (int) $chapter->menu_order, strtotime((string) $chapter->post_date_gmt), (int) $chapter->ID);
    }

    return array(2, strtotime((string) $chapter->post_date_gmt), (int) $chapter->ID, (int) $chapter->ID);
}

function hausanovels_get_book_chapters_fresh(int $book_id): array
{
    $book_id = absint($book_id);

    if ($book_id <= 0 || ! post_type_exists('hn_chapter')) {
        return array();
    }

    if (function_exists('hn_get_book_chapters')) {
        $chapters = hn_get_book_chapters($book_id);
        if (is_array($chapters)) {
            return array_values(array_filter($chapters, static fn ($chapter): bool => $chapter instanceof WP_Post));
        }
    }

    $base_args = array(
        'post_type'              => 'hn_chapter',
        'post_status'            => 'publish',
        'posts_per_page'         => -1,
        'no_found_rows'          => true,
        'ignore_sticky_posts'    => true,
        'cache_results'          => true,
        'update_post_meta_cache' => true,
        'update_post_term_cache' => false,
        'orderby'                => array(
            'menu_order' => 'ASC',
            'date'       => 'ASC',
            'ID'         => 'ASC',
        ),
    );

    $meta_query = new WP_Query($base_args + array(
        'meta_query' => array(
            array(
                'key'     => '_hn_book_id',
                'value'   => $book_id,
                'compare' => '=',
                'type'    => 'NUMERIC',
            ),
        ),
    ));

    $parent_query = new WP_Query($base_args + array(
        'post_parent' => $book_id,
    ));

    $chapters_by_id = array();
    foreach (array_merge($meta_query->posts, $parent_query->posts) as $post) {
        if ($post instanceof WP_Post) {
            $chapters_by_id[(int) $post->ID] = $post;
        }
    }

    wp_reset_postdata();

    $chapters = array_values($chapters_by_id);
    usort($chapters, static function (WP_Post $a, WP_Post $b): int {
        return hausanovels_chapter_sort_value($a) <=> hausanovels_chapter_sort_value($b);
    });

    return $chapters;
}

function hausanovels_get_chapter_coin_price(int $chapter_id): int
{
    if (function_exists('hn_get_chapter_coin_price')) {
        return max(0, (int) hn_get_chapter_coin_price($chapter_id));
    }

    foreach (array('_hn_coin_price', '_hn_chapter_coin_price', '_hn_chapter_price', '_hn_price', '_hn_coins') as $key) {
        $value = get_post_meta($chapter_id, $key, true);
        if ('' !== (string) $value) {
            return max(0, (int) $value);
        }
    }

    return 0;
}

function hausanovels_render_fresh_chapter_list(int $book_id, ?array $chapters = null): string
{
    $chapters = is_array($chapters) ? $chapters : hausanovels_get_book_chapters_fresh($book_id);

    if (! $chapters) {
        return '<div class="hn-chapter-placeholder"><p>' . esc_html__('Chapters will appear here as soon as they are published.', 'hausanovels') . '</p></div>';
    }

    $user_id = get_current_user_id();
    $is_guest = $user_id <= 0;
    $is_publisher = function_exists('hausanovels_is_publisher_only') && hausanovels_is_publisher_only($user_id);
    $is_admin = current_user_can('manage_options');
    $chapter_ids = array_values(array_map(static fn (WP_Post $chapter): int => (int) $chapter->ID, $chapters));
    $unlocked_map = array();

    if (! $is_guest && ! $is_publisher && ! $is_admin && function_exists('hn_wallet_get_unlocked_chapter_ids')) {
        $unlocked_ids = hn_wallet_get_unlocked_chapter_ids($user_id, $chapter_ids);
        $unlocked_map = array_fill_keys(array_map('intval', (array) $unlocked_ids), true);
    }

    ob_start();
    ?>
    <ol class="hn-core-chapter-list hn-fresh-chapter-list" data-hn-content-version="<?php echo esc_attr(hausanovels_content_version()); ?>">
        <?php foreach ($chapters as $index => $chapter) : ?>
            <?php
            $chapter_id = (int) $chapter->ID;
            $coin_price = hausanovels_get_chapter_coin_price($chapter_id);
            $is_paid = function_exists('hn_is_chapter_premium') ? (bool) hn_is_chapter_premium($chapter_id) : $coin_price > 0;
            $chapter_url = $is_guest ? hausanovels_signin_url(get_permalink($chapter_id)) : get_permalink($chapter_id);

            if ($is_admin) {
                $can_read = true;
            } elseif ($is_guest || $is_publisher) {
                $can_read = false;
            } elseif (! $is_paid) {
                $can_read = true;
            } elseif (function_exists('hn_wallet_get_unlocked_chapter_ids')) {
                $can_read = isset($unlocked_map[$chapter_id]);
            } else {
                $can_read = function_exists('hn_user_can_read_chapter') ? (bool) hn_user_can_read_chapter($user_id, $chapter_id) : false;
            }

            if ($is_guest) {
                $status = __('Sign in', 'hausanovels');
                $status_class = 'is-signin';
            } elseif ($is_publisher) {
                $status = __('Reader only', 'hausanovels');
                $status_class = 'is-locked';
            } elseif (! $can_read && $is_paid) {
                $status = $coin_price > 0 ? sprintf(_n('%d coin', '%d coins', $coin_price, 'hausanovels'), $coin_price) : __('Locked', 'hausanovels');
                $status_class = 'is-locked';
            } elseif (! $can_read) {
                $status = __('Locked', 'hausanovels');
                $status_class = 'is-locked';
            } else {
                $status = __('Open', 'hausanovels');
                $status_class = 'is-open';
            }
            ?>
            <li>
                <a class="hn-chapter-row-link" href="<?php echo esc_url($chapter_url); ?>">
                    <span class="hn-chapter-number"><?php echo esc_html((string) ($index + 1)); ?></span>
                    <span class="hn-chapter-row-title"><?php echo esc_html(get_the_title($chapter_id)); ?></span>
                </a>
                <span class="hn-chapter-status <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status); ?></span>
            </li>
        <?php endforeach; ?>
    </ol>
    <?php
    return (string) ob_get_clean();
}

function hausanovels_get_books(array $args = array()): array
{
    if (! post_type_exists('hn_book')) {
        return hausanovels_sample_books();
    }

    $query_args = wp_parse_args($args, array(
        'post_type'      => 'hn_book',
        'posts_per_page' => 10,
        'post_status'    => 'publish',
        'no_found_rows'  => true,
        'ignore_sticky_posts' => true,
    ));

    if (isset($query_args['meta_key']) && '_hn_weekly_reads' === $query_args['meta_key']) {
        unset($query_args['meta_key']);
        $query_args['meta_query'] = array(
            'weekly_reads_clause' => array(
                'key'     => '_hn_weekly_reads',
                'value'   => 0,
                'compare' => '>',
                'type'    => 'NUMERIC',
            ),
        );
        $query_args['orderby'] = array(
            'weekly_reads_clause' => 'DESC',
            'date'                => 'DESC',
        );
    }

    $cache_key = 'hn_books_' . substr(md5(hausanovels_content_version() . '|' . wp_json_encode($query_args)), 0, 28);
    $cached_books = get_transient($cache_key);
    if (is_array($cached_books)) {
        return $cached_books;
    }

    $query = new WP_Query($query_args);
    $books = array();

    foreach ($query->posts as $post) {
        $books[] = hausanovels_book_from_post($post);
    }

    wp_reset_postdata();
    set_transient($cache_key, $books, 5 * MINUTE_IN_SECONDS);

    return $books;
}

function hausanovels_get_trending_books(int $limit = 10): array
{
    $limit = max(1, min(20, $limit));

    $books = hausanovels_get_books(array(
        'posts_per_page' => $limit,
        'meta_query'     => array(
            'weekly_reads_clause' => array(
                'key'     => '_hn_weekly_reads',
                'value'   => 0,
                'compare' => '>',
                'type'    => 'NUMERIC',
            ),
        ),
        'orderby'        => array(
            'weekly_reads_clause' => 'DESC',
            'date'                => 'DESC',
        ),
    ));

    if ($books) {
        return $books;
    }

    return hausanovels_get_books(array(
        'posts_per_page' => $limit,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ));
}

function hausanovels_get_featured_books(int $limit = 8): array
{
    $limit = max(1, min(12, $limit));

    if (! post_type_exists('hn_book')) {
        return array_slice(hausanovels_sample_books(), 0, $limit);
    }

    $featured = hausanovels_get_books(array(
        'posts_per_page' => $limit,
        'meta_query'     => array(
            'relation' => 'OR',
            array(
                'key'     => '_hn_is_featured',
                'value'   => '1',
                'compare' => '=',
            ),
            array(
                'key'     => '_hn_featured',
                'value'   => array('1', 'yes', 'true', 'featured'),
                'compare' => 'IN',
            ),
        ),
        'orderby'        => 'date',
        'order'          => 'DESC',
    ));

    if (count($featured) >= $limit) {
        return $featured;
    }

    $fallback = hausanovels_get_books(array(
        'posts_per_page' => $limit,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ));

    $book_ids = array_map(static fn (array $book): int => (int) ($book['id'] ?? 0), $featured);

    foreach ($fallback as $book) {
        $book_id = (int) ($book['id'] ?? 0);
        if ($book_id && in_array($book_id, $book_ids, true)) {
            continue;
        }

        $featured[] = $book;
        $book_ids[] = $book_id;

        if (count($featured) >= $limit) {
            break;
        }
    }

    return array_slice($featured, 0, $limit);
}

function hausanovels_get_genres(): array
{
    if (taxonomy_exists('hn_genre')) {
        $terms = get_terms(array(
            'taxonomy'   => 'hn_genre',
            'hide_empty' => true,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ));

        if (is_wp_error($terms) || ! $terms) {
            return array();
        }

        return array_map(
            static function ($term): array {
                return array(
                    'name' => $term->name,
                    'slug' => $term->slug,
                    'url'  => get_term_link($term),
                );
            },
            $terms
        );
    }

    return array(
        array('name' => 'Romance', 'slug' => 'romance', 'url' => '#romance'),
        array('name' => 'Royal', 'slug' => 'royal', 'url' => '#royal'),
        array('name' => 'Drama', 'slug' => 'drama', 'url' => '#drama'),
        array('name' => 'Family', 'slug' => 'family', 'url' => '#family'),
        array('name' => 'Mystery', 'slug' => 'mystery', 'url' => '#mystery'),
        array('name' => 'Adventure', 'slug' => 'adventure', 'url' => '#adventure'),
    );
}

function hausanovels_books_for_genre(string $genre): array
{
    if (taxonomy_exists('hn_genre') && post_type_exists('hn_book')) {
        return hausanovels_get_books(array(
            'posts_per_page' => 10,
            'tax_query' => array(
                array(
                    'taxonomy' => 'hn_genre',
                    'field'    => 'slug',
                    'terms'    => $genre,
                ),
            ),
        ));
    }

    $books = array_filter(
        hausanovels_sample_books(),
        static fn (array $book): bool => strtolower($book['genre']) === strtolower($genre)
    );

    return $books ? array_values($books) : array_slice(hausanovels_sample_books(), 0, 6);
}

function hausanovels_render_section(string $title, array $books, string $id = ''): void
{
    $books = array_values(array_filter($books));

    if (! $books) {
        return;
    }

    $books = array_slice($books, 0, 10);
    ?>
    <section class="hn-section" <?php echo $id ? 'id="' . esc_attr($id) . '"' : ''; ?>>
        <div class="hn-section-head">
            <h2><?php echo esc_html($title); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-book-row" tabindex="0" aria-label="<?php echo esc_attr($title); ?>">
            <?php
            foreach ($books as $book) {
                get_template_part('template-parts/book-card', null, array('book' => $book));
            }
            ?>
        </div>
    </section>
    <?php
}
