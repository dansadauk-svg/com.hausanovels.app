<?php
/**
 * Book genre archive template.
 *
 * @package HausanovelsDark
 */

get_header();
$term = get_queried_object();
?>
<section class="hn-hero">
    <div>
        <p class="hn-eyebrow"><?php esc_html_e('Hausa novel category', 'hausanovels'); ?></p>
        <h1><?php echo esc_html($term && ! is_wp_error($term) ? $term->name : __('Category', 'hausanovels')); ?></h1>
    </div>
</section>

<?php if (have_posts()) : ?>
    <section class="hn-section">
        <div class="hn-section-head">
            <h2><?php esc_html_e('Books in this category', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-book-grid">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/book-card', null, array('book' => hausanovels_book_from_post(get_post())));
            endwhile;
            ?>
        </div>
    </section>
<?php endif; ?>

<?php
the_posts_pagination(array(
    'mid_size'  => 1,
    'prev_text' => __('Newer', 'hausanovels'),
    'next_text' => __('Older', 'hausanovels'),
));

get_footer();
