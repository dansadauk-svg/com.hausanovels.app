<?php
/**
 * Footer template.
 *
 * @package HausanovelsDark
 */
?>
    </main>

    <?php $hn_publisher_only = function_exists('hausanovels_is_publisher_only') && hausanovels_is_publisher_only(); ?>
    <nav class="hn-bottom-nav <?php echo esc_attr($hn_publisher_only ? 'is-publisher' : ''); ?>" aria-label="<?php esc_attr_e('App menu', 'hausanovels'); ?>">
        <?php if ($hn_publisher_only) : ?>
            <a href="<?php echo esc_url(hausanovels_app_url('publisher')); ?>" class="<?php echo hausanovels_is_publisher_page() ? 'is-active' : ''; ?>">
                <?php echo hausanovels_icon('grid'); ?>
                <span><?php esc_html_e('Publisher', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(home_url('/publisher/books/')); ?>">
                <?php echo hausanovels_icon('book'); ?>
                <span><?php esc_html_e('Books', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(home_url('/publisher/chapters/')); ?>">
                <?php echo hausanovels_icon('book'); ?>
                <span><?php esc_html_e('Chapters', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(home_url('/publisher/earnings/')); ?>">
                <?php echo hausanovels_icon('wallet'); ?>
                <span><?php esc_html_e('Earnings', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(hausanovels_app_url('account')); ?>" class="<?php echo hausanovels_is_app_page('account') ? 'is-active' : ''; ?>">
                <?php echo hausanovels_icon('user'); ?>
                <span><?php esc_html_e('Account', 'hausanovels'); ?></span>
            </a>
        <?php else : ?>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo is_front_page() ? 'is-active' : ''; ?>">
                <?php echo hausanovels_icon('home'); ?>
                <span><?php esc_html_e('Home', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(hausanovels_app_url('library')); ?>" class="<?php echo hausanovels_is_app_page('library') ? 'is-active' : ''; ?>">
                <?php echo hausanovels_icon('book'); ?>
                <span><?php esc_html_e('Library', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(hausanovels_app_url('discover')); ?>" class="<?php echo hausanovels_is_app_page('discover') ? 'is-active' : ''; ?>">
                <?php echo hausanovels_icon('search'); ?>
                <span><?php esc_html_e('Discover', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(hausanovels_app_url('wallet')); ?>" class="<?php echo hausanovels_is_app_page('wallet') ? 'is-active' : ''; ?>">
                <?php echo hausanovels_icon('wallet'); ?>
                <span><?php esc_html_e('Wallet', 'hausanovels'); ?></span>
            </a>
            <a href="<?php echo esc_url(hausanovels_app_url('account')); ?>" class="<?php echo (hausanovels_is_app_page('account') || hausanovels_is_reader_page() || hausanovels_is_publisher_page()) ? 'is-active' : ''; ?>">
                <?php echo hausanovels_icon('user'); ?>
                <span><?php esc_html_e('Account', 'hausanovels'); ?></span>
            </a>
        <?php endif; ?>
    </nav>

    <footer class="hn-site-footer">
        <p>&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php bloginfo('name'); ?>. <?php esc_html_e('Hausa stories, chapters, and coins.', 'hausanovels'); ?></p>
    </footer>
</div>

<?php wp_footer(); ?>
</body>
</html>
