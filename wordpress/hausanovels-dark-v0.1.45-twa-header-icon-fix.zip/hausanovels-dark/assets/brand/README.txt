HausaNovels brand icon

icon-192.png: header and PWA icon
icon-512.png: manifest, Apple touch icon and social fallback

The high-resolution transparent source is distributed separately from the theme to keep the installed theme lightweight.
