(function () {
    const body = document.body;
    const drawer = document.getElementById('hn-drawer');
    const toggle = document.querySelector('.hn-menu-toggle');
    const closeTargets = document.querySelectorAll('[data-drawer-close]');

    function setDrawer(open) {
        body.classList.toggle('hn-drawer-open', open);
        if (drawer) {
            drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
        }
        if (toggle) {
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
    }

    if (toggle) {
        toggle.addEventListener('click', function () {
            setDrawer(!body.classList.contains('hn-drawer-open'));
        });
    }

    closeTargets.forEach(function (target) {
        target.addEventListener('click', function () {
            setDrawer(false);
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            setDrawer(false);
        }
    });
})();

(function () {
    const reader = document.querySelector('[data-hn-reader]');
    if (!reader) {
        return;
    }

    const buttons = reader.querySelectorAll('[data-reader-theme-value]');
    const storageKey = 'hn-reader-theme';

    function applyTheme(theme) {
        const safeTheme = theme === 'light' ? 'light' : 'dark';
        reader.setAttribute('data-reader-theme', safeTheme);
        buttons.forEach(function (button) {
            button.setAttribute('aria-pressed', button.getAttribute('data-reader-theme-value') === safeTheme ? 'true' : 'false');
        });

        try {
            window.localStorage.setItem(storageKey, safeTheme);
        } catch (error) {}
    }

    let savedTheme = 'dark';
    try {
        savedTheme = window.localStorage.getItem(storageKey) || 'dark';
    } catch (error) {}

    applyTheme(savedTheme);

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            applyTheme(button.getAttribute('data-reader-theme-value'));
        });
    });
}());
