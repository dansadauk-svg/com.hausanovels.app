<?php
/**
 * Single book template.
 *
 * @package HausanovelsDark
 */

get_header();

while (have_posts()) :
    the_post();

    $book_id = get_the_ID();
    $book = hausanovels_book_from_post(get_post());
    $author_name = trim((string) get_post_meta($book_id, '_hn_author_name', true));
    $book_status = sanitize_key((string) get_post_meta($book_id, '_hn_book_status', true));
    $chapters = hausanovels_get_book_chapters_fresh($book_id);
    $chapter_count = count($chapters);
    $first_chapter = $chapters ? reset($chapters) : null;
    $start_url = $first_chapter instanceof WP_Post
        ? (is_user_logged_in() ? get_permalink($first_chapter) : hausanovels_signin_url(get_permalink($first_chapter)))
        : '#chapters';

    $genres = taxonomy_exists('hn_genre') ? wp_get_post_terms($book_id, 'hn_genre') : array();
    if (is_wp_error($genres)) {
        $genres = array();
    }

    $raw_content = trim((string) get_post_field('post_content', $book_id));
    $summary_source = has_excerpt() ? get_the_excerpt() : wp_strip_all_tags(strip_shortcodes($raw_content));
    $summary = wp_trim_words(trim((string) $summary_source), 42, '…');
    ?>
    <article class="hn-book-detail">
        <div class="hn-book-detail-cover">
            <img
                src="<?php echo esc_url($book['cover']); ?>"
                alt="<?php echo esc_attr(sprintf(__('%s book cover', 'hausanovels'), $book['title'])); ?>"
                width="420"
                height="630"
                loading="eager"
                decoding="async"
                fetchpriority="high"
            >
            <span class="hn-book-badge">
                <?php echo hausanovels_icon('book'); ?>
                <span><?php echo esc_html($chapter_count > 0 ? __('Ready to read', 'hausanovels') : __('Coming soon', 'hausanovels')); ?></span>
            </span>
        </div>

        <div class="hn-book-detail-body">
            <p class="hn-eyebrow"><?php esc_html_e('Hausa novel', 'hausanovels'); ?></p>
            <h1><?php the_title(); ?></h1>

            <?php if ($author_name) : ?>
                <p class="hn-book-author"><?php echo esc_html(sprintf(__('By %s', 'hausanovels'), $author_name)); ?></p>
            <?php endif; ?>

            <div class="hn-book-meta" aria-label="<?php esc_attr_e('Book information', 'hausanovels'); ?>">
                <?php if ($book_status) : ?>
                    <span><?php echo esc_html(ucfirst($book_status)); ?></span>
                <?php endif; ?>
                <span><?php echo esc_html(sprintf(_n('%d chapter', '%d chapters', $chapter_count, 'hausanovels'), $chapter_count)); ?></span>
                <?php foreach (array_slice($genres, 0, 2) as $genre) : ?>
                    <?php $genre_link = get_term_link($genre); ?>
                    <?php if (! is_wp_error($genre_link)) : ?>
                        <a href="<?php echo esc_url($genre_link); ?>"><?php echo esc_html($genre->name); ?></a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <?php if ($summary) : ?>
                <div class="hn-book-description">
                    <p><?php echo esc_html($summary); ?></p>
                </div>
            <?php endif; ?>

            <div class="hn-book-actions">
                <a class="hn-hero-action<?php echo $first_chapter ? '' : ' is-disabled'; ?>" href="<?php echo esc_url($start_url); ?>">
                    <?php echo hausanovels_icon('book'); ?>
                    <span><?php echo esc_html($first_chapter ? __('Start Reading', 'hausanovels') : __('View Chapters', 'hausanovels')); ?></span>
                </a>
                <?php if (shortcode_exists('hn_bookmark_button')) : ?>
                    <?php echo do_shortcode('[hn_bookmark_button post_id="' . absint($book_id) . '"]'); ?>
                <?php endif; ?>
            </div>
        </div>
    </article>

    <?php if ($raw_content) : ?>
        <section class="hn-section hn-book-about" id="about-book">
            <div class="hn-section-head">
                <h2><?php esc_html_e('About This Book', 'hausanovels'); ?></h2>
                <span class="hn-section-line" aria-hidden="true"></span>
            </div>
            <div class="hn-book-about-content">
                <?php echo apply_filters('the_content', $raw_content); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="hn-section" id="chapters">
        <div class="hn-section-head">
            <h2><?php esc_html_e('Chapters', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
            <?php if ($chapter_count > 0) : ?>
                <span class="hn-section-count"><?php echo esc_html(number_format_i18n($chapter_count)); ?></span>
            <?php endif; ?>
        </div>
        <?php echo hausanovels_render_fresh_chapter_list($book_id, $chapters); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </section>

    <section class="hn-section hn-reviews-section" id="reviews">
        <div class="hn-section-head">
            <h2><?php esc_html_e('Reader Reviews', 'hausanovels'); ?></h2>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <?php comments_template(); ?>
    </section>
    <?php
endwhile;

get_footer();
