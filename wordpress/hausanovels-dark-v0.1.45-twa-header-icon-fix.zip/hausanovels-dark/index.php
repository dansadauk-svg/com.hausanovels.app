<?php
/**
 * Fallback template.
 *
 * @package HausanovelsDark
 */

get_header();

if (have_posts()) :
    ?>
    <section class="hn-section">
        <div class="hn-section-head">
            <h1><?php echo esc_html(is_home() ? get_bloginfo('name') : wp_get_document_title()); ?></h1>
            <span class="hn-section-line" aria-hidden="true"></span>
        </div>
        <div class="hn-book-row">
            <?php
            while (have_posts()) :
                the_post();
                get_template_part('template-parts/book-card', null, array(
                    'book' => array(
                        'id'        => get_the_ID(),
                        'title'     => get_the_title(),
                        'premium'   => false,
                        'permalink' => get_permalink(),
                        'cover'     => get_the_post_thumbnail_url(get_the_ID(), 'hausanovels-cover') ?: hausanovels_sample_cover(get_the_title()),
                    ),
                ));
            endwhile;
            ?>
        </div>
    </section>
    <?php
else :
    ?>
    <section class="hn-hero">
        <div>
            <p class="hn-eyebrow"><?php esc_html_e('No books found', 'hausanovels'); ?></p>
            <h1><?php esc_html_e('Try searching for another Hausa novel.', 'hausanovels'); ?></h1>
        </div>
    </section>
    <?php
endif;

get_footer();
