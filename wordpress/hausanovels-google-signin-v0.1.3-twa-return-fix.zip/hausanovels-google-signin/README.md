# HausaNovels Google Sign-In v0.1.1

Google OAuth sign-in for the HausaNovels website and Android WebView app.

## Android return fix

The browser and Android WebView do not share WordPress cookies. This version uses a short-lived, one-time app login token:

1. The app opens Google authentication in the secure system browser.
2. Google returns to the HTTPS WordPress callback.
3. WordPress completes Google OAuth and creates a one-time token valid for three minutes.
4. The browser opens `hausanovels://oauth/callback`.
5. The Android app receives the link and loads the one-time login endpoint inside its WebView.
6. WordPress sets the login cookie inside the WebView and redirects to the requested app page.

The token is deleted on first use.

## Google Cloud

Use a **Web application** OAuth client. Keep this exact Authorized Redirect URI:

```text
https://hausanovels.ng/?hn_google_callback=1
```

Do not add the `hausanovels://` custom scheme to Google Cloud. It is used only after the secure server callback is complete.

## Required Android package

```text
ng.hausanovels.app
```

Install the matching Android source v1.3.0 or newer.


## Version 0.1.3

- Uses the standard HTTPS OAuth return inside the Trusted Web Activity.
- Keeps Google authentication in the secure browser instead of an embedded WebView.
- Prevents TWA sessions from being sent through the old custom-scheme bridge.
- Keeps the legacy one-time bridge for older WebView APKs.
- The Google Cloud redirect URI remains `https://hausanovels.ng/?hn_google_callback=1`.


## TWA return fix (0.1.3)

After Google completes the HTTPS OAuth callback, the plugin opens the package-restricted `hausanovels://oauth/callback` deep link. The Android project validates the return URL and relaunches the verified TWA account page. The Google Cloud redirect URI remains the normal HTTPS callback.
