<?php
/**
 * Plugin Name: HausaNovels Google Sign-In
 * Plugin URI: https://hausanovels.ng/
 * Description: Secure Google sign-in for the HausaNovels website and Android app, with a browser-native TWA flow and a legacy one-time return bridge for older WebView builds.
 * Version: 0.1.3
 * Author: HausaNovels
 * Text Domain: hausanovels-google
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (! defined('ABSPATH')) {
    exit;
}

define('HAUSANOVELS_GOOGLE_VERSION', '0.1.3');

final class HausaNovels_Google_Signin
{
    private const OPTION_NAME = 'hausanovels_google_signin_settings';
    private const STATE_PREFIX = 'hn_google_state_';
    private const APP_TOKEN_PREFIX = 'hn_google_app_token_';
    private const APP_COOKIE = 'hn_android_app';
    private const TWA_COOKIE = 'hn_twa';
    private const APP_SCHEME = 'hausanovels';
    private const APP_PACKAGE = 'ng.hausanovels.app';

    public static function init(): void
    {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_post_nopriv_hn_google_start', array(__CLASS__, 'start'));
        add_action('admin_post_hn_google_start', array(__CLASS__, 'start'));
        add_action('template_redirect', array(__CLASS__, 'handle_frontend_callbacks'), 0);
        add_shortcode('hn_google_signin', array(__CLASS__, 'shortcode'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'styles'));
    }

    public static function defaults(): array
    {
        return array(
            'client_id'     => '',
            'client_secret' => '',
        );
    }

    public static function settings(): array
    {
        return wp_parse_args((array) get_option(self::OPTION_NAME, array()), self::defaults());
    }

    public static function redirect_uri(): string
    {
        return home_url('/?hn_google_callback=1');
    }

    public static function admin_menu(): void
    {
        $parent = post_type_exists('hn_book') ? 'edit.php?post_type=hn_book' : 'options-general.php';
        add_submenu_page(
            $parent,
            __('Google Sign-In', 'hausanovels-google'),
            __('Google Sign-In', 'hausanovels-google'),
            'manage_options',
            'hausanovels-google-signin',
            array(__CLASS__, 'admin_page')
        );
    }

    public static function admin_page(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $message = '';
        if (isset($_POST['hn_google_save'])) {
            check_admin_referer('hn_google_save_settings', 'hn_google_nonce');
            $current = self::settings();
            $secret = trim((string) sanitize_text_field(wp_unslash($_POST['client_secret'] ?? '')));
            update_option(self::OPTION_NAME, array(
                'client_id'     => sanitize_text_field(wp_unslash($_POST['client_id'] ?? '')),
                'client_secret' => '' !== $secret ? $secret : (string) $current['client_secret'],
            ));
            $message = __('Google Sign-In settings saved.', 'hausanovels-google');
        }

        $settings = self::settings();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('HausaNovels Google Sign-In', 'hausanovels-google'); ?></h1>
            <?php if ($message) : ?><div class="notice notice-success"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
            <p><?php esc_html_e('Create an OAuth client of type Web application in Google Cloud, then add the redirect URI below exactly as displayed.', 'hausanovels-google'); ?></p>
            <p><strong><?php esc_html_e('Authorized redirect URI:', 'hausanovels-google'); ?></strong><br><code><?php echo esc_html(self::redirect_uri()); ?></code></p>
            <p><?php esc_html_e('The Trusted Web Activity uses the normal HTTPS callback and shares the Chrome sign-in session. The one-time custom app bridge is retained only for older WebView builds. Do not add the custom app scheme to Google Cloud.', 'hausanovels-google'); ?></p>
            <form method="post" style="max-width:760px;">
                <?php wp_nonce_field('hn_google_save_settings', 'hn_google_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="hn-google-client-id"><?php esc_html_e('Web Client ID', 'hausanovels-google'); ?></label></th>
                        <td><input id="hn-google-client-id" name="client_id" class="large-text" value="<?php echo esc_attr((string) $settings['client_id']); ?>" placeholder="...apps.googleusercontent.com"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hn-google-secret"><?php esc_html_e('Web Client Secret', 'hausanovels-google'); ?></label></th>
                        <td><input id="hn-google-secret" type="password" name="client_secret" class="regular-text" value="" autocomplete="off" placeholder="<?php echo esc_attr($settings['client_secret'] ? __('Saved - leave blank to keep', 'hausanovels-google') : 'GOCSPX-...'); ?>"></td>
                    </tr>
                </table>
                <p><button class="button button-primary" name="hn_google_save" value="1"><?php esc_html_e('Save Settings', 'hausanovels-google'); ?></button></p>
            </form>
        </div>
        <?php
    }

    public static function styles(): void
    {
        if (! is_singular() && ! get_query_var('hn_app_page')) {
            return;
        }

        wp_register_style('hausanovels-google-signin', false, array(), HAUSANOVELS_GOOGLE_VERSION);
        wp_enqueue_style('hausanovels-google-signin');
        wp_add_inline_style('hausanovels-google-signin', '
            .hn-google-signin{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:46px;border:1px solid rgba(168,179,199,.25);border-radius:9px;background:#fff;color:#1f2937;padding:10px 14px;font-weight:800;text-decoration:none;box-sizing:border-box}
            .hn-google-signin:hover,.hn-google-signin:focus{border-color:rgba(66,133,244,.65);color:#111827}
            .hn-google-signin svg{width:20px;height:20px;flex:0 0 20px}
        ');
    }

    public static function shortcode(array $atts = array()): string
    {
        $settings = self::settings();
        if ('' === trim((string) $settings['client_id']) || '' === trim((string) $settings['client_secret'])) {
            return current_user_can('manage_options')
                ? '<p class="hn-auth-alert">' . esc_html__('Google Sign-In is not configured yet.', 'hausanovels-google') . '</p>'
                : '';
        }

        $atts = shortcode_atts(array(
            'redirect_to' => home_url('/account/'),
        ), $atts, 'hn_google_signin');

        $redirect = wp_validate_redirect((string) $atts['redirect_to'], home_url('/account/'));
        $args = array(
            'action'      => 'hn_google_start',
            'redirect_to' => $redirect,
        );

        if (self::is_twa_request()) {
            $args['twa'] = '1';
        } elseif (self::is_android_app_request()) {
            $args['app'] = '1';
        }

        $url = add_query_arg($args, admin_url('admin-post.php'));
        $icon = '<svg viewBox="0 0 18 18" aria-hidden="true"><path fill="#4285F4" d="M17.64 9.205c0-.638-.057-1.252-.164-1.841H9v3.482h4.844a4.14 4.14 0 0 1-1.797 2.715v2.258h2.909c1.702-1.567 2.684-3.874 2.684-6.614z"/><path fill="#34A853" d="M9 18c2.43 0 4.468-.806 5.956-2.181l-2.909-2.258c-.806.54-1.836.859-3.047.859-2.344 0-4.328-1.585-5.037-3.715H.956v2.332A9 9 0 0 0 9 18z"/><path fill="#FBBC05" d="M3.963 10.705A5.42 5.42 0 0 1 3.682 9c0-.592.102-1.167.281-1.705V4.963H.956A9 9 0 0 0 0 9c0 1.452.347 2.827.956 4.037l3.007-2.332z"/><path fill="#EA4335" d="M9 3.58c1.322 0 2.508.454 3.441 1.345l2.582-2.582C13.464.892 11.426 0 9 0A9 9 0 0 0 .956 4.963l3.007 2.332C4.672 5.165 6.656 3.58 9 3.58z"/></svg>';

        return '<a class="hn-google-signin" href="' . esc_url($url) . '">' . $icon . '<span>' . esc_html__('Continue with Google', 'hausanovels-google') . '</span></a>';
    }

    public static function start(): void
    {
        $settings = self::settings();
        $client_id = trim((string) $settings['client_id']);
        $client_secret = trim((string) $settings['client_secret']);
        $signin = function_exists('hausanovels_signin_url') ? hausanovels_signin_url() : wp_login_url();

        if ('' === $client_id || '' === $client_secret) {
            wp_safe_redirect(add_query_arg('google_login', 'not-configured', $signin));
            exit;
        }

        $redirect = wp_validate_redirect(
            esc_url_raw(wp_unslash($_GET['redirect_to'] ?? home_url('/account/'))),
            home_url('/account/')
        );
        $twa_mode = '1' === sanitize_text_field(wp_unslash($_GET['twa'] ?? '')) || self::is_twa_request();
        $app_mode = ! $twa_mode && (('1' === sanitize_text_field(wp_unslash($_GET['app'] ?? ''))) || self::is_android_app_request());
        $state = bin2hex(random_bytes(24));
        set_transient(self::STATE_PREFIX . $state, array(
            'redirect' => $redirect,
            'app'      => $app_mode ? 1 : 0,
            'twa'      => $twa_mode ? 1 : 0,
        ), 10 * MINUTE_IN_SECONDS);

        $auth_url = add_query_arg(array(
            'client_id'     => $client_id,
            'redirect_uri'  => self::redirect_uri(),
            'response_type' => 'code',
            'scope'         => 'openid email profile',
            'state'         => $state,
            'prompt'        => 'select_account',
            'access_type'   => 'online',
            'include_granted_scopes' => 'true',
        ), 'https://accounts.google.com/o/oauth2/v2/auth');

        wp_redirect($auth_url);
        exit;
    }

    public static function handle_frontend_callbacks(): void
    {
        if (isset($_GET['hn_google_app_login'])) {
            self::complete_app_login();
        }

        if (isset($_GET['hn_google_callback'])) {
            self::google_callback();
        }
    }

    private static function google_callback(): void
    {
        $signin = function_exists('hausanovels_signin_url') ? hausanovels_signin_url() : wp_login_url();
        $state = sanitize_text_field(wp_unslash($_GET['state'] ?? ''));
        $stored = $state ? get_transient(self::STATE_PREFIX . $state) : false;
        if (! is_array($stored)) {
            wp_safe_redirect(add_query_arg('google_login', 'state', $signin));
            exit;
        }
        delete_transient(self::STATE_PREFIX . $state);

        if (! empty($_GET['error'])) {
            wp_safe_redirect(add_query_arg('google_login', 'cancelled', $signin));
            exit;
        }

        $code = sanitize_text_field(wp_unslash($_GET['code'] ?? ''));
        if ('' === $code) {
            wp_safe_redirect(add_query_arg('google_login', 'missing-code', $signin));
            exit;
        }

        $settings = self::settings();
        $token_response = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'timeout' => 15,
            'body'    => array(
                'code'          => $code,
                'client_id'     => (string) $settings['client_id'],
                'client_secret' => (string) $settings['client_secret'],
                'redirect_uri'  => self::redirect_uri(),
                'grant_type'    => 'authorization_code',
            ),
        ));

        if (is_wp_error($token_response) || 200 !== (int) wp_remote_retrieve_response_code($token_response)) {
            wp_safe_redirect(add_query_arg('google_login', 'token-error', $signin));
            exit;
        }

        $token = json_decode((string) wp_remote_retrieve_body($token_response), true);
        $access_token = is_array($token) ? sanitize_text_field((string) ($token['access_token'] ?? '')) : '';
        if ('' === $access_token) {
            wp_safe_redirect(add_query_arg('google_login', 'token-error', $signin));
            exit;
        }

        $profile_response = wp_remote_get('https://openidconnect.googleapis.com/v1/userinfo', array(
            'timeout' => 15,
            'headers' => array('Authorization' => 'Bearer ' . $access_token),
        ));
        if (is_wp_error($profile_response) || 200 !== (int) wp_remote_retrieve_response_code($profile_response)) {
            wp_safe_redirect(add_query_arg('google_login', 'profile-error', $signin));
            exit;
        }

        $profile = json_decode((string) wp_remote_retrieve_body($profile_response), true);
        $email = is_array($profile) ? sanitize_email((string) ($profile['email'] ?? '')) : '';
        $verified = ! empty($profile['email_verified']);
        $name = sanitize_text_field((string) ($profile['name'] ?? ''));
        $sub = sanitize_text_field((string) ($profile['sub'] ?? ''));

        if (! is_email($email) || ! $verified) {
            wp_safe_redirect(add_query_arg('google_login', 'unverified-email', $signin));
            exit;
        }

        $user = self::find_or_create_user($email, $name, $sub);
        if (! $user instanceof WP_User) {
            wp_safe_redirect(add_query_arg('google_login', 'user-error', $signin));
            exit;
        }

        $redirect = wp_validate_redirect((string) ($stored['redirect'] ?? ''), home_url('/account/'));
        $app_mode = ! empty($stored['app']);
        $twa_mode = ! empty($stored['twa']);

        // Establish the WordPress session in Chrome. The TWA uses the same cookie jar.
        self::sign_in_user($user);

        if ($twa_mode) {
            self::send_twa_back_to_android($redirect);
        }

        if ($app_mode) {
            self::send_user_back_to_android($user, $redirect);
        }

        wp_safe_redirect(add_query_arg('google_login', 'success', $redirect));
        exit;
    }

    private static function find_or_create_user(string $email, string $name, string $sub): ?WP_User
    {
        $user = get_user_by('email', $email);
        if (! $user instanceof WP_User) {
            $base = sanitize_user(strstr($email, '@', true) ?: 'reader', true) ?: 'reader';
            $username = $base;
            $suffix = 1;
            while (username_exists($username)) {
                $username = $base . $suffix;
                $suffix++;
            }

            $user_id = wp_insert_user(array(
                'user_login'   => $username,
                'user_email'   => $email,
                'display_name' => $name ?: $username,
                'user_pass'    => wp_generate_password(32, true, true),
                'role'         => 'subscriber',
            ));
            if (is_wp_error($user_id)) {
                return null;
            }
            update_user_meta((int) $user_id, '_hn_account_type', 'reader');
            $user = get_user_by('id', (int) $user_id);
        }

        if (! $user instanceof WP_User) {
            return null;
        }

        if ('' !== $sub) {
            update_user_meta((int) $user->ID, '_hn_google_sub', $sub);
        }

        return $user;
    }

    private static function sign_in_user(WP_User $user): void
    {
        wp_set_current_user((int) $user->ID);
        wp_set_auth_cookie((int) $user->ID, true, is_ssl());
        do_action('wp_login', $user->user_login, $user);
    }

    private static function send_twa_back_to_android(string $redirect): void
    {
        $redirect = wp_validate_redirect($redirect, home_url('/account/'));
        $redirect = add_query_arg('google_login', 'success', $redirect);
        $query = http_build_query(array('url' => $redirect), '', '&', PHP_QUERY_RFC3986);
        $custom_uri = self::APP_SCHEME . '://oauth/callback?' . $query;
        $intent_uri = 'intent://oauth/callback?' . $query
            . '#Intent;scheme=' . self::APP_SCHEME
            . ';package=' . self::APP_PACKAGE
            . ';S.browser_fallback_url=' . rawurlencode($redirect)
            . ';end';

        nocache_headers();
        status_header(200);
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));
        ?>
        <!doctype html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
            <title><?php esc_html_e('Returning to HausaNovels', 'hausanovels-google'); ?></title>
            <style>
                *{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#050816;color:#f8fafc;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;text-align:center}main{width:min(100%,400px);padding:28px 22px;border:1px solid rgba(168,179,199,.2);border-radius:18px;background:#0b1020;box-shadow:0 24px 70px rgba(0,0,0,.4)}h1{margin:0 0 10px;font-size:1.35rem}p{margin:0 0 20px;color:#a8b3c7;line-height:1.5}a{display:flex;min-height:48px;align-items:center;justify-content:center;border-radius:11px;background:#21c77a;color:#04110b;font-weight:900;text-decoration:none}
            </style>
        </head>
        <body>
            <main>
                <h1><?php esc_html_e('Sign-in complete', 'hausanovels-google'); ?></h1>
                <p><?php esc_html_e('Returning you to the HausaNovels app. Tap the button if Android does not switch automatically.', 'hausanovels-google'); ?></p>
                <a id="hn-return-app" href="<?php echo esc_attr($intent_uri); ?>"><?php esc_html_e('Return to HausaNovels', 'hausanovels-google'); ?></a>
            </main>
            <script>
                (function () {
                    var intentUrl = <?php echo wp_json_encode($intent_uri); ?>;
                    var customUrl = <?php echo wp_json_encode($custom_uri); ?>;
                    window.setTimeout(function () { window.location.href = intentUrl; }, 160);
                    window.setTimeout(function () { window.location.href = customUrl; }, 900);
                }());
            </script>
        </body>
        </html>
        <?php
        exit;
    }

    private static function send_user_back_to_android(WP_User $user, string $redirect): void
    {
        $plain_token = bin2hex(random_bytes(32));
        $token_key = self::APP_TOKEN_PREFIX . hash('sha256', $plain_token);
        set_transient($token_key, array(
            'user_id'  => (int) $user->ID,
            'redirect' => $redirect,
        ), 3 * MINUTE_IN_SECONDS);

        $query = http_build_query(array(
            'token'    => $plain_token,
            'redirect' => $redirect,
        ), '', '&', PHP_QUERY_RFC3986);
        $custom_uri = self::APP_SCHEME . '://oauth/callback?' . $query;
        $fallback = add_query_arg('google_login', 'app-return', $redirect);
        $intent_uri = 'intent://oauth/callback?' . $query
            . '#Intent;scheme=' . self::APP_SCHEME
            . ';package=' . self::APP_PACKAGE
            . ';S.browser_fallback_url=' . rawurlencode($fallback)
            . ';end';

        nocache_headers();
        status_header(200);
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));
        ?>
        <!doctype html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
            <title><?php esc_html_e('Returning to HausaNovels', 'hausanovels-google'); ?></title>
            <style>
                *{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#050816;color:#f8fafc;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;text-align:center}main{width:min(100%,420px);padding:26px;border:1px solid rgba(168,179,199,.2);border-radius:16px;background:#0b1020;box-shadow:0 24px 70px rgba(0,0,0,.4)}h1{margin:0 0 10px;font-size:1.35rem}p{margin:0 0 20px;color:#a8b3c7;line-height:1.5}a{display:flex;min-height:48px;align-items:center;justify-content:center;border-radius:10px;background:#21c77a;color:#04110b;font-weight:900;text-decoration:none}
            </style>
        </head>
        <body>
            <main>
                <h1><?php esc_html_e('Sign-in successful', 'hausanovels-google'); ?></h1>
                <p><?php esc_html_e('Returning you to the HausaNovels app. Tap the button if the app does not open automatically.', 'hausanovels-google'); ?></p>
                <a id="hn-open-app" href="<?php echo esc_attr($intent_uri); ?>"><?php esc_html_e('Open HausaNovels App', 'hausanovels-google'); ?></a>
            </main>
            <script>
                (function () {
                    var intentUrl = <?php echo wp_json_encode($intent_uri); ?>;
                    var customUrl = <?php echo wp_json_encode($custom_uri); ?>;
                    window.setTimeout(function () { window.location.href = intentUrl; }, 100);
                    window.setTimeout(function () { window.location.href = customUrl; }, 900);
                }());
            </script>
        </body>
        </html>
        <?php
        exit;
    }

    private static function complete_app_login(): void
    {
        $plain_token = sanitize_text_field(wp_unslash($_GET['token'] ?? ''));
        if (! preg_match('/^[a-f0-9]{64}$/', $plain_token)) {
            self::app_login_error('invalid-token');
        }

        $token_key = self::APP_TOKEN_PREFIX . hash('sha256', $plain_token);
        $payload = get_transient($token_key);
        delete_transient($token_key);

        if (! is_array($payload) || empty($payload['user_id'])) {
            self::app_login_error('expired-token');
        }

        $user = get_user_by('id', absint($payload['user_id']));
        if (! $user instanceof WP_User) {
            self::app_login_error('user-error');
        }

        self::sign_in_user($user);
        $redirect = wp_validate_redirect((string) ($payload['redirect'] ?? ''), home_url('/account/'));
        wp_safe_redirect(add_query_arg('google_login', 'success', $redirect));
        exit;
    }

    private static function app_login_error(string $code): void
    {
        $signin = function_exists('hausanovels_signin_url') ? hausanovels_signin_url() : wp_login_url();
        wp_safe_redirect(add_query_arg('google_login', sanitize_key($code), $signin));
        exit;
    }

    private static function is_twa_request(): bool
    {
        if (function_exists('hn_pwa_is_twa_request') && hn_pwa_is_twa_request()) {
            return true;
        }

        if ('1' === sanitize_text_field(wp_unslash($_COOKIE[self::TWA_COOKIE] ?? ''))) {
            return true;
        }

        $source = sanitize_key(wp_unslash($_GET['utm_source'] ?? $_GET['source'] ?? ''));
        return 'twa' === $source || '1' === sanitize_text_field(wp_unslash($_GET['twa'] ?? ''));
    }

    private static function is_android_app_request(): bool
    {
        $cookie = sanitize_text_field(wp_unslash($_COOKIE[self::APP_COOKIE] ?? ''));
        if ('1' === $cookie) {
            return true;
        }

        $user_agent = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''));
        return false !== stripos($user_agent, 'HausaNovelsApp/');
    }
}

HausaNovels_Google_Signin::init();
