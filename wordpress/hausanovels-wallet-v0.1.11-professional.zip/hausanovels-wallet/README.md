# Hausanovels Wallet & Coins

Second plugin for Hausanovels.ng.

## What It Adds

- Coin wallet for every user
- Coin balance table
- Full credit/debit ledger
- Chapter unlock table
- Premium chapter protection
- Unlock form and locked chapter message
- Admin wallet credit/debit tool
- Wallet shortcode for users
- Wallet history empty state for new readers
- Plugin-powered `/wallet/` page
- Reader registration shortcuts for logged-out wallet/unlock views
- Logged-out visitors must register or sign in before reading any chapter
- Publisher-only account blocking for reader wallet/chapter unlocks
- Unlock records use the shared chapter parent resolver, so older chapters linked through legacy meta or `post_parent` still connect to the right book

## Database Tables

- `wp_hn_wallets`
- `wp_hn_wallet_ledger`
- `wp_hn_unlocked_chapters`

The table prefix follows the site database prefix, so it may not always be `wp_`.

## Shortcodes

```text
[hn_wallet]
[hn_unlock_button chapter_id="123"]
```

The plugin also creates `/wallet/` automatically. When the Paystack Funding plugin is active, that page will show wallet balance and Paystack coin bundles first.

## Functions For Future Plugins

```php
hn_wallet_get_balance($user_id);
hn_wallet_credit($user_id, $amount, $description, $external_reference, $reference_type, $reference_id);
hn_wallet_debit($user_id, $amount, $description, $reference_type, $reference_id);
hn_wallet_has_unlocked($user_id, $chapter_id);
hn_wallet_unlock_chapter($user_id, $chapter_id);
```

## Next Plugin

Funding plugins should call `hn_wallet_credit()` only after payment has been confirmed.

Publisher-only accounts do not use reader coin wallets. Writers who also want to read should register a separate reader account with a different email address.

## Performance update

This package includes request reduction, query optimization, and safer high-traffic behavior from the July 2026 performance audit. Review PERFORMANCE-AUDIT.md in the complete bundle for deployment guidance.


## Version 0.1.10

- Places Paystack coin packages before wallet balance and transaction history on the plugin-powered wallet route.
- Keeps the same purchase-first order when plugin rewrite rules handle `/wallet/` instead of the theme route.


## Version 0.1.11

- Shows the wallet balance first, coin bundles second, and transaction history last.
- Adds `[hn_wallet_balance]` and `[hn_wallet_history]` shortcodes.
- Replaces the old table with a professional mobile transaction list.
- Loads wallet styles correctly on the theme-powered `/wallet/` app route.
