<?php
/**
 * Plugin Name: Hausanovels Wallet & Coins
 * Plugin URI: https://hausanovels.ng/
 * Description: Wallet, coin ledger, and premium chapter unlock system for Hausanovels.ng.
 * Version: 0.1.11
 * Author: Hausanovels
 * Text Domain: hausanovels-wallet
 * Requires at least: 6.0
 * Requires PHP: 8.0
 *
 * @package HausanovelsWallet
 */

if (! defined('ABSPATH')) {
    exit;
}

define('HAUSANOVELS_WALLET_VERSION', '0.1.11');
define('HAUSANOVELS_WALLET_FILE', __FILE__);

final class Hausanovels_Wallet_Plugin
{
    private static array $wallet_cache = array();
    private static array $unlock_cache = array();

    public static function init(): void
    {
        add_action('admin_notices', array(__CLASS__, 'dependency_notice'));
        add_action('init', array(__CLASS__, 'register_wallet_route'));
        add_filter('query_vars', array(__CLASS__, 'query_vars'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'frontend_styles'));
        add_action('template_redirect', array(__CLASS__, 'handle_unlock_request'));
        add_action('template_redirect', array(__CLASS__, 'render_wallet_route'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_filter('hausanovels_user_can_read_chapter', array(__CLASS__, 'filter_user_can_read_chapter'), 10, 3);
        add_filter('the_content', array(__CLASS__, 'protect_chapter_content'));
        add_shortcode('hn_wallet', array(__CLASS__, 'shortcode_wallet'));
        add_shortcode('hn_wallet_balance', array(__CLASS__, 'shortcode_wallet_balance'));
        add_shortcode('hn_wallet_history', array(__CLASS__, 'shortcode_wallet_history'));
        add_shortcode('hn_unlock_button', array(__CLASS__, 'shortcode_unlock_button'));
    }

    public static function activate(): void
    {
        self::create_tables();
        self::register_wallet_route();
        flush_rewrite_rules();
    }

    public static function register_wallet_route(): void
    {
        add_rewrite_rule('^wallet/?$', 'index.php?hn_wallet_page=1', 'top');
    }

    public static function query_vars(array $vars): array
    {
        $vars[] = 'hn_wallet_page';
        return $vars;
    }

    public static function render_wallet_route(): void
    {
        if (! get_query_var('hn_wallet_page')) {
            return;
        }

        status_header(200);
        nocache_headers();
        get_header();
        echo '<section class="hn-section hn-wallet-route-stack"><div class="hn-section-head"><h1>' . esc_html__('My Wallet', 'hausanovels-wallet') . '</h1><span class="hn-section-line" aria-hidden="true"></span></div>';

        echo do_shortcode('[hn_wallet_balance]');

        if (shortcode_exists('hn_paystack_topup')) {
            echo do_shortcode('[hn_paystack_topup]');
        } elseif (shortcode_exists('hn_bank_transfer_topup')) {
            echo do_shortcode('[hn_bank_transfer_topup]');
        }

        if (! shortcode_exists('hn_paystack_topup') && ! shortcode_exists('hn_bank_transfer_topup') && shortcode_exists('hn_paystack_dedicated_account')) {
            echo do_shortcode('[hn_paystack_dedicated_account]');
        }

        echo do_shortcode('[hn_wallet_history]');
        echo '</section>';
        get_footer();
        exit;
    }

    public static function dependency_notice(): void
    {
        if (class_exists('Hausanovels_Core_Plugin')) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>Hausanovels Wallet & Coins:</strong> ' . esc_html__('Please install and activate Hausanovels Core first. Wallets will work, but chapter locking needs the core plugin.', 'hausanovels-wallet') . '</p></div>';
    }

    public static function tables(): array
    {
        global $wpdb;

        return array(
            'wallets' => $wpdb->prefix . 'hn_wallets',
            'ledger'  => $wpdb->prefix . 'hn_wallet_ledger',
            'unlocks' => $wpdb->prefix . 'hn_unlocked_chapters',
        );
    }

    public static function create_tables(): void
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $tables = self::tables();
        $charset_collate = $wpdb->get_charset_collate();

        $wallets = "CREATE TABLE {$tables['wallets']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            balance bigint(20) unsigned NOT NULL DEFAULT 0,
            total_credited bigint(20) unsigned NOT NULL DEFAULT 0,
            total_debited bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY user_id (user_id)
        ) {$charset_collate};";

        $ledger = "CREATE TABLE {$tables['ledger']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            type varchar(32) NOT NULL,
            amount bigint(20) unsigned NOT NULL DEFAULT 0,
            balance_before bigint(20) unsigned NOT NULL DEFAULT 0,
            balance_after bigint(20) unsigned NOT NULL DEFAULT 0,
            reference_type varchar(64) DEFAULT NULL,
            reference_id bigint(20) unsigned DEFAULT NULL,
            external_reference varchar(191) DEFAULT NULL,
            description text,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY type (type),
            KEY reference_type (reference_type),
            UNIQUE KEY external_reference (external_reference)
        ) {$charset_collate};";

        $unlocks = "CREATE TABLE {$tables['unlocks']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            book_id bigint(20) unsigned NOT NULL DEFAULT 0,
            chapter_id bigint(20) unsigned NOT NULL,
            coins_spent bigint(20) unsigned NOT NULL DEFAULT 0,
            unlocked_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY user_chapter (user_id, chapter_id),
            KEY user_id (user_id),
            KEY chapter_id (chapter_id),
            KEY book_id (book_id)
        ) {$charset_collate};";

        dbDelta($wallets);
        dbDelta($ledger);
        dbDelta($unlocks);
    }

    public static function frontend_styles(): void
    {
        if (! self::should_load_styles()) {
            return;
        }

        wp_register_style('hausanovels-wallet', false, array(), HAUSANOVELS_WALLET_VERSION);
        wp_enqueue_style('hausanovels-wallet');
        wp_add_inline_style('hausanovels-wallet', '
            .hn-wallet-route-stack,.hn-wallet-page-stack{display:grid;gap:16px;min-width:0}
            .hn-wallet-route-stack>.hn-section-head{margin-bottom:0}
            .hn-wallet-card,.hn-locked-card{border:1px solid rgba(168,179,199,.18);border-radius:16px;padding:16px;background:rgba(17,24,39,.72);color:inherit}
            .hn-wallet-overview{position:relative;overflow:hidden;display:grid;gap:16px;border:1px solid rgba(243,179,72,.32);border-radius:20px;padding:18px;background:radial-gradient(circle at 92% 8%,rgba(243,179,72,.2),transparent 34%),linear-gradient(145deg,#121b2f,#070b18 70%);box-shadow:0 20px 46px rgba(0,0,0,.28)}
            .hn-wallet-overview:after{content:"";position:absolute;right:-45px;bottom:-65px;width:170px;height:170px;border:1px solid rgba(243,179,72,.12);border-radius:50%;pointer-events:none}
            .hn-wallet-overview-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;position:relative;z-index:1}
            .hn-wallet-eyebrow{display:block;color:#a8b3c7;font-size:.76rem;font-weight:850;letter-spacing:.08em;text-transform:uppercase}
            .hn-wallet-overview h2{margin:4px 0 0;font-size:1.08rem;line-height:1.25}
            .hn-wallet-status{display:inline-flex;align-items:center;gap:6px;flex:0 0 auto;border:1px solid rgba(33,199,122,.28);border-radius:999px;padding:6px 9px;background:rgba(33,199,122,.09);color:#82efbb;font-size:.7rem;font-weight:900}
            .hn-wallet-status:before{content:"";width:7px;height:7px;border-radius:50%;background:#21c77a;box-shadow:0 0 0 4px rgba(33,199,122,.12)}
            .hn-wallet-balance-wrap{display:flex;align-items:center;gap:13px;position:relative;z-index:1}
            .hn-wallet-coin-icon{display:grid;place-items:center;flex:0 0 auto;width:52px;height:52px;border-radius:50%;background:linear-gradient(145deg,#ffe1a3,#d58d15);color:#281700;font-size:1.05rem;font-weight:950;box-shadow:0 12px 26px rgba(243,179,72,.22),inset 0 1px 0 rgba(255,255,255,.55)}
            .hn-wallet-balance-copy{display:grid;gap:2px;min-width:0}
            .hn-wallet-balance{display:block;margin:0;color:#fff;font-size:clamp(2rem,10vw,3.25rem);line-height:.95;font-weight:950;letter-spacing:-.04em;overflow-wrap:anywhere}
            .hn-wallet-balance-label{color:#f4c975;font-size:.78rem;font-weight:900;text-transform:uppercase;letter-spacing:.08em}
            .hn-wallet-overview-note{position:relative;z-index:1;margin:0;color:#a8b3c7;font-size:.86rem;line-height:1.55}
            .hn-wallet-actions{display:flex;flex-wrap:wrap;gap:10px;margin:0;position:relative;z-index:1}
            .hn-wallet-button{display:inline-flex;min-height:43px;align-items:center;justify-content:center;border:0;border-radius:11px;padding:10px 14px;background:#21c77a;color:#04110b;font-weight:950;text-decoration:none;cursor:pointer}
            .hn-wallet-button.is-muted{border:1px solid rgba(168,179,199,.17);background:rgba(168,179,199,.11);color:#f8fafc}
            .hn-wallet-history-card{display:grid;gap:13px;border:1px solid rgba(168,179,199,.16);border-radius:18px;padding:15px;background:linear-gradient(180deg,rgba(17,24,39,.72),rgba(7,11,24,.78));min-width:0}
            .hn-wallet-history-head{display:flex;align-items:center;justify-content:space-between;gap:12px}
            .hn-wallet-history-head h2{margin:0;font-size:1.05rem}
            .hn-wallet-history-count{display:inline-flex;align-items:center;border-radius:999px;padding:5px 8px;background:rgba(168,179,199,.11);color:#a8b3c7;font-size:.7rem;font-weight:900}
            .hn-wallet-history-list{display:grid;gap:8px}
            .hn-wallet-history-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;border:1px solid rgba(168,179,199,.12);border-radius:13px;padding:11px;background:rgba(5,8,22,.44);min-width:0}
            .hn-wallet-history-main{display:grid;gap:3px;min-width:0}
            .hn-wallet-history-title{display:flex;align-items:center;gap:7px;min-width:0}
            .hn-wallet-history-title strong{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.86rem}
            .hn-wallet-history-badge{display:inline-flex;align-items:center;border-radius:999px;padding:3px 6px;font-size:.58rem;font-weight:950;text-transform:uppercase;letter-spacing:.04em}
            .hn-wallet-history-badge.is-credit{background:rgba(33,199,122,.12);color:#82efbb}
            .hn-wallet-history-badge.is-debit{background:rgba(255,101,120,.12);color:#ff9cab}
            .hn-wallet-history-meta{color:#77849a;font-size:.69rem;font-weight:750}
            .hn-wallet-history-value{display:grid;gap:3px;text-align:right;white-space:nowrap}
            .hn-wallet-history-amount{font-size:.9rem;font-weight:950}
            .hn-wallet-history-amount.is-credit{color:#79efb5}
            .hn-wallet-history-amount.is-debit{color:#ff9cab}
            .hn-wallet-history-after{color:#77849a;font-size:.65rem;font-weight:800}
            .hn-wallet-empty{display:grid;place-items:center;gap:6px;min-height:120px;border:1px dashed rgba(168,179,199,.18);border-radius:13px;padding:18px;text-align:center;color:#a8b3c7}
            .hn-wallet-empty strong{color:#f8fafc}
            .hn-locked-card h2,.hn-wallet-card h2{margin-top:0}
            .hn-locked-card p,.hn-wallet-card p{margin:.35rem 0}
            @media(max-width:420px){.hn-wallet-overview{padding:15px}.hn-wallet-coin-icon{width:46px;height:46px}.hn-wallet-history-card{padding:12px}.hn-wallet-history-row{padding:10px}.hn-wallet-history-title{display:grid;gap:4px}.hn-wallet-history-badge{width:max-content}}
        ');
    }

    public static function admin_menu(): void
    {
        add_submenu_page(
            'edit.php?post_type=hn_book',
            __('Wallets', 'hausanovels-wallet'),
            __('Wallets', 'hausanovels-wallet'),
            'manage_options',
            'hausanovels-wallets',
            array(__CLASS__, 'render_admin_page')
        );
    }

    public static function render_admin_page(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $message = '';

        if (isset($_POST['hn_wallet_admin_action'])) {
            check_admin_referer('hn_wallet_admin_adjust', 'hn_wallet_admin_nonce');

            $user = self::resolve_user(sanitize_text_field(wp_unslash($_POST['hn_wallet_user'] ?? '')));
            $amount = absint($_POST['hn_wallet_amount'] ?? 0);
            $note = sanitize_text_field(wp_unslash($_POST['hn_wallet_note'] ?? 'Admin adjustment'));
            $action = sanitize_key($_POST['hn_wallet_admin_action']);

            if (! $user) {
                $message = __('User not found.', 'hausanovels-wallet');
            } elseif ($amount <= 0) {
                $message = __('Amount must be greater than zero.', 'hausanovels-wallet');
            } elseif ('credit' === $action) {
                $result = self::credit($user->ID, $amount, $note, 'admin:' . wp_generate_uuid4(), 'admin_adjustment', get_current_user_id());
                $message = is_wp_error($result) ? $result->get_error_message() : __('Coins credited successfully.', 'hausanovels-wallet');
            } elseif ('debit' === $action) {
                $result = self::debit($user->ID, $amount, $note, 'admin_adjustment', get_current_user_id());
                $message = is_wp_error($result) ? $result->get_error_message() : __('Coins debited successfully.', 'hausanovels-wallet');
            }
        }

        $recent = self::get_recent_ledger(20);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Hausanovels Wallets', 'hausanovels-wallet'); ?></h1>
            <?php if ($message) : ?>
                <div class="notice notice-info"><p><?php echo esc_html($message); ?></p></div>
            <?php endif; ?>
            <form method="post" style="max-width:720px;background:#fff;border:1px solid #dcdcde;padding:16px;margin:16px 0;">
                <?php wp_nonce_field('hn_wallet_admin_adjust', 'hn_wallet_admin_nonce'); ?>
                <p>
                    <label for="hn-wallet-user"><strong><?php esc_html_e('User ID or Email', 'hausanovels-wallet'); ?></strong></label>
                    <input type="text" id="hn-wallet-user" name="hn_wallet_user" class="regular-text" required>
                </p>
                <p>
                    <label for="hn-wallet-amount"><strong><?php esc_html_e('Coins', 'hausanovels-wallet'); ?></strong></label>
                    <input type="number" min="1" id="hn-wallet-amount" name="hn_wallet_amount" class="small-text" required>
                </p>
                <p>
                    <label for="hn-wallet-note"><strong><?php esc_html_e('Note', 'hausanovels-wallet'); ?></strong></label>
                    <input type="text" id="hn-wallet-note" name="hn_wallet_note" class="regular-text" value="Admin adjustment">
                </p>
                <p>
                    <button class="button button-primary" name="hn_wallet_admin_action" value="credit"><?php esc_html_e('Credit Coins', 'hausanovels-wallet'); ?></button>
                    <button class="button" name="hn_wallet_admin_action" value="debit"><?php esc_html_e('Debit Coins', 'hausanovels-wallet'); ?></button>
                </p>
            </form>
            <h2><?php esc_html_e('Recent Wallet Transactions', 'hausanovels-wallet'); ?></h2>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Date', 'hausanovels-wallet'); ?></th>
                        <th><?php esc_html_e('User', 'hausanovels-wallet'); ?></th>
                        <th><?php esc_html_e('Type', 'hausanovels-wallet'); ?></th>
                        <th><?php esc_html_e('Coins', 'hausanovels-wallet'); ?></th>
                        <th><?php esc_html_e('Balance', 'hausanovels-wallet'); ?></th>
                        <th><?php esc_html_e('Description', 'hausanovels-wallet'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent as $row) : ?>
                        <tr>
                            <td><?php echo esc_html($row->created_at); ?></td>
                            <td><?php echo esc_html((string) $row->user_id); ?></td>
                            <td><?php echo esc_html($row->type); ?></td>
                            <td><?php echo esc_html((string) $row->amount); ?></td>
                            <td><?php echo esc_html((string) $row->balance_after); ?></td>
                            <td><?php echo esc_html($row->description); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function resolve_user(string $value): ?WP_User
    {
        if (is_email($value)) {
            $user = get_user_by('email', $value);
            return $user instanceof WP_User ? $user : null;
        }

        $user = get_user_by('id', absint($value));
        return $user instanceof WP_User ? $user : null;
    }

    public static function ensure_wallet(int $user_id): ?object
    {
        global $wpdb;

        if ($user_id <= 0) {
            return null;
        }

        if (isset(self::$wallet_cache[$user_id])) {
            return self::$wallet_cache[$user_id];
        }

        $tables = self::tables();
        $wallet = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tables['wallets']} WHERE user_id = %d", $user_id));

        if (! $wallet) {
            $now = current_time('mysql');
            $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO {$tables['wallets']} (user_id, balance, total_credited, total_debited, created_at, updated_at)
                 VALUES (%d, 0, 0, 0, %s, %s)",
                $user_id,
                $now,
                $now
            ));
            $wallet = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tables['wallets']} WHERE user_id = %d", $user_id));
        }

        if ($wallet) {
            self::$wallet_cache[$user_id] = $wallet;
        }

        return $wallet ?: null;
    }

    public static function get_balance(int $user_id): int
    {
        $wallet = self::ensure_wallet($user_id);
        return $wallet ? (int) $wallet->balance : 0;
    }

    public static function credit(int $user_id, int $amount, string $description = '', ?string $external_reference = null, string $reference_type = 'manual', int $reference_id = 0)
    {
        global $wpdb;

        if ($user_id <= 0 || $amount <= 0) {
            return new WP_Error('hn_wallet_invalid_credit', __('Invalid wallet credit request.', 'hausanovels-wallet'));
        }

        $tables = self::tables();

        if (! self::ensure_wallet($user_id)) {
            return new WP_Error('hn_wallet_missing', __('Wallet could not be created.', 'hausanovels-wallet'));
        }

        $wpdb->query('START TRANSACTION');

        if ($external_reference) {
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$tables['ledger']} WHERE external_reference = %s LIMIT 1 FOR UPDATE",
                $external_reference
            ));

            if ($existing) {
                $wpdb->query('COMMIT');
                return true;
            }
        }

        $wallet = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['wallets']} WHERE user_id = %d FOR UPDATE",
            $user_id
        ));

        if (! $wallet) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('hn_wallet_missing', __('Wallet could not be loaded.', 'hausanovels-wallet'));
        }

        $before = (int) $wallet->balance;
        $after = $before + $amount;
        $now = current_time('mysql');

        $updated = $wpdb->update($tables['wallets'], array(
            'balance'        => $after,
            'total_credited' => (int) $wallet->total_credited + $amount,
            'updated_at'     => $now,
        ), array('user_id' => $user_id), array('%d', '%d', '%s'), array('%d'));

        if (false === $updated) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('hn_wallet_credit_failed', __('Could not credit wallet.', 'hausanovels-wallet'));
        }

        if (! self::insert_ledger($user_id, 'credit', $amount, $before, $after, $reference_type, $reference_id, $external_reference, $description)) {
            $wpdb->query('ROLLBACK');

            if ($external_reference) {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$tables['ledger']} WHERE external_reference = %s LIMIT 1",
                    $external_reference
                ));

                if ($existing) {
                    unset(self::$wallet_cache[$user_id]);
                    return true;
                }
            }

            return new WP_Error('hn_wallet_credit_failed', __('Could not credit wallet.', 'hausanovels-wallet'));
        }

        $wpdb->query('COMMIT');
        unset(self::$wallet_cache[$user_id]);

        do_action('hausanovels_wallet_credited', $user_id, $amount, $after, $reference_type, $reference_id);

        return true;
    }

    public static function debit(int $user_id, int $amount, string $description = '', string $reference_type = 'manual', int $reference_id = 0)
    {
        global $wpdb;

        if ($user_id <= 0 || $amount <= 0) {
            return new WP_Error('hn_wallet_invalid_debit', __('Invalid wallet debit request.', 'hausanovels-wallet'));
        }

        $tables = self::tables();

        if (! self::ensure_wallet($user_id)) {
            return new WP_Error('hn_wallet_missing', __('Wallet could not be found.', 'hausanovels-wallet'));
        }

        $wpdb->query('START TRANSACTION');

        $wallet = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['wallets']} WHERE user_id = %d FOR UPDATE",
            $user_id
        ));

        if (! $wallet) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('hn_wallet_missing', __('Wallet could not be loaded.', 'hausanovels-wallet'));
        }

        $before = (int) $wallet->balance;

        if ($before < $amount) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('hn_wallet_insufficient_balance', __('Insufficient coin balance.', 'hausanovels-wallet'));
        }

        $after = $before - $amount;
        $now = current_time('mysql');

        $updated = $wpdb->update($tables['wallets'], array(
            'balance'       => $after,
            'total_debited' => (int) $wallet->total_debited + $amount,
            'updated_at'    => $now,
        ), array('user_id' => $user_id), array('%d', '%d', '%s'), array('%d'));

        if (false === $updated || ! self::insert_ledger($user_id, 'debit', $amount, $before, $after, $reference_type, $reference_id, null, $description)) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('hn_wallet_debit_failed', __('Could not debit wallet.', 'hausanovels-wallet'));
        }

        $wpdb->query('COMMIT');
        unset(self::$wallet_cache[$user_id]);

        do_action('hausanovels_wallet_debited', $user_id, $amount, $after, $reference_type, $reference_id);

        return true;
    }

    private static function insert_ledger(int $user_id, string $type, int $amount, int $before, int $after, string $reference_type, int $reference_id, ?string $external_reference, string $description): bool
    {
        global $wpdb;

        $tables = self::tables();
        $inserted = $wpdb->insert($tables['ledger'], array(
            'user_id'            => $user_id,
            'type'               => $type,
            'amount'             => $amount,
            'balance_before'     => $before,
            'balance_after'      => $after,
            'reference_type'     => $reference_type,
            'reference_id'       => $reference_id,
            'external_reference' => $external_reference,
            'description'        => $description,
            'created_at'         => current_time('mysql'),
        ), array('%d', '%s', '%d', '%d', '%d', '%s', '%d', '%s', '%s', '%s'));

        return false !== $inserted;
    }

    public static function get_recent_ledger(int $limit = 10, int $user_id = 0): array
    {
        global $wpdb;

        $tables = self::tables();
        $limit = max(1, min(100, $limit));

        if ($user_id > 0) {
            return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$tables['ledger']} WHERE user_id = %d ORDER BY id DESC LIMIT %d", $user_id, $limit));
        }

        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$tables['ledger']} ORDER BY id DESC LIMIT %d", $limit));
    }

    public static function has_unlocked(int $user_id, int $chapter_id): bool
    {
        global $wpdb;

        if ($user_id <= 0 || $chapter_id <= 0) {
            return false;
        }

        $cache_key = $user_id . ':' . $chapter_id;

        if (array_key_exists($cache_key, self::$unlock_cache)) {
            return self::$unlock_cache[$cache_key];
        }

        $tables = self::tables();
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$tables['unlocks']} WHERE user_id = %d AND chapter_id = %d LIMIT 1",
            $user_id,
            $chapter_id
        ));

        self::$unlock_cache[$cache_key] = (bool) $found;

        return self::$unlock_cache[$cache_key];
    }

    public static function get_unlocked_chapter_ids(int $user_id, array $chapter_ids): array
    {
        global $wpdb;

        $chapter_ids = array_values(array_unique(array_filter(array_map('absint', $chapter_ids))));

        if ($user_id <= 0 || ! $chapter_ids) {
            return array();
        }

        $resolved = array();
        $missing = array();

        foreach ($chapter_ids as $chapter_id) {
            $cache_key = $user_id . ':' . $chapter_id;

            if (array_key_exists($cache_key, self::$unlock_cache)) {
                if (self::$unlock_cache[$cache_key]) {
                    $resolved[] = $chapter_id;
                }
                continue;
            }

            $missing[] = $chapter_id;
        }

        if ($missing) {
            $tables = self::tables();
            $placeholders = implode(',', array_fill(0, count($missing), '%d'));
            $args = array_merge(array($user_id), $missing);
            $sql = "SELECT chapter_id FROM {$tables['unlocks']} WHERE user_id = %d AND chapter_id IN ({$placeholders})";
            $found_ids = array_map('intval', (array) $wpdb->get_col($wpdb->prepare($sql, ...$args)));
            $found_map = array_fill_keys($found_ids, true);

            foreach ($missing as $chapter_id) {
                $cache_key = $user_id . ':' . $chapter_id;
                self::$unlock_cache[$cache_key] = isset($found_map[$chapter_id]);

                if (isset($found_map[$chapter_id])) {
                    $resolved[] = $chapter_id;
                }
            }
        }

        return array_values(array_unique($resolved));
    }

    public static function unlock_chapter(int $user_id, int $chapter_id)
    {
        global $wpdb;

        if ($user_id <= 0 || $chapter_id <= 0) {
            return new WP_Error('hn_unlock_invalid', __('Invalid unlock request.', 'hausanovels-wallet'));
        }

        if (self::is_publisher_only($user_id)) {
            return new WP_Error('hn_unlock_publisher_account', __('Publisher accounts cannot unlock reader chapters.', 'hausanovels-wallet'));
        }

        $tables = self::tables();
        $price = self::get_chapter_price($chapter_id);
        $book_id = self::get_chapter_book_id($chapter_id);
        $now = current_time('mysql');

        if ($price > 0 && ! self::ensure_wallet($user_id)) {
            return new WP_Error('hn_wallet_missing', __('Wallet could not be found.', 'hausanovels-wallet'));
        }

        $wpdb->query('START TRANSACTION');

        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$tables['unlocks']} WHERE user_id = %d AND chapter_id = %d LIMIT 1 FOR UPDATE",
            $user_id,
            $chapter_id
        ));

        if ($existing) {
            $wpdb->query('COMMIT');
            self::$unlock_cache[$user_id . ':' . $chapter_id] = true;
            return true;
        }

        if ($price <= 0) {
            $inserted = $wpdb->insert($tables['unlocks'], array(
                'user_id'     => $user_id,
                'book_id'     => $book_id,
                'chapter_id'  => $chapter_id,
                'coins_spent' => 0,
                'unlocked_at' => $now,
            ), array('%d', '%d', '%d', '%d', '%s'));

            if (false === $inserted) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('hn_unlock_record_failed', __('Could not record chapter unlock.', 'hausanovels-wallet'));
            }

            $wpdb->query('COMMIT');
            self::$unlock_cache[$user_id . ':' . $chapter_id] = true;
            return true;
        }

        $wallet = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['wallets']} WHERE user_id = %d FOR UPDATE",
            $user_id
        ));

        if (! $wallet || (int) $wallet->balance < $price) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('hn_unlock_insufficient_balance', __('Insufficient coins. Please fund your wallet.', 'hausanovels-wallet'));
        }

        $before = (int) $wallet->balance;
        $after = $before - $price;
        $external_reference = 'unlock:' . $user_id . ':' . $chapter_id;

        $updated = $wpdb->update($tables['wallets'], array(
            'balance'       => $after,
            'total_debited' => (int) $wallet->total_debited + $price,
            'updated_at'    => $now,
        ), array('user_id' => $user_id), array('%d', '%d', '%s'), array('%d'));

        $ledger_inserted = false !== $updated && self::insert_ledger(
            $user_id,
            'debit',
            $price,
            $before,
            $after,
            'chapter_unlock',
            $chapter_id,
            $external_reference,
            sprintf(__('Unlocked chapter #%d', 'hausanovels-wallet'), $chapter_id)
        );

        $unlock_inserted = $ledger_inserted ? $wpdb->insert($tables['unlocks'], array(
            'user_id'     => $user_id,
            'book_id'     => $book_id,
            'chapter_id'  => $chapter_id,
            'coins_spent' => $price,
            'unlocked_at' => $now,
        ), array('%d', '%d', '%d', '%d', '%s')) : false;

        if (false === $updated || ! $ledger_inserted || false === $unlock_inserted) {
            $wpdb->query('ROLLBACK');

            $existing_unlock = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$tables['unlocks']} WHERE user_id = %d AND chapter_id = %d LIMIT 1",
                $user_id,
                $chapter_id
            ));

            if ($existing_unlock) {
                unset(self::$wallet_cache[$user_id]);
                self::$unlock_cache[$user_id . ':' . $chapter_id] = true;
                return true;
            }

            return new WP_Error('hn_unlock_record_failed', __('Could not complete chapter unlock.', 'hausanovels-wallet'));
        }

        $wpdb->query('COMMIT');
        unset(self::$wallet_cache[$user_id]);
        self::$unlock_cache[$user_id . ':' . $chapter_id] = true;

        do_action('hausanovels_chapter_unlocked', $user_id, $chapter_id, $book_id, $price);

        return true;
    }

    private static function record_unlock(int $user_id, int $book_id, int $chapter_id, int $coins_spent)
    {
        global $wpdb;

        $tables = self::tables();
        $result = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$tables['unlocks']} (user_id, book_id, chapter_id, coins_spent, unlocked_at)
             VALUES (%d, %d, %d, %d, %s)",
            $user_id,
            $book_id,
            $chapter_id,
            $coins_spent,
            current_time('mysql')
        ));

        if (false === $result) {
            return new WP_Error('hn_unlock_record_failed', __('Could not record chapter unlock.', 'hausanovels-wallet'));
        }

        self::$unlock_cache[$user_id . ':' . $chapter_id] = true;

        return true;
    }

    public static function filter_user_can_read_chapter(bool $can_read, int $user_id, int $chapter_id): bool
    {
        if (self::is_publisher_only($user_id)) {
            return false;
        }

        if ($user_id <= 0) {
            return false;
        }

        if ($can_read) {
            return true;
        }

        return self::has_unlocked($user_id, $chapter_id);
    }

    public static function protect_chapter_content(string $content): string
    {
        if (! is_singular('hn_chapter') || ! in_the_loop() || ! is_main_query()) {
            return $content;
        }

        $chapter_id = get_the_ID();

        if (self::is_publisher_only(get_current_user_id())) {
            return self::render_publisher_blocked_card($chapter_id);
        }

        if (! is_user_logged_in()) {
            return self::render_locked_card($chapter_id);
        }

        if (! self::is_chapter_premium($chapter_id)) {
            return $content;
        }

        if (self::user_can_read_chapter(get_current_user_id(), $chapter_id)) {
            return $content;
        }

        return self::render_locked_card($chapter_id);
    }

    public static function user_can_read_chapter(int $user_id, int $chapter_id): bool
    {
        if (self::is_publisher_only($user_id)) {
            return false;
        }

        if ($user_id <= 0) {
            return false;
        }

        if (! self::is_chapter_premium($chapter_id)) {
            return true;
        }

        return self::has_unlocked($user_id, $chapter_id);
    }

    public static function is_chapter_premium(int $chapter_id): bool
    {
        if (class_exists('Hausanovels_Core_Plugin')) {
            return Hausanovels_Core_Plugin::is_chapter_premium($chapter_id);
        }

        return (bool) get_post_meta($chapter_id, '_hn_is_premium', true)
            || (int) get_post_meta($chapter_id, '_hn_coin_price', true) > 0;
    }

    public static function get_chapter_price(int $chapter_id): int
    {
        if (class_exists('Hausanovels_Core_Plugin')) {
            return Hausanovels_Core_Plugin::get_chapter_coin_price($chapter_id);
        }

        return (int) get_post_meta($chapter_id, '_hn_coin_price', true);
    }

    public static function get_chapter_book_id(int $chapter_id): int
    {
        if (function_exists('hn_get_chapter_book_id')) {
            return hn_get_chapter_book_id($chapter_id);
        }

        $parent_id = (int) get_post_field('post_parent', $chapter_id);
        if ($parent_id > 0 && 'hn_book' === get_post_type($parent_id)) {
            return $parent_id;
        }

        return (int) get_post_meta($chapter_id, '_hn_book_id', true);
    }

    private static function is_publisher_only(int $user_id = 0): bool
    {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();

        if ($user_id <= 0 || user_can($user_id, 'manage_options')) {
            return false;
        }

        if (function_exists('hausanovels_is_publisher_only')) {
            return hausanovels_is_publisher_only($user_id);
        }

        $user = get_userdata($user_id);

        if (! $user instanceof WP_User) {
            return false;
        }

        return in_array('hn_publisher', (array) $user->roles, true);
    }

    public static function render_locked_card(int $chapter_id): string
    {
        if (self::is_publisher_only(get_current_user_id())) {
            return self::render_publisher_blocked_card($chapter_id);
        }

        $price = self::get_chapter_price($chapter_id);
        $balance = is_user_logged_in() ? self::get_balance(get_current_user_id()) : 0;
        $login_url = function_exists('hausanovels_signin_url') ? hausanovels_signin_url(get_permalink($chapter_id)) : wp_login_url(get_permalink($chapter_id));
        $register_url = function_exists('hausanovels_register_url') ? hausanovels_register_url(get_permalink($chapter_id), 'reader') : wp_registration_url();

        ob_start();
        ?>
        <div class="hn-locked-card">
            <h2><?php echo esc_html(self::is_chapter_premium($chapter_id) ? __('Premium Chapter', 'hausanovels-wallet') : __('Reader Account Required', 'hausanovels-wallet')); ?></h2>
            <p><?php echo esc_html(self::is_chapter_premium($chapter_id) ? sprintf(__('This chapter requires %d coins to unlock.', 'hausanovels-wallet'), $price) : __('Please register or sign in as a reader before opening chapters.', 'hausanovels-wallet')); ?></p>
            <?php if (is_user_logged_in()) : ?>
                <p><?php echo esc_html(sprintf(__('Your balance: %d coins', 'hausanovels-wallet'), $balance)); ?></p>
                <?php echo self::unlock_form($chapter_id); ?>
            <?php else : ?>
                <p><?php esc_html_e('Please sign in or create a reader account to continue.', 'hausanovels-wallet'); ?></p>
                <div class="hn-wallet-actions">
                    <a class="hn-wallet-button" href="<?php echo esc_url($login_url); ?>"><?php esc_html_e('Sign In to Read', 'hausanovels-wallet'); ?></a>
                    <a class="hn-wallet-button is-muted" href="<?php echo esc_url($register_url); ?>"><?php esc_html_e('Create Reader Account', 'hausanovels-wallet'); ?></a>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    private static function render_publisher_blocked_card(int $chapter_id): string
    {
        $register_url = function_exists('hausanovels_register_url') ? hausanovels_register_url(get_permalink($chapter_id), 'reader') : wp_registration_url();

        return '<div class="hn-locked-card"><h2>' . esc_html__('Reader Account Required', 'hausanovels-wallet') . '</h2><p>' . esc_html__('This account is registered as a publisher. Please use a separate reader account to unlock and read chapters.', 'hausanovels-wallet') . '</p><div class="hn-wallet-actions"><a class="hn-wallet-button" href="' . esc_url(wp_logout_url($register_url)) . '">' . esc_html__('Sign Out and Register as Reader', 'hausanovels-wallet') . '</a><a class="hn-wallet-button is-muted" href="' . esc_url(home_url('/publisher/')) . '">' . esc_html__('Back to Publisher Dashboard', 'hausanovels-wallet') . '</a></div></div>';
    }

    public static function unlock_form(int $chapter_id): string
    {
        if (! is_user_logged_in()) {
            $login_url = function_exists('hausanovels_signin_url') ? hausanovels_signin_url(get_permalink($chapter_id)) : wp_login_url(get_permalink($chapter_id));
            $register_url = function_exists('hausanovels_register_url') ? hausanovels_register_url(get_permalink($chapter_id), 'reader') : wp_registration_url();

            return '<div class="hn-wallet-actions"><a class="hn-wallet-button" href="' . esc_url($login_url) . '">' . esc_html__('Sign In to Unlock', 'hausanovels-wallet') . '</a><a class="hn-wallet-button is-muted" href="' . esc_url($register_url) . '">' . esc_html__('Create Reader Account', 'hausanovels-wallet') . '</a></div>';
        }

        if (self::has_unlocked(get_current_user_id(), $chapter_id)) {
            return '<span class="hn-wallet-button is-muted">' . esc_html__('Already Unlocked', 'hausanovels-wallet') . '</span>';
        }

        ob_start();
        ?>
        <form method="post" class="hn-wallet-actions">
            <?php wp_nonce_field('hn_unlock_chapter_' . $chapter_id, 'hn_unlock_nonce'); ?>
            <input type="hidden" name="hn_wallet_action" value="unlock_chapter">
            <input type="hidden" name="hn_chapter_id" value="<?php echo esc_attr((string) $chapter_id); ?>">
            <button type="submit" class="hn-wallet-button"><?php esc_html_e('Unlock with Coins', 'hausanovels-wallet'); ?></button>
        </form>
        <?php
        return (string) ob_get_clean();
    }

    public static function handle_unlock_request(): void
    {
        if (! isset($_POST['hn_wallet_action']) || 'unlock_chapter' !== sanitize_key($_POST['hn_wallet_action'])) {
            return;
        }

        $chapter_id = absint($_POST['hn_chapter_id'] ?? 0);
        $redirect = $chapter_id ? get_permalink($chapter_id) : home_url('/');

        if (! is_user_logged_in()) {
            $login_url = function_exists('hausanovels_signin_url') ? hausanovels_signin_url($redirect) : wp_login_url($redirect);
            wp_safe_redirect($login_url);
            exit;
        }

        if (self::is_publisher_only(get_current_user_id())) {
            wp_safe_redirect(add_query_arg('hn_unlock', 'publisher_account', $redirect));
            exit;
        }

        if (! isset($_POST['hn_unlock_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hn_unlock_nonce'])), 'hn_unlock_chapter_' . $chapter_id)) {
            wp_safe_redirect(add_query_arg('hn_unlock', 'invalid', $redirect));
            exit;
        }

        $result = self::unlock_chapter(get_current_user_id(), $chapter_id);

        wp_safe_redirect(add_query_arg('hn_unlock', is_wp_error($result) ? $result->get_error_code() : 'success', $redirect));
        exit;
    }

    private static function wallet_access_message(): string
    {
        if (! is_user_logged_in()) {
            $login_url = function_exists('hausanovels_signin_url') ? hausanovels_signin_url(home_url('/wallet/')) : wp_login_url(home_url('/wallet/'));
            $register_url = function_exists('hausanovels_register_url') ? hausanovels_register_url(home_url('/wallet/'), 'reader') : wp_registration_url();

            return '<div class="hn-wallet-card"><h2>' . esc_html__('Your coin wallet', 'hausanovels-wallet') . '</h2><p>' . esc_html__('Sign in or create a reader account to view your balance, buy coins, and check transactions.', 'hausanovels-wallet') . '</p><div class="hn-wallet-actions"><a class="hn-wallet-button" href="' . esc_url($login_url) . '">' . esc_html__('Sign In', 'hausanovels-wallet') . '</a><a class="hn-wallet-button is-muted" href="' . esc_url($register_url) . '">' . esc_html__('Create Reader Account', 'hausanovels-wallet') . '</a></div></div>';
        }

        if (self::is_publisher_only(get_current_user_id())) {
            return '<div class="hn-wallet-card"><h2>' . esc_html__('Reader wallet unavailable', 'hausanovels-wallet') . '</h2><p>' . esc_html__('Publisher accounts do not use the reader coin wallet. Use a separate reader account to buy coins and unlock chapters.', 'hausanovels-wallet') . '</p><div class="hn-wallet-actions"><a class="hn-wallet-button" href="' . esc_url(home_url('/publisher/')) . '">' . esc_html__('Publisher Dashboard', 'hausanovels-wallet') . '</a></div></div>';
        }

        return '';
    }

    public static function shortcode_wallet_balance(): string
    {
        $access_message = self::wallet_access_message();
        if ('' !== $access_message) {
            return $access_message;
        }

        $balance = self::get_balance(get_current_user_id());

        ob_start();
        ?>
        <section id="wallet-balance" class="hn-wallet-overview" aria-labelledby="hn-wallet-balance-title">
            <div class="hn-wallet-overview-head">
                <div>
                    <span class="hn-wallet-eyebrow"><?php esc_html_e('Available balance', 'hausanovels-wallet'); ?></span>
                    <h2 id="hn-wallet-balance-title"><?php esc_html_e('My Coin Wallet', 'hausanovels-wallet'); ?></h2>
                </div>
                <span class="hn-wallet-status"><?php esc_html_e('Active', 'hausanovels-wallet'); ?></span>
            </div>
            <div class="hn-wallet-balance-wrap">
                <span class="hn-wallet-coin-icon" aria-hidden="true">C</span>
                <span class="hn-wallet-balance-copy">
                    <strong class="hn-wallet-balance"><?php echo esc_html(number_format_i18n($balance)); ?></strong>
                    <span class="hn-wallet-balance-label"><?php esc_html_e('coins', 'hausanovels-wallet'); ?></span>
                </span>
            </div>
            <p class="hn-wallet-overview-note"><?php esc_html_e('Use your coins to unlock premium chapters. Your balance updates automatically after a confirmed purchase or chapter unlock.', 'hausanovels-wallet'); ?></p>
            <div class="hn-wallet-actions">
                <a class="hn-wallet-button" href="#buy-coins"><?php esc_html_e('Buy Coins', 'hausanovels-wallet'); ?></a>
                <a class="hn-wallet-button is-muted" href="#wallet-history"><?php esc_html_e('View History', 'hausanovels-wallet'); ?></a>
            </div>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    public static function shortcode_wallet_history(): string
    {
        if (! is_user_logged_in() || self::is_publisher_only(get_current_user_id())) {
            return '';
        }

        $ledger = self::get_recent_ledger(20, get_current_user_id());

        ob_start();
        ?>
        <section id="wallet-history" class="hn-wallet-history-card" aria-labelledby="hn-wallet-history-title">
            <div class="hn-wallet-history-head">
                <h2 id="hn-wallet-history-title"><?php esc_html_e('Transaction History', 'hausanovels-wallet'); ?></h2>
                <span class="hn-wallet-history-count"><?php echo esc_html(sprintf(_n('%d item', '%d items', count($ledger), 'hausanovels-wallet'), count($ledger))); ?></span>
            </div>

            <?php if ($ledger) : ?>
                <div class="hn-wallet-history-list">
                    <?php foreach ($ledger as $row) : ?>
                        <?php
                        $type = 'debit' === sanitize_key((string) $row->type) ? 'debit' : 'credit';
                        $description = sanitize_text_field((string) $row->description);
                        if ('' === $description) {
                            $description = 'credit' === $type ? __('Coin credit', 'hausanovels-wallet') : __('Chapter unlock', 'hausanovels-wallet');
                        }
                        $sign = 'credit' === $type ? '+' : '−';
                        ?>
                        <article class="hn-wallet-history-row">
                            <div class="hn-wallet-history-main">
                                <div class="hn-wallet-history-title">
                                    <strong><?php echo esc_html($description); ?></strong>
                                    <span class="hn-wallet-history-badge is-<?php echo esc_attr($type); ?>"><?php echo esc_html(ucfirst($type)); ?></span>
                                </div>
                                <span class="hn-wallet-history-meta"><?php echo esc_html(mysql2date('M j, Y · g:i a', (string) $row->created_at)); ?></span>
                            </div>
                            <div class="hn-wallet-history-value">
                                <span class="hn-wallet-history-amount is-<?php echo esc_attr($type); ?>"><?php echo esc_html($sign . number_format_i18n((int) $row->amount)); ?></span>
                                <span class="hn-wallet-history-after"><?php echo esc_html(sprintf(__('Balance: %s', 'hausanovels-wallet'), number_format_i18n((int) $row->balance_after))); ?></span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <div class="hn-wallet-empty">
                    <strong><?php esc_html_e('No transactions yet', 'hausanovels-wallet'); ?></strong>
                    <span><?php esc_html_e('Coin purchases and chapter unlocks will appear here.', 'hausanovels-wallet'); ?></span>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    public static function shortcode_wallet(): string
    {
        $balance = self::shortcode_wallet_balance();
        if (! is_user_logged_in() || self::is_publisher_only(get_current_user_id())) {
            return $balance;
        }

        return $balance . self::shortcode_wallet_history();
    }

    public static function shortcode_unlock_button(array $atts): string
    {
        $atts = shortcode_atts(array(
            'chapter_id' => get_the_ID(),
        ), $atts, 'hn_unlock_button');

        return self::unlock_form(absint($atts['chapter_id']));
    }

    private static function should_load_styles(): bool
    {
        if (get_query_var('hn_wallet_page') || 'wallet' === sanitize_key((string) get_query_var('hn_app_page')) || is_singular('hn_chapter')) {
            return true;
        }

        global $post;

        if (! $post instanceof WP_Post) {
            return false;
        }

        $content = (string) $post->post_content;

        return has_shortcode($content, 'hn_wallet')
            || has_shortcode($content, 'hn_wallet_balance')
            || has_shortcode($content, 'hn_wallet_history')
            || has_shortcode($content, 'hn_unlock_button');
    }

}

Hausanovels_Wallet_Plugin::init();

register_activation_hook(__FILE__, array('Hausanovels_Wallet_Plugin', 'activate'));

if (! function_exists('hn_wallet_get_balance')) {
    function hn_wallet_get_balance(int $user_id): int
    {
        return Hausanovels_Wallet_Plugin::get_balance($user_id);
    }
}

if (! function_exists('hn_wallet_credit')) {
    function hn_wallet_credit(int $user_id, int $amount, string $description = '', ?string $external_reference = null, string $reference_type = 'manual', int $reference_id = 0)
    {
        return Hausanovels_Wallet_Plugin::credit($user_id, $amount, $description, $external_reference, $reference_type, $reference_id);
    }
}

if (! function_exists('hn_wallet_debit')) {
    function hn_wallet_debit(int $user_id, int $amount, string $description = '', string $reference_type = 'manual', int $reference_id = 0)
    {
        return Hausanovels_Wallet_Plugin::debit($user_id, $amount, $description, $reference_type, $reference_id);
    }
}

if (! function_exists('hn_wallet_has_unlocked')) {
    function hn_wallet_has_unlocked(int $user_id, int $chapter_id): bool
    {
        return Hausanovels_Wallet_Plugin::has_unlocked($user_id, $chapter_id);
    }
}

if (! function_exists('hn_wallet_unlock_chapter')) {
    function hn_wallet_unlock_chapter(int $user_id, int $chapter_id)
    {
        return Hausanovels_Wallet_Plugin::unlock_chapter($user_id, $chapter_id);
    }
}

if (! function_exists('hn_wallet_get_unlocked_chapter_ids')) {
    function hn_wallet_get_unlocked_chapter_ids(int $user_id, array $chapter_ids): array
    {
        return Hausanovels_Wallet_Plugin::get_unlocked_chapter_ids($user_id, $chapter_ids);
    }
}
