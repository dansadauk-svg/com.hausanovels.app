# Hausanovels Paystack Funding

Paystack wallet funding plugin for Hausanovels.ng.

## What It Adds

- Reader coin bundle checkout through Paystack
- Test mode and live mode settings
- Separate test and live secret keys
- Paystack callback verification
- Paystack REST webhook verification with query-string fallback
- Automatic wallet credit after successful payment
- Admin manual reference verification
- Admin readiness check for active mode keys, wallet credit helper, bundles, callback URL, and webhook URL
- Compatibility aliases for older wallet/theme shortcode hooks

## Shortcodes

```text
[hn_paystack_topup]
```

The plugin also keeps these old shortcode aliases so older wallet/theme packages still show Paystack funding:

```text
[hn_bank_transfer_topup]
[hn_manual_bank_transfer]
```

## Setup

1. Install Hausanovels Core.
2. Install Hausanovels Wallet & Coins.
3. Install this plugin.
4. Go to **Hausa Books > Paystack Funding**.
5. Keep **Paystack Mode** on **Test mode** while testing.
6. Add your Paystack test public and secret keys.
7. Add or edit coin bundles.
8. Confirm the **Paystack Test Readiness** box shows the active test keys, wallet helper, bundles, callback, and webhook as ready.
9. Add the callback URL and REST webhook URL shown in the admin page to your Paystack dashboard.
10. Switch to **Live mode** and add live keys when you are ready for real payments.

If your host blocks WordPress REST API requests, use the fallback webhook URL shown beside the REST webhook URL.

## Default Coin Bundles

```text
500|500|Starter Pack
1000|1000|Reader Pack
2500|2600|Best Value
5000|5400|Heavy Reader
```

Each line follows:

```text
amount_naira|coins|label
```

## Performance update

This package includes request reduction, query optimization, and safer high-traffic behavior from the July 2026 performance audit. Review PERFORMANCE-AUDIT.md in the complete bundle for deployment guidance.

## Version 0.2.4

- Redesigned responsive coin purchase cards with clearer coin values, prices, bonus labels, and secure checkout presentation.

## Version 0.2.5

- Loads purchase-card styles on both the Wallet plugin route and the theme's `/wallet/` app route.
- Displays two professional coin-package cards per row on mobile and four per row on wider screens.
- Improves compact spacing, price hierarchy, bonus labels, and Best Value presentation.


## Version 0.2.6

- Adds the stable `#buy-coins` section anchor used by the redesigned wallet balance card.
- Keeps two professional coin cards per row on mobile and four on wider screens.
- Loads correctly on both the theme wallet route and the Wallet plugin route.
