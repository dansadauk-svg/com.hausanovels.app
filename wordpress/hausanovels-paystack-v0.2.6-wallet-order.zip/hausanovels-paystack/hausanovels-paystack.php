<?php
/**
 * Plugin Name: Hausanovels Paystack Funding
 * Plugin URI: https://hausanovels.ng/
 * Description: Paystack checkout funding, coin bundles, payment verification, and wallet crediting for Hausanovels.ng.
 * Version: 0.2.6
 * Author: Hausanovels
 * Text Domain: hausanovels-paystack
 * Requires at least: 6.0
 * Requires PHP: 8.0
 *
 * @package HausanovelsPaystack
 */

if (! defined('ABSPATH')) {
    exit;
}

define('HAUSANOVELS_PAYSTACK_VERSION', '0.2.6');
define('HAUSANOVELS_PAYSTACK_FILE', __FILE__);

final class Hausanovels_Paystack_Plugin
{
    private const OPTION_NAME = 'hausanovels_paystack_settings';
    private const DB_VERSION_OPTION = 'hausanovels_paystack_db_version';

    public static function init(): void
    {
        add_action('admin_init', array(__CLASS__, 'maybe_upgrade'));
        add_action('admin_notices', array(__CLASS__, 'dependency_notice'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'frontend_styles'));
        add_action('template_redirect', array(__CLASS__, 'handle_requests'), 1);
        add_action('rest_api_init', array(__CLASS__, 'register_rest_routes'));

        add_shortcode('hn_paystack_topup', array(__CLASS__, 'shortcode_topup'));
        add_shortcode('hn_paystack_dedicated_account', array(__CLASS__, 'shortcode_legacy_account'));

        // Compatibility for older wallet/theme builds that still look for bank-transfer shortcodes.
        add_shortcode('hn_bank_transfer_topup', array(__CLASS__, 'shortcode_topup'));
        add_shortcode('hn_manual_bank_transfer', array(__CLASS__, 'shortcode_topup'));
        add_shortcode('hn_bank_transfer_account', array(__CLASS__, 'shortcode_legacy_account'));
    }

    public static function activate(): void
    {
        self::create_tables();
        update_option(self::DB_VERSION_OPTION, HAUSANOVELS_PAYSTACK_VERSION);
    }

    public static function maybe_upgrade(): void
    {
        if (HAUSANOVELS_PAYSTACK_VERSION === (string) get_option(self::DB_VERSION_OPTION, '')) {
            return;
        }

        self::create_tables();
        update_option(self::DB_VERSION_OPTION, HAUSANOVELS_PAYSTACK_VERSION);
    }

    public static function dependency_notice(): void
    {
        if (function_exists('hn_wallet_credit')) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>Hausanovels Paystack Funding:</strong> ' . esc_html__('Please install and activate Hausanovels Wallet & Coins first. Successful payments cannot credit coins without it.', 'hausanovels-paystack') . '</p></div>';
    }

    public static function tables(): array
    {
        global $wpdb;

        return array(
            'transactions' => $wpdb->prefix . 'hn_paystack_transactions',
        );
    }

    public static function create_tables(): void
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $tables = self::tables();
        $charset_collate = $wpdb->get_charset_collate();

        $transactions = "CREATE TABLE {$tables['transactions']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            reference varchar(191) NOT NULL,
            bundle_label varchar(191) NOT NULL DEFAULT '',
            mode varchar(16) NOT NULL DEFAULT 'test',
            paystack_id varchar(64) DEFAULT NULL,
            amount_kobo bigint(20) unsigned NOT NULL DEFAULT 0,
            currency varchar(8) NOT NULL DEFAULT 'NGN',
            coins bigint(20) unsigned NOT NULL DEFAULT 0,
            status varchar(32) NOT NULL DEFAULT 'pending',
            channel varchar(32) DEFAULT NULL,
            raw_response longtext,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            credited_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY reference (reference),
            KEY user_id (user_id),
            KEY mode (mode),
            KEY status (status)
        ) {$charset_collate};";

        dbDelta($transactions);
        self::maybe_add_column($tables['transactions'], 'bundle_label', "varchar(191) NOT NULL DEFAULT ''", 'reference');
        self::maybe_add_column($tables['transactions'], 'mode', "varchar(16) NOT NULL DEFAULT 'test'", 'bundle_label');
        self::maybe_add_column($tables['transactions'], 'credited_at', 'datetime DEFAULT NULL', 'updated_at');
    }

    private static function maybe_add_column(string $table, string $column, string $definition, string $after = ''): void
    {
        global $wpdb;

        $exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM {$table} LIKE %s", $column));
        if ($exists) {
            return;
        }

        $after_sql = '' !== $after ? ' AFTER ' . $after : '';
        $wpdb->query("ALTER TABLE {$table} ADD {$column} {$definition}{$after_sql}");
    }

    public static function defaults(): array
    {
        return array(
            'mode'            => 'test',
            'test_public_key' => '',
            'test_secret_key' => '',
            'live_public_key' => '',
            'live_secret_key' => '',
            'public_key'      => '',
            'secret_key'      => '',
            'currency'        => 'NGN',
            'coins_per_naira' => 1,
            'wallet_url'      => home_url('/wallet/'),
            'instructions'    => __('Choose a coin bundle and pay securely with Paystack. Coins are credited automatically after Paystack confirms the payment.', 'hausanovels-paystack'),
            'bundles'         => "500|500|Starter Pack\n1000|1000|Reader Pack\n2500|2600|Best Value\n5000|5400|Heavy Reader",
        );
    }

    public static function settings(): array
    {
        $settings = wp_parse_args((array) get_option(self::OPTION_NAME, array()), self::defaults());
        $settings['mode'] = in_array((string) $settings['mode'], array('test', 'live'), true) ? (string) $settings['mode'] : 'test';
        $settings['currency'] = strtoupper(sanitize_key((string) $settings['currency'])) ?: 'NGN';
        $settings['coins_per_naira'] = max(1, absint($settings['coins_per_naira']));
        $settings['wallet_url'] = esc_url_raw((string) $settings['wallet_url']) ?: home_url('/wallet/');

        if ('' === trim((string) $settings['test_public_key']) && 0 === strpos((string) $settings['public_key'], 'pk_test_')) {
            $settings['test_public_key'] = (string) $settings['public_key'];
        }

        if ('' === trim((string) $settings['test_secret_key']) && 0 === strpos((string) $settings['secret_key'], 'sk_test_')) {
            $settings['test_secret_key'] = (string) $settings['secret_key'];
        }

        if ('' === trim((string) $settings['live_public_key']) && 0 === strpos((string) $settings['public_key'], 'pk_live_')) {
            $settings['live_public_key'] = (string) $settings['public_key'];
        }

        if ('' === trim((string) $settings['live_secret_key']) && 0 === strpos((string) $settings['secret_key'], 'sk_live_')) {
            $settings['live_secret_key'] = (string) $settings['secret_key'];
        }

        return $settings;
    }

    public static function active_mode(): string
    {
        $settings = self::settings();
        return (string) $settings['mode'];
    }

    public static function active_public_key(): string
    {
        $settings = self::settings();
        $key = 'live' === (string) $settings['mode'] ? $settings['live_public_key'] : $settings['test_public_key'];

        return trim((string) $key);
    }

    public static function active_secret_key(): string
    {
        $key = self::secret_key_for_mode(self::active_mode());

        return trim((string) $key);
    }

    private static function secret_key_for_mode(string $mode): string
    {
        $settings = self::settings();

        if ('live' === $mode) {
            return trim((string) $settings['live_secret_key']);
        }

        if ('test' === $mode) {
            return trim((string) $settings['test_secret_key']);
        }

        return trim((string) $settings['secret_key']);
    }

    private static function callback_url(): string
    {
        return home_url('/?hn_paystack_callback=1');
    }

    private static function webhook_url(): string
    {
        return rest_url('hausanovels/v1/paystack/webhook');
    }

    private static function legacy_webhook_url(): string
    {
        return home_url('/?hn_paystack_webhook=1');
    }

    public static function admin_menu(): void
    {
        $parent = post_type_exists('hn_book') ? 'edit.php?post_type=hn_book' : 'options-general.php';

        add_submenu_page(
            $parent,
            __('Paystack Funding', 'hausanovels-paystack'),
            __('Paystack Funding', 'hausanovels-paystack'),
            'manage_options',
            'hausanovels-paystack',
            array(__CLASS__, 'render_admin_page')
        );
    }

    public static function register_rest_routes(): void
    {
        register_rest_route('hausanovels/v1', '/paystack/webhook', array(
            'methods'             => 'POST',
            'callback'            => array(__CLASS__, 'handle_rest_webhook'),
            'permission_callback' => '__return_true',
        ));
    }

    public static function render_admin_page(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $message = '';

        if (isset($_POST['hn_paystack_save'])) {
            check_admin_referer('hn_paystack_save_settings', 'hn_paystack_nonce');
            $current = self::settings();
            $settings = array(
                'mode'            => in_array(($_POST['mode'] ?? 'test'), array('test', 'live'), true) ? sanitize_key(wp_unslash($_POST['mode'])) : 'test',
                'test_public_key' => sanitize_text_field(wp_unslash($_POST['test_public_key'] ?? '')),
                'test_secret_key' => self::posted_secret('test_secret_key', (string) $current['test_secret_key']),
                'live_public_key' => sanitize_text_field(wp_unslash($_POST['live_public_key'] ?? '')),
                'live_secret_key' => self::posted_secret('live_secret_key', (string) $current['live_secret_key']),
                'currency'        => strtoupper(sanitize_key(wp_unslash($_POST['currency'] ?? 'NGN'))) ?: 'NGN',
                'coins_per_naira' => max(1, absint($_POST['coins_per_naira'] ?? 1)),
                'wallet_url'      => esc_url_raw(wp_unslash($_POST['wallet_url'] ?? home_url('/wallet/'))),
                'instructions'    => sanitize_textarea_field(wp_unslash($_POST['instructions'] ?? '')),
                'bundles'         => sanitize_textarea_field(wp_unslash($_POST['bundles'] ?? '')),
            );

            update_option(self::OPTION_NAME, $settings);
            $message = __('Paystack settings saved.', 'hausanovels-paystack');
        }

        if (isset($_POST['hn_paystack_admin_action']) && 'verify_reference' === sanitize_key($_POST['hn_paystack_admin_action'])) {
            check_admin_referer('hn_paystack_verify_reference', 'hn_paystack_verify_nonce');
            $reference = sanitize_text_field(wp_unslash($_POST['reference'] ?? ''));
            $result = $reference ? self::verify_and_credit($reference, 'admin') : new WP_Error('hn_paystack_missing_reference', __('Enter a Paystack reference first.', 'hausanovels-paystack'));
            $message = is_wp_error($result) ? $result->get_error_message() : __('Payment verified and wallet checked.', 'hausanovels-paystack');
        }

        $settings = self::settings();
        $transactions = self::get_recent_transactions(30);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Hausanovels Paystack Funding', 'hausanovels-paystack'); ?></h1>
            <?php if ($message) : ?>
                <div class="notice notice-info"><p><?php echo esc_html($message); ?></p></div>
            <?php endif; ?>
            <p><?php esc_html_e('Use test mode while setting up. When you are ready for real money, switch mode to Live and add your live Paystack keys.', 'hausanovels-paystack'); ?></p>
            <?php self::render_setup_check($settings); ?>

            <form method="post" style="max-width:900px;">
                <?php wp_nonce_field('hn_paystack_save_settings', 'hn_paystack_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="mode"><?php esc_html_e('Paystack Mode', 'hausanovels-paystack'); ?></label></th>
                        <td>
                            <select id="mode" name="mode">
                                <option value="test" <?php selected($settings['mode'], 'test'); ?>><?php esc_html_e('Test mode', 'hausanovels-paystack'); ?></option>
                                <option value="live" <?php selected($settings['mode'], 'live'); ?>><?php esc_html_e('Live mode', 'hausanovels-paystack'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="test-public-key"><?php esc_html_e('Test Public Key', 'hausanovels-paystack'); ?></label></th>
                        <td><input type="text" id="test-public-key" name="test_public_key" value="<?php echo esc_attr((string) $settings['test_public_key']); ?>" class="regular-text" placeholder="pk_test_..."></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="test-secret-key"><?php esc_html_e('Test Secret Key', 'hausanovels-paystack'); ?></label></th>
                        <td><input type="password" id="test-secret-key" name="test_secret_key" value="" class="regular-text" autocomplete="off" placeholder="<?php echo esc_attr($settings['test_secret_key'] ? __('Saved - leave blank to keep', 'hausanovels-paystack') : 'sk_test_...'); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="live-public-key"><?php esc_html_e('Live Public Key', 'hausanovels-paystack'); ?></label></th>
                        <td><input type="text" id="live-public-key" name="live_public_key" value="<?php echo esc_attr((string) $settings['live_public_key']); ?>" class="regular-text" placeholder="pk_live_..."></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="live-secret-key"><?php esc_html_e('Live Secret Key', 'hausanovels-paystack'); ?></label></th>
                        <td><input type="password" id="live-secret-key" name="live_secret_key" value="" class="regular-text" autocomplete="off" placeholder="<?php echo esc_attr($settings['live_secret_key'] ? __('Saved - leave blank to keep', 'hausanovels-paystack') : 'sk_live_...'); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="currency"><?php esc_html_e('Currency', 'hausanovels-paystack'); ?></label></th>
                        <td><input type="text" id="currency" name="currency" value="<?php echo esc_attr((string) $settings['currency']); ?>" class="small-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="coins-per-naira"><?php esc_html_e('Coins Per Naira', 'hausanovels-paystack'); ?></label></th>
                        <td>
                            <input type="number" min="1" id="coins-per-naira" name="coins_per_naira" value="<?php echo esc_attr((string) $settings['coins_per_naira']); ?>" class="small-text">
                            <p class="description"><?php esc_html_e('Used only for unmapped webhook payments. Coin bundles below control normal checkout payments.', 'hausanovels-paystack'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="wallet-url"><?php esc_html_e('Wallet URL', 'hausanovels-paystack'); ?></label></th>
                        <td><input type="url" id="wallet-url" name="wallet_url" value="<?php echo esc_attr((string) $settings['wallet_url']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="instructions"><?php esc_html_e('Reader Instructions', 'hausanovels-paystack'); ?></label></th>
                        <td><textarea id="instructions" name="instructions" class="large-text" rows="3"><?php echo esc_textarea((string) $settings['instructions']); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="bundles"><?php esc_html_e('Coin Bundles', 'hausanovels-paystack'); ?></label></th>
                        <td>
                            <textarea id="bundles" name="bundles" class="large-text code" rows="7"><?php echo esc_textarea((string) $settings['bundles']); ?></textarea>
                            <p class="description"><?php esc_html_e('One bundle per line: amount_naira|coins|label', 'hausanovels-paystack'); ?></p>
                        </td>
                    </tr>
                </table>
                <p><button type="submit" name="hn_paystack_save" class="button button-primary"><?php esc_html_e('Save Settings', 'hausanovels-paystack'); ?></button></p>
            </form>

            <hr>
            <h2><?php esc_html_e('Paystack URLs', 'hausanovels-paystack'); ?></h2>
            <p><strong><?php esc_html_e('Callback URL:', 'hausanovels-paystack'); ?></strong> <code><?php echo esc_html(self::callback_url()); ?></code></p>
            <p><strong><?php esc_html_e('Webhook URL:', 'hausanovels-paystack'); ?></strong> <code><?php echo esc_html(self::webhook_url()); ?></code></p>
            <p><strong><?php esc_html_e('Fallback Webhook URL:', 'hausanovels-paystack'); ?></strong> <code><?php echo esc_html(self::legacy_webhook_url()); ?></code></p>
            <p class="description"><?php esc_html_e('Use the Webhook URL in Paystack. The fallback URL is kept for hosts that block WordPress REST API requests.', 'hausanovels-paystack'); ?></p>

            <h2><?php esc_html_e('Manual Verify', 'hausanovels-paystack'); ?></h2>
            <form method="post" style="display:flex;gap:8px;align-items:center;max-width:680px;">
                <?php wp_nonce_field('hn_paystack_verify_reference', 'hn_paystack_verify_nonce'); ?>
                <input type="text" name="reference" class="regular-text" placeholder="Paystack reference">
                <button type="submit" class="button" name="hn_paystack_admin_action" value="verify_reference"><?php esc_html_e('Verify & Credit', 'hausanovels-paystack'); ?></button>
            </form>

            <h2><?php esc_html_e('Recent Paystack Payments', 'hausanovels-paystack'); ?></h2>
            <?php self::render_transactions_table($transactions); ?>

            <h2><?php esc_html_e('Shortcodes', 'hausanovels-paystack'); ?></h2>
            <p><code>[hn_paystack_topup]</code></p>
        </div>
        <?php
    }

    private static function render_setup_check(array $settings): void
    {
        $mode = (string) $settings['mode'];
        $public_key = self::active_public_key();
        $secret_key = self::active_secret_key();
        $expected_public_prefix = 'live' === $mode ? 'pk_live_' : 'pk_test_';
        $expected_secret_prefix = 'live' === $mode ? 'sk_live_' : 'sk_test_';
        $bundles = self::get_bundles();
        $items = array(
            array(
                'label' => sprintf(__('Active mode is %s', 'hausanovels-paystack'), ucfirst($mode)),
                'ok'    => in_array($mode, array('test', 'live'), true),
            ),
            array(
                'label' => __('Active public key is saved for this mode', 'hausanovels-paystack'),
                'ok'    => '' !== $public_key && 0 === strpos($public_key, $expected_public_prefix),
            ),
            array(
                'label' => __('Active secret key is saved for this mode', 'hausanovels-paystack'),
                'ok'    => '' !== $secret_key && 0 === strpos($secret_key, $expected_secret_prefix),
            ),
            array(
                'label' => __('Wallet plugin can receive automatic coin credits', 'hausanovels-paystack'),
                'ok'    => function_exists('hn_wallet_credit'),
            ),
            array(
                'label' => __('At least one coin bundle is configured', 'hausanovels-paystack'),
                'ok'    => ! empty($bundles),
            ),
            array(
                'label' => __('Callback URL is ready for payment return', 'hausanovels-paystack'),
                'ok'    => '' !== self::callback_url(),
            ),
            array(
                'label' => __('REST webhook URL is ready for Paystack events', 'hausanovels-paystack'),
                'ok'    => '' !== self::webhook_url(),
            ),
        );
        ?>
        <div style="max-width:900px;background:#fff;border:1px solid #dcdcde;padding:14px 16px;margin:16px 0;">
            <h2 style="margin-top:0;"><?php esc_html_e('Paystack Test Readiness', 'hausanovels-paystack'); ?></h2>
            <ul style="margin:0;">
                <?php foreach ($items as $item) : ?>
                    <li style="margin:.35rem 0;">
                        <strong style="color:<?php echo $item['ok'] ? '#008a20' : '#b32d2e'; ?>;"><?php echo esc_html($item['ok'] ? __('Ready', 'hausanovels-paystack') : __('Needs attention', 'hausanovels-paystack')); ?></strong>
                        - <?php echo esc_html($item['label']); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p class="description"><?php esc_html_e('For testing, keep mode on Test and paste the Webhook URL below into your Paystack dashboard. Then buy a coin bundle with Paystack test cards.', 'hausanovels-paystack'); ?></p>
        </div>
        <?php
    }

    private static function posted_secret(string $field, string $current): string
    {
        $posted = isset($_POST[$field]) ? trim((string) sanitize_text_field(wp_unslash($_POST[$field]))) : '';

        return '' !== $posted ? $posted : $current;
    }

    private static function render_transactions_table(array $transactions): void
    {
        ?>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Date', 'hausanovels-paystack'); ?></th>
                    <th><?php esc_html_e('Reference', 'hausanovels-paystack'); ?></th>
                    <th><?php esc_html_e('User', 'hausanovels-paystack'); ?></th>
                    <th><?php esc_html_e('Mode', 'hausanovels-paystack'); ?></th>
                    <th><?php esc_html_e('Bundle', 'hausanovels-paystack'); ?></th>
                    <th><?php esc_html_e('Amount', 'hausanovels-paystack'); ?></th>
                    <th><?php esc_html_e('Coins', 'hausanovels-paystack'); ?></th>
                    <th><?php esc_html_e('Status', 'hausanovels-paystack'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($transactions) : ?>
                    <?php foreach ($transactions as $transaction) : ?>
                        <tr>
                            <td><?php echo esc_html($transaction->created_at); ?></td>
                            <td><code><?php echo esc_html((string) $transaction->reference); ?></code></td>
                            <td><?php echo esc_html(self::user_label((int) $transaction->user_id)); ?></td>
                            <td><?php echo esc_html(ucfirst((string) $transaction->mode)); ?></td>
                            <td><?php echo esc_html((string) $transaction->bundle_label); ?></td>
                            <td><?php echo esc_html((string) $transaction->currency . ' ' . number_format_i18n(((int) $transaction->amount_kobo) / 100)); ?></td>
                            <td><?php echo esc_html(number_format_i18n((int) $transaction->coins)); ?></td>
                            <td><?php echo esc_html(str_replace('_', ' ', (string) $transaction->status)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="8"><?php esc_html_e('No Paystack payments yet.', 'hausanovels-paystack'); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php
    }

    public static function frontend_styles(): void
    {
        if (! self::should_load_styles()) {
            return;
        }

        wp_register_style('hausanovels-paystack', false, array(), HAUSANOVELS_PAYSTACK_VERSION);
        wp_enqueue_style('hausanovels-paystack');
        wp_add_inline_style('hausanovels-paystack', '
            .hn-paystack-panel{scroll-margin-top:84px;width:100%;max-width:100%;min-width:0;overflow:hidden;border:1px solid rgba(168,179,199,.18);border-radius:16px;padding:14px;background:linear-gradient(180deg,rgba(17,24,39,.82),rgba(5,8,22,.74));color:inherit;margin:14px 0;box-shadow:0 16px 34px rgba(0,0,0,.2)}
            .hn-paystack-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:6px}
            .hn-paystack-head-copy{min-width:0}
            .hn-paystack-panel h2{margin:0;font-size:1.15rem;line-height:1.15}
            .hn-paystack-secure{display:inline-flex;align-items:center;gap:5px;flex:0 0 auto;border:1px solid rgba(33,199,122,.3);border-radius:999px;padding:5px 8px;background:rgba(33,199,122,.08);color:#79efb5;font-size:11px;font-weight:900;white-space:nowrap}
            .hn-paystack-note{color:#a8b3c7;margin:.45rem 0 1rem;font-size:.84rem;line-height:1.5}
            .hn-paystack-status{border-left:3px solid #21c77a;border-radius:8px;padding:10px 12px;background:rgba(33,199,122,.1);margin-bottom:12px;color:#dfffea;font-weight:800}
            .hn-paystack-status.is-error{border-left-color:#ff6578;background:rgba(255,101,120,.1);color:#ffdce1}
            .hn-paystack-mode{display:inline-flex;align-items:center;border:1px solid rgba(243,179,72,.38);border-radius:999px;padding:5px 9px;color:#f9d18a;font-weight:900;font-size:11px;margin:0 0 10px}
            .hn-paystack-bundles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;width:100%;min-width:0}
            .hn-paystack-bundle-form{display:block;min-width:0;margin:0}
            .hn-paystack-bundle{position:relative;width:100%;height:100%;min-width:0;min-height:154px;display:grid;grid-template-rows:auto 1fr auto;gap:9px;text-align:left;border:1px solid rgba(168,179,199,.2);border-radius:14px;padding:11px;background:linear-gradient(145deg,rgba(20,29,48,.97),rgba(7,11,25,.98));color:inherit;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.035);transition:transform .15s ease,border-color .15s ease,box-shadow .15s ease}
            .hn-paystack-bundle:hover,.hn-paystack-bundle:focus-visible{transform:translateY(-2px);border-color:rgba(33,199,122,.55);box-shadow:0 12px 24px rgba(0,0,0,.22);outline:0}
            .hn-paystack-bundle.is-best{border-color:rgba(243,179,72,.62);background:linear-gradient(145deg,rgba(62,43,13,.82),rgba(10,13,25,.98));box-shadow:inset 0 1px 0 rgba(255,224,164,.08)}
            .hn-paystack-bundle-label{display:block;min-height:2.15em;padding-right:0;color:#bdc7d8;font-size:.69rem;font-weight:900;line-height:1.18;overflow-wrap:anywhere}
            .hn-paystack-best{position:absolute;top:8px;right:8px;display:inline-flex;align-items:center;border-radius:999px;padding:3px 6px;background:#f3b348;color:#211300;font-size:.55rem;font-weight:950;white-space:nowrap;box-shadow:0 4px 10px rgba(0,0,0,.2)}
            .hn-paystack-coins{display:flex;align-items:center;gap:7px;min-width:0}
            .hn-paystack-coin-mark{display:inline-grid;place-items:center;flex:0 0 auto;width:1.85rem;height:1.85rem;border-radius:999px;background:linear-gradient(135deg,#f3b348,#ffd98d);color:#2b1900;font-size:.84rem;font-weight:950;box-shadow:0 7px 16px rgba(243,179,72,.2)}
            .hn-paystack-coin-copy{display:grid;min-width:0}
            .hn-paystack-coin-copy strong{font-size:clamp(1.02rem,5vw,1.28rem);line-height:1.05;overflow-wrap:anywhere}
            .hn-paystack-coin-copy small{color:#a8b3c7;font-size:.61rem;font-weight:850;line-height:1.2}
            .hn-paystack-price-row{display:grid;gap:3px;padding-top:8px;border-top:1px solid rgba(168,179,199,.13)}
            .hn-paystack-price{color:#f8fafc;font-size:.86rem;font-weight:950;white-space:nowrap}
            .hn-paystack-buy-text{color:#79efb5;font-size:.64rem;font-weight:950}
            .hn-paystack-bonus{color:#f3b348;font-size:.66rem;font-weight:900}
            .hn-paystack-button{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:8px;padding:11px 15px;background:#21c77a;color:#04110b;font-weight:950;text-decoration:none;cursor:pointer}
            .hn-paystack-button.is-muted{background:rgba(168,179,199,.16);color:#f8fafc}
            .hn-paystack-actions{display:flex;gap:10px;flex-wrap:wrap}
            @media(min-width:720px){.hn-paystack-bundles{grid-template-columns:repeat(4,minmax(0,1fr))}}
            @media(min-width:1100px){.hn-paystack-bundles{gap:12px}.hn-paystack-bundle{min-height:164px;padding:13px}}
            @media(max-width:370px){.hn-paystack-panel{padding:11px}.hn-paystack-head{display:grid}.hn-paystack-secure{width:max-content}.hn-paystack-bundles{gap:7px}.hn-paystack-bundle{min-height:148px;padding:9px}.hn-paystack-best{top:6px;right:6px}.hn-paystack-coin-mark{width:1.65rem;height:1.65rem}}
        ');
    }

    public static function get_bundles(): array
    {
        $settings = self::settings();
        $lines = preg_split('/\r\n|\r|\n/', (string) $settings['bundles']);
        $bundles = array();

        foreach ($lines as $line) {
            $line = trim($line);
            if ('' === $line) {
                continue;
            }

            $parts = array_map('trim', explode('|', $line));
            $amount = isset($parts[0]) ? absint($parts[0]) : 0;
            $coins = isset($parts[1]) ? absint($parts[1]) : 0;
            $label = isset($parts[2]) && $parts[2] ? sanitize_text_field($parts[2]) : sprintf(__('%d coins', 'hausanovels-paystack'), $coins);

            if ($amount > 0 && $coins > 0) {
                $bundles[] = array(
                    'amount_naira' => $amount,
                    'amount_kobo'  => $amount * 100,
                    'coins'        => $coins,
                    'label'        => $label,
                );
            }
        }

        return $bundles;
    }

    public static function shortcode_topup(): string
    {
        $settings = self::settings();

        if (! is_user_logged_in()) {
            $login_url = function_exists('hausanovels_signin_url') ? hausanovels_signin_url($settings['wallet_url']) : wp_login_url($settings['wallet_url']);
            $register_url = function_exists('hausanovels_register_url') ? hausanovels_register_url($settings['wallet_url'], 'reader') : wp_registration_url();

            return '<div class="hn-paystack-panel"><p>' . esc_html__('Please sign in or create a reader account to buy coins.', 'hausanovels-paystack') . '</p><div class="hn-paystack-actions"><a class="hn-paystack-button" href="' . esc_url($login_url) . '">' . esc_html__('Sign In', 'hausanovels-paystack') . '</a><a class="hn-paystack-button is-muted" href="' . esc_url($register_url) . '">' . esc_html__('Create Reader Account', 'hausanovels-paystack') . '</a></div></div>';
        }

        if (function_exists('hn_user_is_publisher_account') && hn_user_is_publisher_account(get_current_user_id()) && ! current_user_can('manage_options')) {
            return '<div class="hn-paystack-panel"><p>' . esc_html__('Publisher accounts do not use the reader coin wallet. Please use a separate reader account to buy coins and read chapters.', 'hausanovels-paystack') . '</p></div>';
        }

        $bundles = self::get_bundles();
        $status = self::status_message();
        $is_configured = '' !== self::active_secret_key();
        $base_rate = max(1, absint($settings['coins_per_naira'] ?? 1));
        $best_index = -1;
        $best_ratio = 0.0;
        foreach ($bundles as $candidate_index => $candidate) {
            $ratio = (int) $candidate['coins'] / max(1, (int) $candidate['amount_naira']);
            if ($ratio > $best_ratio) {
                $best_ratio = $ratio;
                $best_index = (int) $candidate_index;
            }
        }

        ob_start();
        ?>
        <section id="buy-coins" class="hn-paystack-panel" aria-labelledby="hn-buy-coins-title">
            <div class="hn-paystack-head">
                <div class="hn-paystack-head-copy">
                    <h2 id="hn-buy-coins-title"><?php esc_html_e('Buy Coins', 'hausanovels-paystack'); ?></h2>
                </div>
                <span class="hn-paystack-secure" aria-label="<?php esc_attr_e('Secure Paystack checkout', 'hausanovels-paystack'); ?>">✓ <?php esc_html_e('Secure checkout', 'hausanovels-paystack'); ?></span>
            </div>
            <?php if ('test' === self::active_mode()) : ?>
                <span class="hn-paystack-mode"><?php esc_html_e('Paystack test mode', 'hausanovels-paystack'); ?></span>
            <?php endif; ?>
            <?php if ($status) : ?>
                <div class="hn-paystack-status <?php echo esc_attr($status['type']); ?>"><?php echo esc_html($status['message']); ?></div>
            <?php endif; ?>
            <p class="hn-paystack-note"><?php echo esc_html((string) $settings['instructions']); ?></p>

            <?php if (! $is_configured) : ?>
                <p class="hn-paystack-status is-error"><?php esc_html_e('Paystack is not configured yet. Add the active mode secret key in the admin settings.', 'hausanovels-paystack'); ?></p>
            <?php elseif (! $bundles) : ?>
                <p><?php esc_html_e('No coin bundles are configured yet.', 'hausanovels-paystack'); ?></p>
            <?php else : ?>
                <div class="hn-paystack-bundles">
                    <?php foreach ($bundles as $index => $bundle) : ?>
                        <?php
                        $bonus = max(0, (int) $bundle['coins'] - ((int) $bundle['amount_naira'] * $base_rate));
                        $is_best = (int) $index === $best_index && $best_ratio > (float) $base_rate;
                        ?>
                        <form class="hn-paystack-bundle-form" method="post">
                            <?php wp_nonce_field('hn_paystack_initialize_' . $index, 'hn_paystack_nonce'); ?>
                            <input type="hidden" name="hn_paystack_action" value="initialize_topup">
                            <input type="hidden" name="bundle_index" value="<?php echo esc_attr((string) $index); ?>">
                            <input type="hidden" name="redirect_to" value="<?php echo esc_attr(self::current_url()); ?>">
                            <button class="hn-paystack-bundle<?php echo $is_best ? ' is-best' : ''; ?>" type="submit">
                                <span class="hn-paystack-bundle-label">
                                    <span><?php echo esc_html($bundle['label']); ?></span>
                                    <?php if ($is_best) : ?><span class="hn-paystack-best"><?php esc_html_e('Best value', 'hausanovels-paystack'); ?></span><?php endif; ?>
                                </span>
                                <span class="hn-paystack-coins">
                                    <span class="hn-paystack-coin-mark" aria-hidden="true">C</span>
                                    <span class="hn-paystack-coin-copy">
                                        <strong><?php echo esc_html(number_format_i18n($bundle['coins'])); ?></strong>
                                        <small><?php esc_html_e('coins', 'hausanovels-paystack'); ?><?php if ($bonus > 0) : ?> · <span class="hn-paystack-bonus"><?php echo esc_html(sprintf(__('+%s bonus', 'hausanovels-paystack'), number_format_i18n($bonus))); ?></span><?php endif; ?></small>
                                    </span>
                                </span>
                                <span class="hn-paystack-price-row">
                                    <span class="hn-paystack-price"><?php echo esc_html((string) $settings['currency'] . ' ' . number_format_i18n($bundle['amount_naira'])); ?></span>
                                    <span class="hn-paystack-buy-text"><?php esc_html_e('Buy now', 'hausanovels-paystack'); ?> →</span>
                                </span>
                            </button>
                        </form>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <?php

        return (string) ob_get_clean();
    }

    public static function shortcode_legacy_account(): string
    {
        return '';
    }

    public static function handle_requests(): void
    {
        if (isset($_GET['hn_paystack_webhook'])) {
            self::handle_webhook();
        }

        if (isset($_GET['hn_paystack_callback'])) {
            self::handle_callback();
        }

        if (! isset($_POST['hn_paystack_action'])) {
            return;
        }

        $action = sanitize_key(wp_unslash($_POST['hn_paystack_action']));

        if ('initialize_topup' === $action) {
            self::handle_initialize_topup();
        }
    }

    private static function handle_initialize_topup(): void
    {
        if (! is_user_logged_in()) {
            $login_url = function_exists('hausanovels_signin_url') ? hausanovels_signin_url(self::posted_redirect_url()) : wp_login_url(self::posted_redirect_url());
            wp_safe_redirect($login_url);
            exit;
        }

        $bundle_index = absint($_POST['bundle_index'] ?? 0);

        if (! isset($_POST['hn_paystack_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hn_paystack_nonce'])), 'hn_paystack_initialize_' . $bundle_index)) {
            wp_die(esc_html__('Invalid Paystack payment request.', 'hausanovels-paystack'));
        }

        $result = self::initialize_transaction(get_current_user_id(), $bundle_index);

        if (is_wp_error($result)) {
            wp_safe_redirect(add_query_arg('hn_payment', $result->get_error_code(), self::posted_redirect_url()));
            exit;
        }

        $checkout_url = (string) $result;
        if (! self::is_paystack_checkout_url($checkout_url)) {
            wp_safe_redirect(add_query_arg('hn_payment', 'hn_paystack_invalid_checkout_url', self::posted_redirect_url()));
            exit;
        }

        wp_redirect($checkout_url, 302, 'Hausanovels Paystack Funding');
        exit;
    }

    private static function handle_callback(): void
    {
        $reference = sanitize_text_field(wp_unslash($_GET['reference'] ?? ''));
        $settings = self::settings();
        $status = 'missing_reference';

        if ($reference) {
            $result = self::verify_and_credit($reference, 'callback');
            $status = is_wp_error($result) ? $result->get_error_code() : 'success';
        }

        wp_safe_redirect(add_query_arg(array(
            'hn_payment'           => $status,
            'hn_payment_reference' => $reference,
        ), $settings['wallet_url']));
        exit;
    }

    private static function handle_webhook(): void
    {
        $payload = (string) file_get_contents('php://input');
        $signature = sanitize_text_field(wp_unslash($_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? ''));
        $result = self::process_webhook_payload($payload, $signature);

        status_header(is_wp_error($result) ? self::error_status($result) : 200);
        echo is_wp_error($result) ? esc_html($result->get_error_message()) : 'ok';
        exit;
    }

    public static function handle_rest_webhook($request): WP_REST_Response
    {
        $payload = method_exists($request, 'get_body') ? (string) $request->get_body() : '';
        $signature = method_exists($request, 'get_header') ? sanitize_text_field((string) $request->get_header('x-paystack-signature')) : '';
        $result = self::process_webhook_payload($payload, $signature);

        if (is_wp_error($result)) {
            return new WP_REST_Response(array(
                'status'  => 'error',
                'message' => $result->get_error_message(),
            ), self::error_status($result));
        }

        return new WP_REST_Response(array(
            'status'  => 'ok',
            'message' => 'processed',
        ), 200);
    }

    private static function process_webhook_payload(string $payload, string $signature)
    {
        if ('' === $payload || '' === $signature) {
            return new WP_Error('hn_paystack_webhook_missing_signature', 'missing signature', array('status' => 401));
        }

        $matched_mode = self::verify_webhook_signature($payload, $signature);
        if (! $matched_mode) {
            return new WP_Error('hn_paystack_webhook_invalid_signature', 'invalid signature', array('status' => 401));
        }

        $event = json_decode($payload, true);
        if (! is_array($event)) {
            return new WP_Error('hn_paystack_webhook_bad_payload', 'invalid payload', array('status' => 400));
        }

        $event_name = (string) ($event['event'] ?? '');
        if ('charge.success' === $event_name) {
            $processed = self::process_charge_success((array) ($event['data'] ?? array()), 'webhook_' . sanitize_key($matched_mode));
            if (is_wp_error($processed)) {
                return array(
                    'event'   => $event_name,
                    'mode'    => $matched_mode,
                    'message' => $processed->get_error_message(),
                );
            }
        }

        return array(
            'event' => $event_name,
            'mode'  => $matched_mode,
        );
    }

    private static function verify_webhook_signature(string $payload, string $signature): string
    {
        foreach (self::webhook_secret_keys() as $mode => $secret_key) {
            $hash = hash_hmac('sha512', $payload, $secret_key);
            if (hash_equals($hash, $signature)) {
                return (string) $mode;
            }
        }

        return '';
    }

    private static function webhook_secret_keys(): array
    {
        $settings = self::settings();
        $keys = array();
        $candidates = array(
            (string) $settings['mode'] => self::secret_key_for_mode((string) $settings['mode']),
            'test'                     => (string) $settings['test_secret_key'],
            'live'                     => (string) $settings['live_secret_key'],
            'legacy'                   => (string) $settings['secret_key'],
        );

        foreach ($candidates as $mode => $secret_key) {
            $secret_key = trim((string) $secret_key);
            if ('' === $secret_key || in_array($secret_key, $keys, true)) {
                continue;
            }

            $keys[(string) $mode] = $secret_key;
        }

        return $keys;
    }

    private static function error_status(WP_Error $error): int
    {
        $data = $error->get_error_data();
        $status = is_array($data) ? absint($data['status'] ?? 400) : 400;

        return $status ?: 400;
    }

    public static function initialize_transaction(int $user_id, int $bundle_index)
    {
        $settings = self::settings();
        $secret_key = self::active_secret_key();
        $bundles = self::get_bundles();
        $bundle = $bundles[$bundle_index] ?? null;

        if (! $bundle) {
            return new WP_Error('hn_paystack_invalid_bundle', __('Please choose a valid coin bundle.', 'hausanovels-paystack'));
        }

        if ('' === $secret_key) {
            return new WP_Error('hn_paystack_not_configured', __('Paystack is not configured for the active mode yet.', 'hausanovels-paystack'));
        }

        if (! function_exists('hn_wallet_credit')) {
            return new WP_Error('hn_paystack_wallet_missing', __('Wallet plugin is required before accepting payments.', 'hausanovels-paystack'));
        }

        if (function_exists('hn_user_is_publisher_account') && hn_user_is_publisher_account($user_id) && ! current_user_can('manage_options')) {
            return new WP_Error('hn_paystack_publisher_account', __('Publisher accounts cannot buy reader coins.', 'hausanovels-paystack'));
        }

        $user = get_user_by('id', $user_id);
        if (! $user instanceof WP_User || ! $user->user_email) {
            return new WP_Error('hn_paystack_user_missing', __('User email is required for Paystack payment.', 'hausanovels-paystack'));
        }

        $reference = self::generate_reference($user_id);
        self::insert_transaction($user_id, $reference, $bundle, (string) $settings['currency'], 'pending', 'checkout', '');

        $response = self::api_request('POST', '/transaction/initialize', array(
            'email'        => $user->user_email,
            'amount'       => $bundle['amount_kobo'],
            'currency'     => (string) $settings['currency'],
            'reference'    => $reference,
            'callback_url' => self::callback_url(),
            'metadata'     => array(
                'project'      => 'hausanovels',
                'source'       => 'hausanovels_wallet',
                'user_id'      => $user_id,
                'coins'        => $bundle['coins'],
                'bundle_label' => $bundle['label'],
                'mode'         => self::active_mode(),
            ),
        ));

        if (is_wp_error($response)) {
            self::update_transaction($reference, array(
                'status'       => 'initialize_failed',
                'raw_response' => $response->get_error_message(),
            ));
            return $response;
        }

        self::update_transaction($reference, array(
            'status'       => 'initialized',
            'raw_response' => wp_json_encode($response),
        ));

        $authorization_url = esc_url_raw((string) ($response['data']['authorization_url'] ?? ''));
        if ('' === $authorization_url) {
            return new WP_Error('hn_paystack_no_auth_url', __('Paystack did not return a payment URL.', 'hausanovels-paystack'));
        }

        return $authorization_url;
    }

    public static function verify_and_credit(string $reference, string $source = 'manual')
    {
        $reference = sanitize_text_field($reference);

        if ('' === $reference) {
            return new WP_Error('hn_paystack_missing_reference', __('Missing Paystack reference.', 'hausanovels-paystack'));
        }

        $transaction = self::get_transaction($reference);
        if ($transaction && 'credited' === (string) $transaction->status) {
            return true;
        }

        if (! self::acquire_reference_lock($reference)) {
            return new WP_Error('hn_paystack_verification_busy', __('This payment is already being verified. Please wait a moment.', 'hausanovels-paystack'));
        }

        try {
            $transaction = self::get_transaction($reference);
            if ($transaction && 'credited' === (string) $transaction->status) {
                return true;
            }

            $response = self::api_request('GET', '/transaction/verify/' . rawurlencode($reference), array(), self::secret_key_for_reference($reference));
            if (is_wp_error($response)) {
                self::update_transaction($reference, array(
                    'status'       => 'verify_failed',
                    'raw_response' => $response->get_error_message(),
                ));
                return $response;
            }

            return self::process_charge_success((array) ($response['data'] ?? array()), $source);
        } finally {
            self::release_reference_lock($reference);
        }
    }

    private static function process_charge_success(array $data, string $source)
    {
        if (! function_exists('hn_wallet_credit')) {
            return new WP_Error('hn_paystack_wallet_missing', __('Wallet plugin is not active.', 'hausanovels-paystack'));
        }

        $reference = sanitize_text_field((string) ($data['reference'] ?? ''));
        $status = sanitize_key((string) ($data['status'] ?? ''));
        $amount_kobo = absint($data['amount'] ?? 0);
        $currency = strtoupper(sanitize_key((string) ($data['currency'] ?? 'NGN')));
        $paystack_id = sanitize_text_field((string) ($data['id'] ?? ''));

        if ('' === $reference || 'success' !== $status) {
            return new WP_Error('hn_paystack_not_successful', __('Paystack transaction is not successful yet.', 'hausanovels-paystack'));
        }

        $transaction = self::get_transaction($reference);
        if ($transaction && 'credited' === (string) $transaction->status) {
            return true;
        }

        $settings = self::settings();
        if ($transaction) {
            if ((int) $transaction->amount_kobo !== $amount_kobo || strtoupper((string) $transaction->currency) !== $currency) {
                self::update_transaction($reference, array(
                    'status'       => 'amount_mismatch',
                    'paystack_id'  => $paystack_id,
                    'raw_response' => wp_json_encode($data),
                ));
                return new WP_Error('hn_paystack_amount_mismatch', __('Paystack amount mismatch. Wallet was not credited.', 'hausanovels-paystack'));
            }

            $user_id = (int) $transaction->user_id;
            $coins = (int) $transaction->coins;
        } else {
            $metadata = (array) ($data['metadata'] ?? array());
            $user_id = absint($metadata['user_id'] ?? 0);
            $coins = absint($metadata['coins'] ?? floor(($amount_kobo / 100) * max(1, absint($settings['coins_per_naira']))));
            $bundle = array(
                'label'        => sanitize_text_field((string) ($metadata['bundle_label'] ?? __('Webhook payment', 'hausanovels-paystack'))),
                'amount_kobo'  => $amount_kobo,
                'amount_naira' => (int) floor($amount_kobo / 100),
                'coins'        => $coins,
            );
            self::insert_transaction($user_id, $reference, $bundle, $currency, 'webhook_received', 'webhook', wp_json_encode($data));
            $transaction = self::get_transaction($reference);
        }

        if ($user_id <= 0 || $coins <= 0) {
            self::update_transaction($reference, array(
                'status'       => 'unmapped',
                'paystack_id'  => $paystack_id,
                'raw_response' => wp_json_encode($data),
            ));
            return new WP_Error('hn_paystack_unmapped_user', __('Could not map Paystack payment to a reader wallet.', 'hausanovels-paystack'));
        }

        $result = hn_wallet_credit(
            $user_id,
            $coins,
            sprintf(__('Paystack wallet funding: %s', 'hausanovels-paystack'), $reference),
            'paystack:' . $reference,
            'paystack_' . sanitize_key($source),
            $transaction ? (int) $transaction->id : 0
        );

        if (is_wp_error($result)) {
            self::update_transaction($reference, array(
                'status'       => 'credit_failed',
                'paystack_id'  => $paystack_id,
                'raw_response' => wp_json_encode($data),
            ));
            return $result;
        }

        self::update_transaction($reference, array(
            'status'       => 'credited',
            'paystack_id'  => $paystack_id,
            'raw_response' => wp_json_encode($data),
            'credited_at'  => current_time('mysql'),
        ));

        do_action('hausanovels_paystack_wallet_credited', $user_id, $coins, $reference, $source, $data);

        return true;
    }

    private static function api_request(string $method, string $path, array $body = array(), string $secret_key_override = '')
    {
        $secret_key = '' !== trim($secret_key_override) ? trim($secret_key_override) : self::active_secret_key();

        if ('' === $secret_key) {
            return new WP_Error('hn_paystack_not_configured', __('Paystack secret key is not configured for the active mode.', 'hausanovels-paystack'));
        }

        $args = array(
            'method'  => strtoupper($method),
            'timeout' => 20,
            'headers' => array(
                'Authorization' => 'Bearer ' . $secret_key,
                'Content-Type'  => 'application/json',
            ),
        );

        if ($body) {
            $args['body'] = wp_json_encode($body);
        }

        $response = wp_remote_request('https://api.paystack.co' . $path, $args);
        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $raw_body = (string) wp_remote_retrieve_body($response);
        $decoded = json_decode($raw_body, true);

        if (! is_array($decoded)) {
            return new WP_Error('hn_paystack_response', __('Paystack returned an unreadable response.', 'hausanovels-paystack'));
        }

        $message = sanitize_text_field((string) ($decoded['message'] ?? __('Paystack request failed.', 'hausanovels-paystack')));
        if ($code >= 400 || empty($decoded['status'])) {
            return new WP_Error('hn_paystack_api', $message);
        }

        return $decoded;
    }

    private static function reference_lock_option(string $reference): string
    {
        return 'hn_paystack_verify_lock_' . md5($reference);
    }

    private static function acquire_reference_lock(string $reference): bool
    {
        $option = self::reference_lock_option($reference);
        $now = time();
        $current = (int) get_option($option, 0);

        if ($current > 0 && ($now - $current) < 60) {
            return false;
        }

        if ($current > 0) {
            delete_option($option);
        }

        return add_option($option, $now, '', false);
    }

    private static function release_reference_lock(string $reference): void
    {
        delete_option(self::reference_lock_option($reference));
    }

    private static function secret_key_for_reference(string $reference): string
    {
        $transaction = self::get_transaction($reference);
        if ($transaction && in_array((string) $transaction->mode, array('test', 'live'), true)) {
            return self::secret_key_for_mode((string) $transaction->mode);
        }

        return self::active_secret_key();
    }

    private static function insert_transaction(int $user_id, string $reference, array $bundle, string $currency, string $status, string $channel, string $raw_response): void
    {
        global $wpdb;

        $tables = self::tables();
        $now = current_time('mysql');
        $wpdb->insert($tables['transactions'], array(
            'user_id'      => $user_id,
            'reference'    => $reference,
            'bundle_label' => sanitize_text_field((string) ($bundle['label'] ?? '')),
            'mode'         => self::active_mode(),
            'amount_kobo'  => absint($bundle['amount_kobo'] ?? 0),
            'currency'     => $currency,
            'coins'        => absint($bundle['coins'] ?? 0),
            'status'       => sanitize_key($status),
            'channel'      => sanitize_key($channel),
            'raw_response' => $raw_response,
            'created_at'   => $now,
            'updated_at'   => $now,
        ), array('%d', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s'));
    }

    private static function update_transaction(string $reference, array $data): void
    {
        global $wpdb;

        if ('' === $reference || ! $data) {
            return;
        }

        $data['updated_at'] = current_time('mysql');
        $formats = array();
        foreach ($data as $key => $value) {
            $formats[] = in_array($key, array('amount_kobo', 'coins', 'user_id'), true) ? '%d' : '%s';
        }

        $tables = self::tables();
        $wpdb->update($tables['transactions'], $data, array('reference' => $reference), $formats, array('%s'));
    }

    private static function get_transaction(string $reference): ?object
    {
        global $wpdb;

        $tables = self::tables();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tables['transactions']} WHERE reference = %s", $reference));

        return $row ?: null;
    }

    private static function get_recent_transactions(int $limit = 20): array
    {
        global $wpdb;

        $tables = self::tables();
        $limit = max(1, min(100, $limit));

        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$tables['transactions']} ORDER BY created_at DESC LIMIT %d", $limit));
    }

    private static function generate_reference(int $user_id): string
    {
        return 'HNPAY-' . self::active_mode() . '-' . $user_id . '-' . time() . '-' . strtolower(wp_generate_password(8, false, false));
    }

    private static function status_message(): array
    {
        $status = sanitize_key(wp_unslash($_GET['hn_payment'] ?? ''));

        if (! $status) {
            return array();
        }

        if ('success' === $status || 'checked' === $status) {
            return array(
                'type'    => '',
                'message' => __('Payment confirmed. Your wallet balance has been checked and credited if the payment was successful.', 'hausanovels-paystack'),
            );
        }

        $messages = array(
            'missing_reference'           => __('Paystack did not return a payment reference.', 'hausanovels-paystack'),
            'hn_paystack_not_configured'  => __('Paystack is not configured for the active mode yet.', 'hausanovels-paystack'),
            'hn_paystack_invalid_bundle'  => __('Please choose a valid coin bundle.', 'hausanovels-paystack'),
            'hn_paystack_wallet_missing'  => __('Wallet plugin is not active, so coins could not be credited.', 'hausanovels-paystack'),
            'hn_paystack_amount_mismatch' => __('The Paystack amount did not match the selected bundle. Wallet was not credited.', 'hausanovels-paystack'),
            'hn_paystack_not_successful'  => __('The Paystack payment is not successful yet.', 'hausanovels-paystack'),
            'hn_paystack_invalid_checkout_url' => __('Paystack returned an invalid checkout URL. Please try again.', 'hausanovels-paystack'),
        );

        return array(
            'type'    => 'is-error',
            'message' => $messages[$status] ?? __('Payment could not be completed. Please try again or contact support.', 'hausanovels-paystack'),
        );
    }

    private static function posted_redirect_url(): string
    {
        $settings = self::settings();
        $redirect = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : $settings['wallet_url'];

        return wp_validate_redirect($redirect, $settings['wallet_url']);
    }

    private static function is_paystack_checkout_url(string $url): bool
    {
        $parts = wp_parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = strtolower((string) ($parts['host'] ?? ''));

        if ('https' !== $scheme || '' === $host) {
            return false;
        }

        return (bool) preg_match('/(^|\.)paystack\.(com|co)$/', $host);
    }

    private static function current_url(): string
    {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host = sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'] ?? ''));
        $uri = sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'] ?? '/'));

        return esc_url_raw($scheme . $host . $uri);
    }

    private static function user_label(int $user_id): string
    {
        $user = $user_id > 0 ? get_user_by('id', $user_id) : false;

        if ($user instanceof WP_User) {
            return $user->display_name . ' (#' . $user_id . ')';
        }

        return '#' . $user_id;
    }

    private static function should_load_styles(): bool
    {
        $app_page = sanitize_key((string) get_query_var('hn_app_page'));

        if (get_query_var('hn_wallet_page') || 'wallet' === $app_page || is_page('wallet')) {
            return true;
        }

        global $post;

        if (! $post instanceof WP_Post) {
            return false;
        }

        $content = (string) $post->post_content;

        foreach (array('hn_paystack_topup', 'hn_bank_transfer_topup', 'hn_manual_bank_transfer', 'hn_paystack_dedicated_account', 'hn_bank_transfer_account') as $shortcode) {
            if (has_shortcode($content, $shortcode)) {
                return true;
            }
        }

        return false;
    }

}

Hausanovels_Paystack_Plugin::init();

register_activation_hook(__FILE__, array('Hausanovels_Paystack_Plugin', 'activate'));

if (! function_exists('hn_paystack_get_bundles')) {
    function hn_paystack_get_bundles(): array
    {
        return Hausanovels_Paystack_Plugin::get_bundles();
    }
}

if (! function_exists('hn_paystack_active_mode')) {
    function hn_paystack_active_mode(): string
    {
        return Hausanovels_Paystack_Plugin::active_mode();
    }
}

if (! function_exists('hn_paystack_active_secret_key')) {
    function hn_paystack_active_secret_key(): string
    {
        return Hausanovels_Paystack_Plugin::active_secret_key();
    }
}
